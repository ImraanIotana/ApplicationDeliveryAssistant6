####################################################################################################
<#
.SYNOPSIS
    UNIVERSAL DEPLOYMENT FRAMEWORK: This deploys and removes applications, using a collection of scripts, collectively called The Universal Deployment Framework.
.DESCRIPTION
    This script is part of the Universal Deployment Framework (UDF) and provides a standardized, modular approach for installing and uninstalling applications.
    It supports all common deployment asset types, including MSI, EXE, fonts, drivers, certificates, and other application resources.
    The script can be executed manually or integrated into enterprise deployment platforms such as Microsoft Intune or Microsoft Configuration Manager (SCCM).
    INTUNE USAGE: Package this script together with the application source files into an .intunewin package. Use the command lines below.
    SCCM USAGE: Import the application into SCCM and configure the following command lines:
    - Install   : powershell.exe -ExecutionPolicy Bypass -File .\Start-Deployment.ps1 -Install -Verbose
    - Uninstall : powershell.exe -ExecutionPolicy Bypass -File .\Start-Deployment.ps1 -Uninstall -Verbose
.EXAMPLE
    Start-Deployment.ps1
.EXAMPLE
    Start-Deployment.ps1 -Install
.EXAMPLE
    Start-Deployment.ps1 -Uninstall
.INPUTS
    Requires at minimum: a valid data file (DeploymentData.psd1) in the same folder as this script, and the necessary source files for the applications to be deployed.
    The script does not take any direct input parameters, but relies on the presence of the data file and source files for its operation.
.OUTPUTS
    This Framework returns no stream output. All operational output is written to the host, and logged to the deployment logfile.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : Defined in the Global DeploymentObject
    Author          : Imraan Iotana
    Creation Date   : January 2023
    Last Update     : March 2026
#>
####################################################################################################

[CmdletBinding(DefaultParameterSetName='Install')]
[OutputType([System.Void])]
param (
    [Parameter(Mandatory=$false,ParameterSetName='Install',HelpMessage='Use this switch to trigger the installation process.')]
    [System.Management.Automation.SwitchParameter]$Install,

    [Parameter(Mandatory=$true,ParameterSetName='Uninstall',HelpMessage='Use this switch to trigger the uninstallation process.')]
    [System.Management.Automation.SwitchParameter]$Uninstall
)

begin {
}

process {
    # PREPARATION
    # Create the Global DeploymentObject
    [PSCustomObject]$Global:DeploymentObject = @{
        # Main
        Name                    = [System.String]'Universal Deployment Framework'
        UDFVersion              = [System.String]'6.0.0.0'
        DeploymentAction        = [System.String]($PSCmdlet.ParameterSetName)
        # Items
        Rootfolder              = [System.String]$PSScriptRoot
        DeploymentDataFilePath  = [System.String](Join-Path -Path $PSScriptRoot -ChildPath 'DeploymentData.psd1')
    }

    # EXECUTION
    # Import all the engine modules
    Get-ChildItem -Path $PSScriptRoot -Filter *.psm1 -File -Recurse | ForEach-Object { Import-Module -Name $_.FullName -Force }
    # Start the Deployment Process
    Start-MainDeploymentProcess -DeploymentDataFilePath $Global:DeploymentObject.DeploymentDataFilePath
}

end {
}

### END OF DEPLOYMENTSCRIPT
####################################################################################################
