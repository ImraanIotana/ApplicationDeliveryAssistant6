#
# Module 'ShortcutMainEngine.psm1'
# Last Update: March 2026
#

####################################################################################################
<#
.SYNOPSIS
    This function starts the Deployment Process for shortcuts based on the provided deployment object.
.DESCRIPTION
    The Start-ShortcutDeployment function takes a deployment object as input, which contains information about the shortcuts to be installed or removed and the action to be performed (install or uninstall).
    The function processes the deployment object and calls the appropriate functions to either install or remove the shortcuts based on the specified deployment action.
.EXAMPLE
    Start-ShortcutDeployment -DeploymentObject $DeploymentObject
.INPUTS
    [System.Collections.Hashtable]$DeploymentObject
    The deployment object that will be processed. It must contain the following keys:
.OUTPUTS
    [System.Boolean]$ShortcutDeploymentSuccess
    A boolean value indicating whether the deployment was successful or not.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################

function Start-ShortcutDeployment {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The deployment object that will be processed.')]
        [System.Collections.Hashtable]$DeploymentObject
    )
    begin {
        # Set the Output
        [System.Boolean]$ShortcutDeploymentSuccess = $null
    }
    process {
        try {
            # EXECUTION
            # Call the appropriate function based on the DeploymentAction in the deployment object
            $ShortcutDeploymentSuccess = switch ($DeploymentObject.DeploymentAction) {
                'Install'   { Install-Shortcut -DeploymentObject $DeploymentObject -ErrorAction Stop }
                'Uninstall' { Uninstall-Shortcut -DeploymentObject $DeploymentObject -ErrorAction Stop }
            }
        }
        catch [System.ArgumentException] {
            $PSCmdlet.ThrowTerminatingError($_)
        }
        catch [System.UnauthorizedAccessException] {
            $PSCmdlet.ThrowTerminatingError($_)
        }
        catch [System.Management.Automation.RuntimeException] {
            Write-Line "A runtime error has occurred." -Type Fail
            $PSCmdlet.ThrowTerminatingError($_)
        }
        catch {
            Write-ErrorReport -ErrorRecord $_
        }
    }
    end {
        # OUTPUT
        # Return the deployment success status
        $ShortcutDeploymentSuccess
    }
    
}

# END OF FUNCTION
####################################################################################################
