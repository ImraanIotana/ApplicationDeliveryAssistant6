#
# Module 'ShortcutInstallEngine.psm1'
# Last Update: March 2026
#

####################################################################################################
<#
.SYNOPSIS
    Installs a shortcut based on the provided deployment object.
.DESCRIPTION
    This function installs a shortcut by creating it on the user's desktop and start menu, as well as the system's desktop and start menu, depending on the parameters provided in the deployment object.
.EXAMPLE
    Install-Shortcut -DeploymentObject $DeploymentObject
.INPUTS
    [System.Collections.Hashtable]$DeploymentObject
    The deployment object that will be processed. It must contain the following keys:
.OUTPUTS
    [System.Boolean]$DeploymentSuccess
    A boolean value indicating whether the deployment was successful or not.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Install-Shortcut {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The deployment object that will be processed.')]
        [System.Collections.Hashtable]$DeploymentObject
    )

    begin {
        # PREPARATION - OUTPUT
        # Set the Output
        [System.Boolean]$InstallShortcutSuccess = $null
    }

    process {
        $InstallShortcutSuccess = try {
            # PREPARATION - SHORTCUT FULL PATHS
            # Add the full paths of the shortcuts to the DeploymentObject
            $DeploymentObject = Add-ShortcutFullPaths -DeploymentObject $DeploymentObject -ErrorAction Stop

            # PREPARATION - ICON FILE PATH
            # Add the IconFilePath
            $DeploymentObject = Add-ShortcutIconPath -DeploymentObject $DeploymentObject -ErrorAction Stop
    
            # EXECUTION
            # Create a new shortcut
            New-Shortcut -DeploymentObject $DeploymentObject -ErrorAction Stop
        }
        catch [System.UnauthorizedAccessException] {
            $PSCmdlet.ThrowTerminatingError($_)
        }
        catch {
            Write-ErrorReport -ErrorRecord $_
        }
    }

    end{
        # Return the deployment success status
        $InstallShortcutSuccess
    }
}

# END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Creates a new shortcut based on the provided deployment object.
.DESCRIPTION
    This function creates a new shortcut by placing it on the user's desktop and start menu, as well as the system's desktop and start menu, depending on the parameters provided in the deployment object.
.EXAMPLE
    New-Shortcut -DeploymentObject $DeploymentObject
.INPUTS
    [System.Collections.Hashtable]$DeploymentObject
    The deployment object that will be processed. It must contain the following keys:
.OUTPUTS
    [System.Boolean]$NewShortcutSuccess
    A boolean value indicating whether the shortcut creation was successful or not.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function New-Shortcut {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The deployment object that will be processed.')]
        [System.Collections.Hashtable]$DeploymentObject
    )

    begin {
        # PREPARATION - INPUT
        # Get the ShortcutsToCreate
        $ShortcutsToCreate = $DeploymentObject.ShortcutsToCreate

        # PREPARATION - OUTPUT
        # Set the Output
        [System.Boolean]$NewShortcutSuccess = $null
    }

    process {
        try {
            # For each shortcut location, create the shortcut
            foreach ($ShortcutFullPath in $ShortcutsToCreate) {
                # Create a WScript object
                [System.__ComObject]$WScriptShellObject = New-Object -ComObject WScript.Shell

                # Create a new shortcut object
                Write-Line "Creating a new shortcut object... ($ShortcutFullPath)"
                [System.__ComObject]$NewShortcutObject = $WScriptShellObject.CreateShortcut($ShortcutFullPath)

                # Add the properties to the shortcut object
                $NewShortcutObject = Add-ShortcutProperties -ShortcutObject $NewShortcutObject -DeploymentObject $DeploymentObject -ErrorAction Stop

                # Save the shortcut
                Write-Line "Saving the shortcut object... ($ShortcutFullPath)"
                $NewShortcutObject.Save()

                # Clean up the COM objects
                Clear-ComObject -ComObject @($NewShortcutObject, $WScriptShellObject)

                # Set the shortcut creation success status to true
                $NewShortcutSuccess = $true
            }
        }
        catch [System.UnauthorizedAccessException] {
            Write-Line "You do not have the necessary permissions to create the shortcut: ($ShortcutFullPath)." -Type Fail
            $PSCmdlet.ThrowTerminatingError($_)
        }
        catch {
            Write-ErrorReport -ErrorRecord $_
        }
    }

    end{
        # Return the shortcut creation success status
        $NewShortcutSuccess
    }
}

# END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Adds the IconFilePath property to the DeploymentObject based on the IconFileName property.
.DESCRIPTION
    This function is responsible for adding the IconFilePath property to the deployment object based on the IconFileName property.
    It checks if the IconFileName is provided, validates that the file exists in the source files folder, creates a local folder in ProgramData for the application icon,
    copies the icon file to that local folder, and updates the IconFilePath in the deployment object to point to the new location of the icon file.
.EXAMPLE
    Add-ShortcutIconPath -DeploymentObject $DeploymentObject
    This command will process the provided deployment object, check for the IconFileName property, and if it is set and valid, it will copy the icon file to a local folder in ProgramData and update the IconFilePath in the deployment object accordingly.
.INPUTS
    [System.Collections.Hashtable]$DeploymentObject
    A hashtable representing the deployment object that contains properties related to the deployment, including IconFileName.
.OUTPUTS
    [System.Collections.Hashtable]$UpdatedDeploymentObject
    A hashtable representing the updated deployment object with the IconFilePath property set if the icon file was successfully processed.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Add-ShortcutIconPath {
    [CmdletBinding()]
    [OutputType([System.Collections.Hashtable])]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The deployment object that will be processed.')]
        [System.Collections.Hashtable]$DeploymentObject
    )

    begin {
        # PREPARATION - INPUT
        # Set the IconFileName
        [System.String]$IconFileName = $DeploymentObject.IconFileName

        # PREPARATION - HANDLERS
        # Set the local folder for the application icon
        [System.String]$LocalIconFolder = Join-Path -Path $env:ProgramData -ChildPath (Get-DeploymentData -PropertyName ApplicationID)

        # PREPARATION - OUTPUT
        # Set the Output
        [System.Collections.Hashtable]$UpdatedDeploymentObject = $DeploymentObject
    }

    process {
        try {
            # VALIDATION - STRING
            # If the IconFileName property is empty, write the message and return without setting the icon file path
            if (Test-String -IsEmpty $IconFileName) {
                Write-Line "The IconFileName string is empty. The icon will not be set for the shortcut."
                return
            }

            # VALIDATION - FILE
            # Get the full path of the icon file from the source files folder
            Write-Verbose "The IconFileName property is ($IconFileName)."
            [System.String]$IconFilePathInSourceFiles = Get-SourceItem -FileName $IconFileName -ErrorAction Stop

            # EXECUTION - COPY ICON FILE
            # Copy the icon file to the local folder
            Copy-ItemUDF -ThisFile $IconFilePathInSourceFiles -IntoThisFolder $LocalIconFolder -OutHost -ErrorAction Stop

            # EXECUTION - ADD ICON FILE PATH
            # Set the IconFilePath in the UpdatedDeploymentObject
            $UpdatedDeploymentObject.IconFilePath = Join-Path -Path $LocalIconFolder -ChildPath $IconFileName
            Write-Verbose "The IconFilePath for the shortcut has been set to: ($($UpdatedDeploymentObject.IconFilePath))."
        }
        catch [System.UnauthorizedAccessException] {
            $PSCmdlet.ThrowTerminatingError($_)
        }
        catch [System.Management.Automation.RuntimeException] {
            Write-Line "A runtime error has occurred." -Type Fail
            $PSCmdlet.ThrowTerminatingError($_)
        }
        catch {
            Write-ErrorReport -ErrorRecord $_
        }

    }

    end{
        # OUTPUT
        # Return the updated deployment object
        $UpdatedDeploymentObject
    }
}

# END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Adds the full paths for the shortcuts to the DeploymentObject based on the DisplayName and StartMenuSubFolder properties.
.DESCRIPTION
    This function processes the provided deployment object, checks for the DisplayName and StartMenuSubFolder properties
    If they are set and valid, it creates the necessary folders in the Start Menu and Desktop, and updates the ShortcutFilePath properties in the deployment object accordingly.  
.EXAMPLE
    Add-ShortcutFullPaths -DeploymentObject $DeploymentObject
    This command will process the provided deployment object, check for the DisplayName and StartMenuSubFolder properties, and if they are set and valid, it will create the necessary folders in the Start Menu and Desktop, and update the ShortcutFilePath properties in the deployment object accordingly.
.INPUTS
    [System.Collections.Hashtable]$DeploymentObject
    A hashtable representing the deployment object that contains properties related to the deployment, including DisplayName and StartMenuSubFolder.
.OUTPUTS
    [System.Collections.Hashtable]$UpdatedDeploymentObject
    A hashtable representing the updated deployment object with the ShortcutFilePath properties set if the shortcuts were successfully processed.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Add-ShortcutFullPaths {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The deployment object that will be processed.')]
        [System.Collections.Hashtable]$DeploymentObject
    )
    
    begin {
        # PREPARATION - INPUT
        # Get the StartMenuSubFolderName
        [System.String]$StartMenuSubFolderName = $DeploymentObject.StartMenuSubFolder
        # Set the shortcut file name
        [System.String]$ShortcutFileName = "$($DeploymentObject.DisplayName).lnk"

        # PREPARATION - HANDLERS
        # Set the Start Menu Programs Folder
        [System.String]$SystemStartMenuProgramsFolder = Get-SystemPath -Name StartMenuProgramsFolder
        # Set the Desktop Folder
        [System.String]$SystemDesktopFolder = Get-SystemPath -Name DesktopFolder

        # PREPARATION - OUTPUT
        # Set the Output
        [System.Collections.Hashtable]$UpdatedDeploymentObject = $DeploymentObject
    }
    
    process {
        try {
            # PREPARATION - START MENU SUBFOLDER
            # Set the shortcut path for the start menu. If a StartMenuSubFolder is specified, place the shortcut in that subfolder. Otherwise, place it directly in the Programs folder.
            [System.String]$ShortcutStartMenuParentFolder = if (Test-String -IsEmpty $StartMenuSubFolderName) {
                $SystemStartMenuProgramsFolder
            } else {
                Join-Path -Path $SystemStartMenuProgramsFolder -ChildPath $StartMenuSubFolderName
            }

            # EXECUTION - START MENU SUBFOLDER
            # Create the StartMenuSubFolder
            New-FolderUDF -Path $ShortcutStartMenuParentFolder -ResetACL
            # Add the StartMenuParentFolder to the UpdatedDeploymentObject
            $UpdatedDeploymentObject.ShortcutStartMenuParentFolder = $ShortcutStartMenuParentFolder

            # EXECUTION - SHORTCUT FILE NAME
            # Set the full path for the start menu shortcut
            [System.String]$ShortcutInStartMenuFullPath = Join-Path -Path $DeploymentObject.ShortcutStartMenuParentFolder -ChildPath $ShortcutFileName

            # PREPARATION - SHORTCUTS ARRAY
            # Set the array of shortcuts to create
            [System.Collections.ArrayList]$ShortcutsToCreate = @($ShortcutInStartMenuFullPath)

            # PREPARATION - DESKTOP SHORTCUT
            # If the AlsoPlaceOnDesktop property is set to true, add the desktop shortcut path to the array of shortcuts to create
            if ($DeploymentObject.AlsoPlaceOnDesktop -eq $true) { [System.Void]($ShortcutsToCreate.Add((Join-Path -Path $SystemDesktopFolder -ChildPath $ShortcutFileName))) }

            # Add the array to the DeploymentObject
            $UpdatedDeploymentObject.ShortcutsToCreate = $ShortcutsToCreate.ToArray()
        }
        catch [System.UnauthorizedAccessException] {
            $PSCmdlet.ThrowTerminatingError($_)
        }
        catch {
            Write-ErrorReport -ErrorRecord $_
        }
    }

    end {
        # OUTPUT
        # Return the updated deployment object
        $UpdatedDeploymentObject
    }
}

# END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Adds properties to a shortcut object based on the deployment object.
.DESCRIPTION
    This function processes the provided deployment object and updates the shortcut object with properties such as TargetPath, WorkingDirectory, Arguments, and IconLocation.
.EXAMPLE
    Add-ShortcutProperties -ShortcutObject $ShortcutObject -DeploymentObject $DeploymentObject
    This command will take the provided shortcut object and deployment object, and update the shortcut object with properties based on the values in the deployment object.
.INPUTS
    [System.__ComObject]$ShortcutObject
    A COM object representing the shortcut that will be updated with properties from the deployment object.
    [System.Collections.Hashtable]$DeploymentObject
    A hashtable representing the deployment object that contains properties related to the deployment, including DisplayName and StartMenuSubFolder.
.OUTPUTS
    [System.__ComObject]$UpdatedShortcutObject
    A COM object representing the updated shortcut with properties set based on the deployment object.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Add-ShortcutProperties {
    [CmdletBinding()]
    [OutputType([System.__ComObject])]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The Shell Object that will be used to create the shortcuts.')]
        [System.__ComObject]$ShortcutObject,

        [Parameter(Mandatory=$true,HelpMessage='The deployment object that will be processed.')]
        [System.Collections.Hashtable]$DeploymentObject
    )
    
    begin {
        # PREPARATION - OUTPUT
        # Set the Output
        [System.__ComObject]$UpdatedShortcutObject = $ShortcutObject
    }
    
    process {
        try {
            # EXECUTION - SET SHORTCUT PROPERTIES
            # Setting the TargetPath
            Write-Line "Setting the TargetPath to ($($DeploymentObject.TargetPath))"
            $UpdatedShortcutObject.TargetPath = $DeploymentObject.TargetPath
    
            # Set the WorkingDirectory
            if ($DeploymentObject.WorkingDirectory) {
                Write-Line "Setting the WorkingDirectory to ($($DeploymentObject.WorkingDirectory))"
                $UpdatedShortcutObject.WorkingDirectory = $DeploymentObject.WorkingDirectory
            } else {
                Write-Verbose "The WorkingDirectory property is empty."
            }
    
            # Set the Arguments
            if ($DeploymentObject.Arguments) {
                Write-Line "Setting the Arguments to ($($DeploymentObject.Arguments))"
                $UpdatedShortcutObject.Arguments = $DeploymentObject.Arguments
            } else {
                Write-Verbose "The Arguments property is empty."
            }
    
            # Set the IconLocation
            if ($DeploymentObject.IconFilePath) {
                Write-Line "Setting the IconLocation to ($($DeploymentObject.IconFilePath))"
                $UpdatedShortcutObject.IconLocation = $DeploymentObject.IconFilePath
            } else {
                Write-Verbose "The IconFilePath property is empty."
            }
        }
        catch {
            $PSCmdlet.ThrowTerminatingError($_)
        }
    }
    
    end {
        # OUTPUT
        # Return the updated shortcut object
        $UpdatedShortcutObject
    }
}

# END OF FUNCTION
####################################################################################################
