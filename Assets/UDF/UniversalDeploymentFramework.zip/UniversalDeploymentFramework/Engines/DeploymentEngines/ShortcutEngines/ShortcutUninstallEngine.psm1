#
# Module 'ShortcutUninstallEngine.psm1'
# Last Update: March 2026
#

####################################################################################################
<#
.SYNOPSIS
    This function uninstalls shortcuts from the system based on the provided deployment object.
.DESCRIPTION
    The Uninstall-Shortcut function takes a deployment object as input, which contains information about the shortcuts to be removed and the action to be performed (uninstall).
    The function processes the deployment object and calls the appropriate functions to remove the shortcuts based on the specified deployment action.
.EXAMPLE
    Uninstall-Shortcut -DeploymentObject $DeploymentObject
.INPUTS
    [System.Collections.Hashtable]$DeploymentObject
    The deployment object that will be processed. It must contain the following keys:
.OUTPUTS
    [System.Boolean]$ShortcutUninstallSuccess
    A boolean value indicating whether the uninstallation was successful or not.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################

function Uninstall-Shortcut {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The deployment object that will be processed.')]
        [System.Collections.Hashtable]$DeploymentObject
    )
    begin {
        # PREPARATION - INPUT
        # Create a new hashtable with the necessary properties for the Remove-Shortcut function
        [System.Collections.Hashtable]$RemoveShortcutDeploymentObject = @{
            Type                    = 'REMOVESHORTCUT'
            ShortcutFileName        = "$($DeploymentObject.DisplayName).lnk"
            PerformDuringInstall    = $true
            PerformDuringUninstall  = $true
            AlsoRemoveFromStartMenu = $true
            DeploymentAction        = $DeploymentObject.DeploymentAction
            DeploymentFunction      = 'Remove-Shortcut'
        }

        # PREPARATION - HANDLERS
        # Set the local folder for the application icon
        [System.String]$LocalIconFolder = Join-Path -Path $env:ProgramData -ChildPath (Get-DeploymentData -PropertyName ApplicationID)

        # PREPARATION - OUTPUT
        # Set the Output
        [System.Boolean]$ShortcutUninstallSuccess = $null
    }

    process {
        try {
            # EXECUTION - REMOVE ICON FOLDER
            # Remove the local icon folder
            Remove-ItemUDF -Path $LocalIconFolder -OutHost -ErrorAction Stop
            # Call the Remove-Shortcut function to remove the shortcut based on the properties of the RemoveShortcutDeploymentObject
            $ShortcutUninstallSuccess = Remove-Shortcut -DeploymentObject $RemoveShortcutDeploymentObject -ErrorAction Stop
        }
        catch {
            $PSCmdlet.ThrowTerminatingError($_)
        }
    }

    end {
        # Return the shortcut uninstallation success status
        $ShortcutUninstallSuccess
    }
    
}

# END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    This function removes shortcuts from the system based on the provided deployment object.
.DESCRIPTION
    The Remove-Shortcut function takes a deployment object as input, which contains information about the shortcut to be removed and the locations from which it should be removed.
    The function searches for the specified shortcut in the user's desktop and start menu, as well as the system's desktop and start menu, depending on the parameters provided in the deployment object.
    If the shortcut is found, it is removed from the system. The function returns a boolean value indicating whether the removal was successful or not.
.EXAMPLE
    Remove-Shortcut -DeploymentObject $DeploymentObject
.INPUTS
    [System.Collections.Hashtable]$DeploymentObject
    The deployment object that will be processed. It must contain the following keys:
        - ShortcutFileName: The name of the shortcut file to be removed.
        - RemoveFromDesktopOnly: A boolean value indicating whether to remove the shortcut only from the desktop.
.OUTPUTS
    [System.Boolean]$ShortcutRemoveSuccess
    A boolean value indicating whether the shortcut removal was successful or not.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Remove-Shortcut {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param(
        [Parameter(Mandatory=$true,HelpMessage='The deployment object that will be processed.')]
        [System.Collections.Hashtable]$DeploymentObject
    )
    
    begin {
        # Set the Output
        [System.Boolean]$ShortcutRemoveSuccess  = $true
    }

    process {
        try {
            # PREPARATION
            # Set the Desktop Folders
            [System.String]$SystemDesktopFolder     = Get-SystemPath -Name DesktopFolder
            [System.String]$UserDesktopFolder       = Get-UserPath -Name DesktopFolder
            # Set the Startmenu Folders
            [System.String]$SystemStartmenuFolder   = Get-SystemPath -Name StartMenuFolder
            [System.String]$UserStartmenuFolder     = Get-UserPath -Name StartMenuFolder
            # Set the folders to search for the shortcut
            [System.Collections.ArrayList]$FoldersToSearch = @($SystemDesktopFolder,$UserDesktopFolder)
            if ($DeploymentObject.AlsoRemoveFromStartMenu -eq $true) { [System.Void]($FoldersToSearch.AddRange(@($SystemStartmenuFolder,$UserStartmenuFolder))) }

            # EXECUTION - REMOVAL
            # Set the shortcut file name to search for
            [System.String]$ShortcutFileName = $DeploymentObject.ShortcutFileName
            # Get the list of shortcuts to remove as an array
            [System.String[]]$ShortcutsToRemoveArray = Get-ShortcutPaths -ShortcutFileName $ShortcutFileName -FoldersToSearch $FoldersToSearch.ToArray()
            # If no shortcuts are found, return
            if (Test-Array -IsEmpty $ShortcutsToRemoveArray) { Write-Line "No Shortcut with the name ($ShortcutFileName) was found." -Type SuccessNoAction ; return }
            # Write the number of shortcuts
            Write-Line "Number of shortcuts to remove: ($($ShortcutsToRemoveArray.Count))"
            # For each shortcut to remove
            foreach ($ShortcutToRemoveFullPath in $ShortcutsToRemoveArray) {

                # REMOVAL - SHORTCUT
                # Remove the shortcut
                Remove-ItemUDF -Path $ShortcutToRemoveFullPath -OutHost -ErrorAction Stop

                # REMOVAL - START MENU SUBFOLDER
                # Check if the StartMenuSubFolder is empty, and remove it, if it is
                Remove-StartMenuSubFolder -ShortcutFullPath $ShortcutToRemoveFullPath
            }
        }
        catch [System.ArgumentException] {
            $ShortcutRemoveSuccess = $false
            $PSCmdlet.ThrowTerminatingError($_)
        }
        catch {
            $ShortcutRemoveSuccess = $false
            Write-ErrorReport -ErrorRecord $_
        }
    }

    end {
        # Return the shortcut removal success status
        $ShortcutRemoveSuccess
    }
}

# END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    This function removes a Start Menu subfolder if it is empty, based on the provided folder path or shortcut path.
.DESCRIPTION
    The function takes either a folder path or a shortcut path as input. If a folder path is provided, it checks if the folder is empty and removes it if it is.
    If a shortcut path is provided, it checks the parent folder of the shortcut and removes it if it is empty.
.EXAMPLE
    Remove-StartMenuSubFolder -StartMenuSubFolderFullPath "C:\ProgramData\Microsoft\Windows\Start Menu\MyApplicationFolder"
.EXAMPLE
    Remove-StartMenuSubFolder -ShortcutFullPath "C:\ProgramData\Microsoft\Windows\Start Menu\MyApplicationFolder\MyApp.lnk"
.INPUTS
    [System.String]$StartMenuSubFolderFullPath
    The full path of the Start Menu subfolder to check and remove if empty. Example: "C:\ProgramData\Microsoft\Windows\Start Menu\MyApplicationFolder"
    -or-
    [System.String]$ShortcutFullPath
    The full path of the shortcut, of which the parent folder will be checked and removed if empty. Example: "C:\ProgramData\Microsoft\Windows\Start Menu\MyApplicationFolder\MyApp.lnk"
.OUTPUTS
    No objects are returned to the pipeline. All operational output is written to the host and logged to the deployment logfile.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Remove-StartMenuSubFolder {
    [CmdletBinding()]
    [OutputType([System.Void])]
    param(
        [Parameter(Mandatory=$true,ParameterSetName='ByFolder',HelpMessage='The full path of the Start Menu subfolder to check and remove if empty.')]
        [System.String]$StartMenuSubFolderFullPath,
        
        [Parameter(Mandatory=$true,ParameterSetName='ByShortcut',HelpMessage='The full path of the shortcut, of which the parent folder will be checked and removed if empty.')]
        [System.String]$ShortcutFullPath
    )
    
    begin {
        # Set the FolderToCheck
        [System.String]$FolderToCheck = switch ($PSCmdlet.ParameterSetName) {
            'ByFolder'      { $StartMenuSubFolderFullPath }
            'ByShortcut'    { Split-Path -Path $ShortcutFullPath -Parent }
        }

        # Set the Desktop folders
        [System.String]$SystemDesktopFolder = [Environment]::GetFolderPath('CommonDesktopDirectory')
        [System.String]$UserDesktopFolder   = [Environment]::GetFolderPath('Desktop')
    }
    process {
        try {
            # Check if it is a desktop path.
            [System.Boolean]$IsDesktopPath = (
                $FolderToCheck.StartsWith($SystemDesktopFolder,'OrdinalIgnoreCase') -or 
                $FolderToCheck.StartsWith($UserDesktopFolder,'OrdinalIgnoreCase')
            )
            # If it is a desktop path, return without attempting to remove the folder.
            if ($IsDesktopPath) {
                Write-Line "The parent folder of the shortcut is a desktop path. It will not be removed. ($FolderToCheck)"
                return
            }
            # If the folder exists
            if (Test-Path -Path $FolderToCheck) {
                # Check if the folder is really empty (no files, no subfolders)
                [System.Object[]]$FolderContent = Get-ChildItem -Path $FolderToCheck -Force -ErrorAction SilentlyContinue
                # If the StartMenu subfolder is empty, remove it
                if (-not $FolderContent) {
                    # Remove the empty StartMenu subfolder
                    Write-Line "The StartMenu subfolder is empty. Removing the empty folder... ($FolderToCheck)"
                    Remove-ItemUDF -Path $FolderToCheck -OutHost -ErrorAction Stop
                } else {
                    # If the folder is not empty, write the message
                    Write-Line "The StartMenu subfolder is not empty. It will not be removed. ($FolderToCheck)"
                }
            } else {
                # If the folder does not exist, write the message
                Write-Line "The StartMenu subfolder ($FolderToCheck) does not exist."
            }
        } catch {
            Write-ErrorReport -ErrorRecord $_
        }
    }
    end {
    }
}

# END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Retrieves the full paths of the provided shortcut name, in the specified folders.
.DESCRIPTION
    This function searches for shortcut files in the specified folders and returns their full paths.
.EXAMPLE
    Get-ShortcutPaths -ShortcutFileName "MyApp.lnk" -FoldersToSearch @("C:\Users\Public\Desktop", "C:\Users\Public\Start Menu")
    This command will search for "MyApp.lnk" in the specified folders and return the full paths of any found shortcuts.
.INPUTS
    [System.String]$ShortcutFileName - The name of the shortcut file to find.
    [System.String[]]$FoldersToSearch - An array of folder paths to search for shortcut files.
.OUTPUTS
    [System.String[]] Array of shortcut file paths.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Get-ShortcutPaths {
    [CmdletBinding()]
    [OutputType([System.String[]])]
    param (
        [Parameter(Mandatory=$false,HelpMessage='Name of the shortcut file to find.')]
        [System.String]$ShortcutFileName,
        
        [Parameter(Mandatory=$false,HelpMessage='Folders to search for shortcuts.')]
        [System.String[]]$FoldersToSearch
    )

    begin {
        # Set the Output variable
        [System.Collections.ArrayList]$OutputShortcutPaths = @()
    }

    process {
        try {
            # VALIDATION
            # If the ShortcutFileName is not provided, write a message and return
            if (Test-String -IsEmpty $ShortcutFileName) {
                Write-Line "The ShortcutFileName string is null or empty." -Type Fail
                return
            }
            # If the FoldersToSearch array is null or empty, write a message and return
            if ($null -eq $FoldersToSearch -or $FoldersToSearch.Count -eq 0) {
                Write-Line "The FoldersToSearch array is null or empty." -Type Fail
                return
            }

            # EXECUTION
            # Search for shortcut files in the specified folders
            foreach ($SearchFolder in $FoldersToSearch) {
                if (Test-Path -Path $SearchFolder) {
                    # Write the message
                    Write-Line "Searching for shortcut ($ShortcutFileName) in folder ($SearchFolder)..."
                    # Search for the shortcut file in the current folder and add its full path to the list of shortcuts to remove
                    [System.String[]]$FoundShortcutFullPaths = (Get-ChildItem -Path $SearchFolder -Recurse -Filter $ShortcutFileName -File -ErrorAction SilentlyContinue).FullName
                    # If shortcuts are found, add them to the list of shortcuts to remove
                    if ($FoundShortcutFullPaths) { [System.Void]$OutputShortcutPaths.AddRange($FoundShortcutFullPaths) }
                }
            }
        }
        catch {
            Write-ErrorReport -ErrorRecord $_
        }
    }

    end {
        # Return the array of shortcut paths
        $OutputShortcutPaths.ToArray()
    }
}

# END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Clears an array of COM objects from memory.
.DESCRIPTION
    This function takes an array of COM objects, releases them from memory, and forces garbage collection to clean up any remaining references.
    Use this function to prevent memory leaks when working with COM objects in PowerShell.
.EXAMPLE
    Clear-ComObject -ComObject $comObjects
.INPUTS
    [System.__ComObject[]]$ComObjects - An array of COM objects to release and clear from memory.
.OUTPUTS
    No objects are returned to the pipeline. All operational output is written to the host and logged to the deployment logfile.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Clear-ComObject {
    [CmdletBinding()]
    [OutputType([System.Void])]
    param (
        [Parameter(Mandatory=$true,HelpMessage='An array of COM objects to release and clear from memory.')]
        [System.__ComObject[]]$ComObject
    )

    begin {
        # Set the COM objects to clear
        [System.__ComObject[]]$ComObjectsToClear = $ComObject
    }

    process {
        try {
            # VALIDATION
            if (Test-Array -IsEmpty $ComObjectsToClear) { Write-Line "No COM objects provided to clear." ; return }
    
            # EXECUTION
            # Clean up the COM objects
            foreach ($CurrentCOMObject in $ComObjectsToClear) {
                # Write the message
                [system.string]$ObjectFullName      = $CurrentCOMObject.FullName
                [System.String]$ObjectDescription   = if ($ObjectFullName) { $ObjectFullName } else { $CurrentCOMObject.GetType().FullName }
                Write-Line "Releasing COM object ($ObjectDescription)..."
                # Release the COM object
                [System.Runtime.InteropServices.Marshal]::ReleaseComObject($CurrentCOMObject) | Out-Null
                # Set the variable to null to release the reference
                $CurrentCOMObject = $null
            }
            # Force garbage collection to clean up the COM objects
            [System.GC]::Collect()
            [System.GC]::WaitForPendingFinalizers()
        }
        catch {
            Write-ErrorReport -ErrorRecord $_
        }
    }

    end {
    }

}

# END OF FUNCTION
####################################################################################################

