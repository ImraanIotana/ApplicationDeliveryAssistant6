#
# Module 'FileEngines.psm1'
# Last Update: March 2026
#

####################################################################################################
<#
.SYNOPSIS
    Starts the deployment process for a file deployment based on the provided deployment object.
.DESCRIPTION
    This function processes a file deployment by copying a specified file from the source files to a destination path during installation, and removing the file during uninstallation.
    The function determines the file name based on the deployment object properties and performs the necessary file operations accordingly.
.EXAMPLE
    Start-BasicFileDeployment -DeploymentObject $DeploymentObject
.INPUTS
    [System.Collections.Hashtable]$DeploymentObject
.OUTPUTS
    [System.Boolean]$CTX.Output
    Indicates whether the deployment was performed successfully.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Start-BasicFileDeployment {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The deployment object that will be processed.')]
        [System.Collections.Hashtable]$DeploymentObject
    )
    
    begin {
        # VALIDATION - INPUT
        # Validate the DeploymentObject
        Approve-MandatoryHashtable -Hashtable $DeploymentObject -HashtableDescription 'DeploymentObject'

        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            # Input
            DeploymentObject    = $DeploymentObject
            FileToCopy          = $DeploymentObject.FileToCopy
            FolderToCopyInto    = $DeploymentObject.DestinationFolder
            # Text Handlers
            Text                = @{
                Action          = $DeploymentObject.DeploymentActionInBrackets
                FunctionName    = $DeploymentObject.FunctionNameInBrackets
            }
            # Output
            Output              = $null
        }
    }

    process {
        try {
            # PREPARATION
            # Write the message
            Write-Line "Starting the $($CTX.Text.Action) of the function $($CTX.Text.FunctionName)..." -Type Busy

            # EXECUTION
            # Switch on the DeploymentAction
            switch ($CTX.DeploymentObject.DeploymentAction ) {
                'Install'   {
                    # PREPARATION
                    # Get the File from the source files
                    [System.String]$FileToCopyPath = Get-SourceItem -FileName $CTX.FileToCopy
                    # Copy the file to the destination path
                    Copy-ItemUDF -ThisFile $FileToCopyPath -IntoThisFolder $CTX.FolderToCopyInto -OutHost
                }
                'Uninstall' {
                    # EXECUTION
                    # Set the FileToRemove
                    [System.String]$FileToRemove = Join-Path -Path $CTX.FolderToCopyInto -ChildPath $CTX.FileToCopy
                    # Remove the file
                    Remove-ItemUDF -Path $FileToRemove -OutHost
                }
            }

            # RESULT - OUTPUT
            # Set the output to $true to indicate that the deployment was performed successfully
            $CTX.Output = $true
        }
        catch {
            # ERROR HANDLING
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
    }
    
    end {
        # OUTPUT
        # Return the output of the deployment process
        $CTX.Output
    }
}

### END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Tests if a file deployment should be performed based on deployment action and installation state.
.DESCRIPTION
    This function resolves the file from the deployment object, determines whether the file is already
    deployed, and returns whether the deployment should be performed for the specified action.
.EXAMPLE
    Test-FileDeploymentRequired -DeploymentObject $MyDeploymentObject
.INPUTS
    [System.Collections.Hashtable]
    [System.String]
.OUTPUTS
    [System.Boolean]
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Test-FileDeploymentRequired {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The deployment object that will be processed.')]
        [System.Collections.Hashtable]$DeploymentObject
    )

    begin {
        # VALIDATION - INPUT
        # Validate the DeploymentObject
        Approve-MandatoryHashtable -Hashtable $DeploymentObject -HashtableDescription 'DeploymentObject'

        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            # Input
            DeploymentObject            = $DeploymentObject
            FileToCopy                  = $DeploymentObject.FileToCopy
            # Text Handlers
            Text                = @{
                Action          = $DeploymentObject.DeploymentActionInBrackets
                FunctionName    = $DeploymentObject.FunctionNameInBrackets
            }
            # Output
            Output                      = $null
        }
    }

    process {
        try {
            # PREPARATION
            # Write the message
            Write-Line "Evaluating if the Deployment should be performed for the action $($CTX.Text.Action) by the function $($CTX.Text.FunctionName)..."
            # Set the DestinationFilePath based on the deployment object properties
            [System.String]$DestinationFilePath = Join-Path -Path $CTX.DeploymentObject.DestinationFolder -ChildPath $CTX.FileToCopy
            # Test if the file is installed by checking if the file exists at the destination path
            [System.Boolean]$FileIsInstalled = Test-Path -Path $DestinationFilePath -PathType Leaf

            # EXECUTION - EVALUATION
            # Evaluate whether deployment should be performed
            [System.Boolean]$FileDeploymentShouldBePerformed = switch ($CTX.DeploymentObject.DeploymentAction) {
                'Install'   {
                    # If the file is installed, and the OverwriteExistingFile is False
                    if ($FileIsInstalled -and ($CTX.DeploymentObject.OverwriteExistingFile -eq $false)) {
                        # Set the output to $false to indicate that the install should not be performed
                        Write-Line "The file is already installed, and the OverwriteExistingFile boolean has been set to False. ($DestinationFilePath)"
                        $false
                    }
                    else {
                        # In all other cases, set the output to $true to indicate that the install should be performed
                        $true
                    }
                }
                'Uninstall' {
                    # If the file is installed, return $true to indicate that the uninstall should be performed, otherwise return $false
                    if ($FileIsInstalled) {
                        $true
                    } else {
                        # Set the output to $false to indicate that the uninstall should not be performed
                        Write-Line "The file is NOT installed. ($DestinationFilePath)"
                        $false
                    }
                }
            }

            # RESULT - OUTPUT
            # Set the output
            $CTX.Output = $FileDeploymentShouldBePerformed
        }
        catch {
            # ERROR HANDLING
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
    }

    end {
        # OUTPUT
        # Return the output
        $CTX.Output
    }
}

### END OF FUNCTION
####################################################################################################
