#
# Module 'FolderEngines.psm1'
# Last Update: March 2026
#

####################################################################################################
<#
.SYNOPSIS
    Starts the deployment process for a folder deployment based on the provided deployment object.
.DESCRIPTION
    This function processes a folder deployment by copying a specified folder from the source files to a destination path during installation, and removing the folder during uninstallation.
    The function determines the folder name based on the deployment object properties and performs the necessary file operations accordingly.
.EXAMPLE
    Start-BasicFolderDeployment -DeploymentObject $DeploymentObject
.INPUTS
    [System.Collections.Hashtable]$DeploymentObject
.OUTPUTS
    [System.Boolean]$CTX.Output
    Indicates whether the deployment was performed successfully.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Start-BasicFolderDeployment {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The deployment object that will be processed.')]
        [System.Collections.Hashtable]$DeploymentObject
    )
    
    begin {
        # VALIDATION - INPUT
        # Validate the DeploymentObject
        Approve-MandatoryHashtable -Hashtable $DeploymentObject -HashtableDescription 'DeploymentObject'

        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            # Input
            DeploymentObject    = $DeploymentObject
            FolderToCopy        = $DeploymentObject.FolderToCopy
            DestinationFolder   = $DeploymentObject.DestinationFolder
            KeepFolderName      = $DeploymentObject.KeepCurrentFolderName
            # Text Handlers
            Text                = @{
                Action          = $DeploymentObject.DeploymentActionInBrackets
                FunctionName    = $DeploymentObject.FunctionNameInBrackets
            }
            # Output
            Output              = $null
        }
    }

    process {
        try {
            # PREPARATION
            # Write the message
            Write-Line "Starting the $($CTX.Text.Action) of the function $($CTX.Text.FunctionName)..." -Type Busy
            # Add the additional properties to the DeploymentObject for easier access
            $CTX.FolderLeafName     = if ($CTX.KeepFolderName) { $CTX.FolderToCopy } else { Get-DeploymentData -PropertyName ApplicationID }
            $CTX.FolderToCopyInto   = Join-Path -Path $CTX.DestinationFolder -ChildPath $CTX.FolderLeafName
            $CTX.FolderToRemove     = $CTX.FolderToCopyInto

            # EXECUTION
            # Switch on the DeploymentAction
            switch ($CTX.DeploymentObject.DeploymentAction ) {
                'Install'   {
                    # PREPARATION
                    # Get the Folder from the source files
                    [System.String]$FolderToCopyPath = Get-SourceItem -FolderName $CTX.FolderToCopy
                    # Copy the folder to the destination path
                    Copy-ItemUDF -ContentOfThisFolder $FolderToCopyPath -IntoThisFolder $CTX.FolderToCopyInto -OutHost
                }
                'Uninstall' {
                    # EXECUTION
                    # Remove the folder
                    Remove-ItemUDF -Path $CTX.FolderToRemove -OutHost
                }
            }

            # RESULT - OUTPUT
            # Set the output to $true to indicate that the deployment was performed successfully
            $CTX.Output = $true
        }
        catch {
            # ERROR HANDLING
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
    }
    
    end {
        # OUTPUT
        # Return the output of the deployment process
        $CTX.Output
    }
}

### END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Tests if a Folder deployment should be performed based on deployment action and installation state.
.DESCRIPTION
    This function resolves the folder from the deployment object, determines whether the folder is already
    deployed, and returns whether the deployment should be performed for the specified action.
.EXAMPLE
    Test-FolderDeploymentRequired -DeploymentObject $MyDeploymentObject
.INPUTS
    [System.Collections.Hashtable]
    [System.String]
.OUTPUTS
    [System.Boolean]
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Test-FolderDeploymentRequired {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The deployment object that will be processed.')]
        [System.Collections.Hashtable]$DeploymentObject
    )

    begin {
        # VALIDATION - INPUT
        # Validate the DeploymentObject
        Approve-MandatoryHashtable -Hashtable $DeploymentObject -HashtableDescription 'DeploymentObject'

        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            # Input
            DeploymentObject    = $DeploymentObject
            FolderToCopy        = $DeploymentObject.FolderToCopy
            DestinationFolder   = $DeploymentObject.DestinationFolder
            KeepFolderName      = $DeploymentObject.KeepCurrentFolderName
            DeploymentAction    = $DeploymentObject.DeploymentAction
            # Text Handlers
            Text                = @{
                Action          = $DeploymentObject.DeploymentActionInBrackets
                FunctionName    = $DeploymentObject.FunctionNameInBrackets
            }
            # Output
            Output                      = $null
        }
    }

    process {
        try {
            # PREPARATION
            # Write the message
            Write-Line "Evaluating if the Deployment should be performed for the action $($CTX.Text.Action) by the function $($CTX.Text.FunctionName)..."
            # Set the FolderToCheck
            [System.String]$FolderLeafName = if ($CTX.KeepFolderName) { $CTX.FolderToCopy } else { Get-DeploymentData -PropertyName ApplicationID -ErrorAction Stop }
            [System.String]$FolderToCheck = Join-Path -Path $CTX.DestinationFolder -ChildPath $FolderLeafName
            # Determine if the Folder is already installed by checking if the folder exists at the destination path
            [System.Boolean]$FolderIsInstalled = Test-Path -Path $FolderToCheck -PathType Container

            # EXECUTION - EVALUATION
            # Evaluate whether deployment should be performed
            [System.Boolean]$FolderDeploymentShouldBePerformed = switch ($CTX.DeploymentAction) {
                'Install'   { if ($FolderIsInstalled) { $false } else { $true } }
                'Uninstall' { if ($FolderIsInstalled) { $true } else { $false } }
            }

            # RESULT - MESSAGE
            # Write the message
            [System.String]$InFix = if ($FolderIsInstalled) { 'IS' } else { 'is NOT' }
            Write-Line "The folder $InFix installed: ($FolderToCheck)."

            # RESULT - OUTPUT
            # Set the output
            $CTX.Output = $FolderDeploymentShouldBePerformed
        }
        catch {
            # ERROR HANDLING
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
    }

    end {
        # OUTPUT
        # Return the output
        $CTX.Output
    }
}

### END OF FUNCTION
####################################################################################################
