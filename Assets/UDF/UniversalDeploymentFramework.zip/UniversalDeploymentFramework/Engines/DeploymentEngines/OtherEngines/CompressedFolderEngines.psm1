#
# Module 'CompressedFolderEngines.psm1'
# Last Update: April 2026
#

####################################################################################################
<#
.SYNOPSIS
    Starts the deployment process for a folder deployment based on the provided deployment object.
.DESCRIPTION
    This function processes a folder deployment by copying a specified folder from the source files to a destination path during installation, and removing the folder during uninstallation.
    The function determines the folder name based on the deployment object properties and performs the necessary file operations accordingly.
.EXAMPLE
    Start-CompressedFolderDeployment -DeploymentObject $DeploymentObject
.INPUTS
    [System.Collections.Hashtable]$DeploymentObject
.OUTPUTS
    [System.Boolean]
    Indicates whether the deployment was performed successfully.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : April 2026
#>
####################################################################################################W
function Start-CompressedFolderDeployment {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The deployment object that will be processed.')]
        [System.Collections.Hashtable]$DeploymentObject
    )

    try {
        # VALIDATION - INPUT
        # Validate the DeploymentObject
        Approve-MandatoryHashtable -Hashtable $DeploymentObject -HashtableDescription 'DeploymentObject'

        # PREPARATION
        # Write the message
        Write-Line "Starting the $($DeploymentObject.DeploymentActionInBrackets) of the function $($DeploymentObject.FunctionNameInBrackets)..."

        # Switch on the DeploymentAction, and return the output of the deployment process
        switch ($DeploymentObject.DeploymentAction ) {
            'Install'   { & $DeploymentObject.InstallFunction -DeploymentObject $DeploymentObject }
            'Uninstall' { & $DeploymentObject.UninstallFunction -DeploymentObject $DeploymentObject }
        }
    }
    catch {
        # ERROR HANDLING
        Write-ErrorReport -ErrorRecord $_
        $PSCmdlet.ThrowTerminatingError($_)
    }
}

### END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Installs a compressed folder based on the provided deployment object.
.DESCRIPTION
    This function processes a folder deployment by copying a specified folder from the source files to a destination path during installation, and removing the folder during uninstallation.
    The function determines the folder name based on the deployment object properties and performs the necessary file operations accordingly.
.EXAMPLE
    Install-CompressedFolder -DeploymentObject $DeploymentObject
.INPUTS
    [System.Collections.Hashtable]$DeploymentObject
.OUTPUTS
    [System.Boolean]$CTX.Output
    Indicates whether the installation was performed successfully.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : April 2026
#>
####################################################################################################
function Install-CompressedFolder {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The deployment object that will be processed.')]
        [System.Collections.Hashtable]$DeploymentObject
    )

    try {
        # VALIDATION - INPUT
        # Validate the DeploymentObject
        Approve-MandatoryHashtable -Hashtable $DeploymentObject -HashtableDescription 'DeploymentObject'

        # PREPARATION
        # Write the message
        Write-Line "Installing the compressed folder (zipfile)... ($($DeploymentObject.FriendlyObjectName))"
        # Create the TemporaryWorkFolder
        [System.String]$TemporaryWorkFolder = New-TemporaryFolderUDF

        # EXECUTION - EXTRACTION
        # Get the ZipFile from the source files
        [System.String]$SourceZipFilePath = Get-SourceItem -FileName $DeploymentObject.ZipFileName
        # Unzip the zip file to the TemporaryWorkFolder
        Expand-ZipFile -ZipFilePath $SourceZipFilePath -IntoThisFolder $TemporaryWorkFolder

        # VALIDATION - TOP FOLDER
        # If the top folder in the zip file SHOULD be skipped
        if ($DeploymentObject.SkipTopFolderInsideZipFile) {
            # Get the number of folders in the TemporaryWorkFolder
            [System.Int32]$NumberOfFolders = (Get-ChildItem -Path $TemporaryWorkFolder -Directory).Count
            # If there are 0 or multiple folders in the TemporaryWorkFolder, throw an error, because there should be only one single TopFolder
            if ($NumberOfFolders -ne 1) {
                throw "There are 0 or multiple folders in the root of the zip file and SkipTopFolderInsideZipFile is set to $true.`nPlease make sure that there is only 1 folder in the root of the zip file. Or set SkipTopFolderInsideZipFile to $false."
            }
        }

        # EXECUTION - COPY CONTENT
        # If the top folder in the zip file SHOULD be skipped
        [System.String]$FolderToCopyContentOf = if ($DeploymentObject.SkipTopFolderInsideZipFile) {
            # Get the TopFolder (which is the only folder in the TemporaryWorkFolder)
            [System.IO.DirectoryInfo]$TopFolderObject = Get-ChildItem -Path $TemporaryWorkFolder -Directory | Select-Object -First 1
            # Copy the content of the TopFolder to the destination path
            Write-Line "One moment please... Skipping the Topfolder ($($TopFolderObject.Name)) and copying the CONTENT of the Topfolder to the destination path. ($($DeploymentObject.DestinationFolder))" -Type Busy
            # Return the path to the TopFolder
            $TopFolderObject.FullName
        }
        # If the top folder in the zip file SHOULD NOT be skipped
        else {
            # Copy the extracted folder directly to the destination path
            Write-Line "One moment please... Copying the content of the extracted folder to the destination path. ($($DeploymentObject.DestinationFolder))" -Type Busy
            $TemporaryWorkFolder
        }
        # Copy the content of the folder to the destination path
        Copy-ItemUDF -ContentOfThisFolder $FolderToCopyContentOf -IntoThisFolder $DeploymentObject.DestinationFolder -OutHost

        # EXECUTION - MARKER FILE
        # Create the Marker file
        New-InstallationMarkerFile -DeploymentObject $DeploymentObject

        # OUTPUT
        # Return $true to indicate that the installation was performed successfully
        $true
    }
    catch {
        # ERROR HANDLING
        Write-ErrorReport -ErrorRecord $_
        $PSCmdlet.ThrowTerminatingError($_)
    }
    finally {
        # CLEANUP
        # Remove the TemporaryWorkFolder
        if (Test-String -IsPopulated $TemporaryWorkFolder) { Remove-ItemUDF -Path $TemporaryWorkFolder -OutHost }
    }

}

### END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Uninstalls a compressed folder based on the provided deployment object.
.DESCRIPTION
    This function processes a folder deployment by removing a specified folder from the destination path during uninstallation.
    The function verifies the installation by checking for a marker file that was created during installation, and performs the necessary file operations accordingly.
.EXAMPLE
    Uninstall-CompressedFolder -DeploymentObject $DeploymentObject
.INPUTS
    [System.Collections.Hashtable]$DeploymentObject
.OUTPUTS
    [System.Boolean]
    Indicates whether the uninstallation was performed successfully.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Uninstall-CompressedFolder {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The deployment object that will be processed.')]
        [System.Collections.Hashtable]$DeploymentObject
    )

    try {
        # VALIDATION - INPUT
        # Validate the DeploymentObject
        Approve-MandatoryHashtable -Hashtable $DeploymentObject -HashtableDescription 'DeploymentObject'

        # EXECUTION
        # Remove the folder, and return output of the removal process to the stream
        Write-Line "Uninstalling the compressed folder ($($DeploymentObject.FriendlyObjectName)) by removing the installation folder ($($DeploymentObject.DestinationFolder))" -Type Busy
        Remove-ItemUDF -Path $DeploymentObject.DestinationFolder -PassThru
    }
    catch {
        # ERROR HANDLING
        Write-ErrorReport -ErrorRecord $_
        $PSCmdlet.ThrowTerminatingError($_)
    }

}

### END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Expands a zip file to a specified destination folder.
.DESCRIPTION
    This function expands a zip file to a specified destination folder. It validates the input parameters, performs the extraction using the .NET method, and verifies the extraction by checking the contents of the destination folder.
.EXAMPLE
    Expand-ZipFile -ZipFilePath $ZipFilePath -IntoThisFolder $DestinationFolder
.INPUTS
    [System.String]$ZipFilePath
    The path to the compressed folder (zip file) that should be expanded.
    [System.String]$IntoThisFolder
    The destination path where the compressed folder should be expanded to.
.OUTPUTS
    No objects are returned to the pipeline. All operational output is written to the host and logged to the deployment logfile.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : April 2026
    Last Update     : April 2026
#>
####################################################################################################
function Expand-ZipFile {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The path to the compressed folder (zip file) that should be expanded.')]
        [System.String]$ZipFilePath,

        [Parameter(Mandatory=$true,HelpMessage='The destination path where the compressed folder should be expanded to.')]
        [System.String]$IntoThisFolder
    )

    try {
        # VALIDATION - INPUT
        # Validate the input parameters
        Approve-MandatoryPath -Path $ZipFilePath -PathDescription 'ZipFilePath'
        Approve-MandatoryString -String $IntoThisFolder -StringDescription 'IntoThisFolder'
        
        # EXECUTION - EXTRACTION
        # Unzip the zip file using the DotNet method. (This prevents a GUI, which prevents errors when installing from an SCCM Task Sequence)
        [System.String]$FolderToExtractTo = $IntoThisFolder
        Write-Line "One moment please... Extracting the zipfile ($ZipFilePath) to the folder ($FolderToExtractTo)" -Type Busy
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        [System.IO.Compression.ZipFile]::ExtractToDirectory($ZipFilePath,$FolderToExtractTo)

        # VALIDATION - EXTRACTION
        # Check if the extraction was successful by checking if there are any files or folders in the destination folder
        [System.Object[]]$ExtractedItems = Get-ChildItem -Path $FolderToExtractTo
        if (-not $ExtractedItems) {
            throw "No files or folders were found in the folder ($FolderToExtractTo). The extraction of the zip file ($ZipFilePath) failed."
        }
    }
    catch {
        # ERROR HANDLING
        Write-ErrorReport -ErrorRecord $_
        $PSCmdlet.ThrowTerminatingError($_)
    }
}

### END OF FUNCTION
####################################################################################################
