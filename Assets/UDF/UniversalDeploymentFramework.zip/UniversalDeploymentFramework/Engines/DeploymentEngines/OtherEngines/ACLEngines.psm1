#
# Module 'ACLEngines.psm1'
# Last Update: March 2026
#

####################################################################################################
<#
.SYNOPSIS
    Resets the Access Control List (ACL) of a specified folder to match its parent folder.
.DESCRIPTION
    This function resets the Access Control List (ACL) of a specified folder to match its parent folder. It provides options to use icacls, return the output, and write the output to the host.
.EXAMPLE
    Reset-ACL -Path "C:\MyFolder" -UseIcacls -OutHost
.INPUTS
    [System.String]
    [System.Management.Automation.SwitchParameter]
.OUTPUTS
    [System.Boolean]
    A boolean value indicating whether the ACL reset operation was successful, returned when using -PassThru
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Reset-ACL {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$true,Position=0,HelpMessage='The path of the item for which the ACL will be reset.')]
        [System.String]$Path,

        [Parameter(Mandatory=$false,HelpMessage='Switch for using icacls instead of PowerShell.')]
        [System.Management.Automation.SwitchParameter]$UseIcacls,

        [Parameter(Mandatory=$false,HelpMessage='Switch for returning the output.')]
        [System.Management.Automation.SwitchParameter]$PassThru,

        [Parameter(Mandatory=$false,HelpMessage='Switch for writing the output to the host.')]
        [System.Management.Automation.SwitchParameter]$OutHost
    )
    
    begin {
        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            FullName    = $Path
            ParentPath  = Split-Path -Path $Path -Parent
            LeafName    = Split-Path -Path $Path -Leaf
            Output      = $null
        }
    }
    
    process {
        try {
            # VALIDATION - INPUT
            # Validate the Path
            Approve-MandatoryPath -Path $CTX.FullName -PathDescription 'Path' -ErrorAction Stop

            # VALIDATION - ACL
            # Compare the two ACL's
            if (Compare-AclToParent -Path $CTX.FullName -PassThru -OutHost) {
                Write-Line "The ACL of the Childfolder ($($CTX.LeafName)) is the same as the Parentfolder. ($($CTX.ParentPath))"
                Write-Line "No action has been taken."
                $CTX.Output = $true
                Return
            } else {
                Write-Line "The ACL of the Childfolder ($($CTX.LeafName)) is NOT the same as the Parentfolder. ($($CTX.ParentPath))"
            }

            # VALIDATION - ICACLS EXECUTABLE
            # Validate if icacls is present on the local system
            if ($UseIcacls.IsPresent) {
                # Set the icacls Fallback Path
                [System.String]$IcaclsFallbackPath = Get-SystemPath -Name Icacls -ErrorAction Stop
                # Get the icacls command information
                [System.Management.Automation.ApplicationInfo]$IcaclsCommandObject = Get-Command icacls -ErrorAction SilentlyContinue
                # Validate that the icacls command was found
                [System.String]$IcaclsPath = if (-Not($IcaclsCommandObject)) {
                    # Fallback to the hardcoded path to icacls
                    Write-Line "The command 'icacls' can not be found via the Get-Command method. Falling back to the hardcoded path. ($IcaclsFallbackPath)" -Type Warning
                    $IcaclsFallbackPath
                } else {
                    # If the icacls command was found, write the message
                    Write-Line "The command 'icacls' was found. Using the following icacls-executable: ($($IcaclsCommandObject.Path))"
                    $IcaclsCommandObject.Path
                }
                # If icacls is not present at all, fallback to using PowerShell's Set-Acl cmdlet
                if (-Not($IcaclsPath)) {
                    Write-Line "The switch to use icacls is specified but icacls is not found. Falling back to using PowerShell's Set-Acl cmdlet." -Type Warning
                    $UseIcacls.IsPresent = $false
                }
            }

            # EXECUTION
            # Reset the ACL of the folder to that of the parent folder
            if ($UseIcacls.IsPresent) {
                # Use icacls to reset the ACL so it will inherit from the parent
                Write-Line "Resetting the permissions using icacls, so the ACL of the Parentfolder will be inherited... ($($CTX.ParentPath))" -Type Busy
                Start-Process -FilePath $IcaclsPath -ArgumentList "`"$($CTX.FullName)`" /reset /t /c /q"
            } else {
                # Use powershell to set the ACL to that of the parent
                Write-Line "Equalizing the permissions using Set-Acl, to the ACL of the Parentfolder... ($($CTX.ParentPath))" -Type Busy
                [System.Security.AccessControl.DirectorySecurity]$AclObjectOfParentFolder = Get-Acl -Path $($CTX.ParentPath)
                Set-Acl -Path $($CTX.FullName) -AclObject $AclObjectOfParentFolder
            }

            # RESULT
            # Compare the two ACL's
            if (Compare-AclToParent -Path $CTX.FullName -PassThru -OutHost) {
                Write-Line "Successfully reset the ACL for the item: ($($CTX.FullName))."
                $CTX.Output = $true
                Return
            } else {
                Write-Line "Failed to reset the ACL for the item: ($($CTX.FullName))." -Type Fail
                throw [System.Management.Automation.RuntimeException]
            }
        }
        catch [System.Management.Automation.RuntimeException] {
            Write-Line "A runtime error has occurred." -Type Fail
            $PSCmdlet.ThrowTerminatingError($_)
        }
        catch {
            Write-Line "Failed to reset the ACL for the item: ($($CTX.FullName))." -Type Fail
            Write-ErrorReport -ErrorRecord $_
        }
    }
    
    end {
        # OUTPUT
        # Return the result of the reset operation if PassThru is specified
        if ($PassThru) { $CTX.Output }
    }
}

# END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Compares the Access Control List (ACL) of a folder to the ACL of its parent folder.
.DESCRIPTION
    This function compares the ACL of a specified folder to the ACL of its parent folder.
    It returns $true if the ACLs are equal (the folder inherits permissions from its parent), or $false if they differ.
.EXAMPLE
    Compare-AclToParent -Path 'C:\Demo\MyNewFolder'
    Compares the ACL of the folder to its parent and returns the result.
.EXAMPLE
    Compare-AclToParent -Path 'C:\Program Files\MyApplication' -OutHost
    Compares the ACL and writes the comparison details to the host.
.INPUTS
    [System.String]$Path
    A string representing the path to the folder for which the ACL will be compared.
.OUTPUTS
    [System.Boolean]
    A boolean value indicating whether the ACL of the folder matches its parent folder, returned when using -PassThru.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : December 2025
    Last Update     : March 2026
#>
####################################################################################################
function Compare-AclToParent {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$true,Position=0,HelpMessage='The folder of which the ACL will be checked.')]
        [System.String]$Path,

        [Parameter(Mandatory=$false,HelpMessage='Switch for returning the output.')]
        [System.Management.Automation.SwitchParameter]$PassThru,

        [Parameter(Mandatory=$false,HelpMessage='Switch for writing the output to the host.')]
        [System.Management.Automation.SwitchParameter]$OutHost
    )

    begin {
        # PREPARATION - INPUT
        # Set the folder object
        [System.Collections.Hashtable]$FolderObject = @{
            FullName    = $Path
            ParentPath  = Split-Path -Path $Path -Parent
            LeafName    = Split-Path -Path $Path -Leaf
        }

        # PREPARATION - OUTPUT
        # Set the output
        [System.Boolean]$AclsAreEqual = $false
    }
    
    process {
        try {
            # VALIDATION - FOLDER
            # Validate that the folder exists
            if (-not (Test-Path -Path $FolderObject.FullName -PathType Container)) {
                Write-Line "The folder can not be reached: ($($FolderObject.FullName))" -Type Fail ; return
            }

            # EXECUTION
            # Get the ACLs of the parent and child folders
            Write-Line "Comparing the ACL of the folder ($($FolderObject.LeafName)) to its parent folder ($($FolderObject.ParentPath))."
            [System.Security.AccessControl.AuthorizationRuleCollection]$AclOfParentFolder   = (Get-Acl -Path $FolderObject.ParentPath).Access
            [System.Security.AccessControl.AuthorizationRuleCollection]$AclOfChildFolder    = (Get-Acl -Path $FolderObject.FullName).Access
            
            # Compare the two ACLs
            [System.Object[]]$ComparisonResult = Compare-Object -ReferenceObject $AclOfParentFolder -DifferenceObject $AclOfChildFolder
            
            # Determine if the ACLs are equal
            if ($null -eq $ComparisonResult) {
                Write-Line "The ACL of the folder ($($FolderObject.LeafName)) is the same as the parent folder ($($FolderObject.ParentPath))."
                $AclsAreEqual = $true
            } else {
                Write-Line "The ACL of the folder ($($FolderObject.LeafName)) is NOT the same as the parent folder ($($FolderObject.ParentPath))."
                $AclsAreEqual = $false
            }
        }
        catch {
            Write-Line "Failed to compare the ACL for the folder: ($($FolderObject.FullName))." -Type Fail
            Write-ErrorReport -ErrorRecord $_
        }
    }
    
    end {
        # OUTPUT
        # Return the result of the comparison if PassThru is specified
        if ($PassThru) { $AclsAreEqual }
    }
}

# END OF FUNCTION
####################################################################################################
