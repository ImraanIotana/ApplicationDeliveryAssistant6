#
# Module 'RegistryEngines.psm1'
# Last Update: March 2026
#

####################################################################################################
<#
.SYNOPSIS
    Pauses the deployment process for a specified number of seconds.
.DESCRIPTION
    This function pauses the deployment process based on the 'SecondsToPause' property of the deployment object.
    It checks if the deployment is required and then executes a pause for the specified duration.
.EXAMPLE
    Start-PauseDeployment -DeploymentObject $DeploymentObject
.INPUTS
    [System.Collections.Hashtable]
.OUTPUTS
    [System.Boolean]
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Start-REGFileDeployment {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The deployment object that will be processed.')]
        [System.Collections.Hashtable]$DeploymentObject
    )
    
    begin {
        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            DeploymentObject        = $DeploymentObject
            AlsoRemoveParentKeys    = $DeploymentObject.AlsoRemoveParentKeys
            Output                  = $null
        }
    }

    process {
        try {
            # PREPARATION
            # If the action is Uninstall, then inverse the content of the REG file
            if ($CTX.DeploymentObject.DeploymentAction -eq 'Uninstall') {

                # Make a copy of the original REG file and inverse its content
                Write-Line "Inversing the content of the REG file for uninstallation: $($CTX.DeploymentObject.REGFileName)"
                [System.String]$RegFilePath         = Get-SourceItem -FileName $CTX.DeploymentObject.REGFileName -ErrorAction Stop
                [System.String]$InversedRegFilePath = New-InversedREGFile -Path $RegFilePath -InverseParentKeys:$CTX.AlsoRemoveParentKeys -PassThru -ErrorAction Stop
                [System.String]$InversedRegFileName = Split-Path -Path $InversedRegFilePath -Leaf

                # Update the deployment object to use the inversed REG file for uninstallation
                $CTX.DeploymentObject.REGFileName = $InversedRegFileName
            }

            # EXECUTION
            # Import the REG file
            Write-Line "Calling Import-REGFile to import the REG file: $($CTX.DeploymentObject.REGFileName)"
            $CTX.Output = Import-REGFile -DeploymentObject $CTX.DeploymentObject -ErrorAction Stop
        }
        catch {
            # ERROR HANDLING
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
        
    }
    
    end {
        # OUTPUT
        # Return the output of the deployment process
        $CTX.Output
    }
}

### END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    This function imports a registry file (.reg) to the local system.
.DESCRIPTION
    The function takes a deployment object as input, which contains the name of the registry file to be imported. 
    It retrieves the path to the REG executable, constructs the command-line arguments, and executes the import operation. 
    The function returns a boolean value indicating the success or failure of the import process.
.EXAMPLE
    Import-REGFile -DeploymentObject $DeploymentObject
.INPUTS
    [System.Collections.Hashtable]$DeploymentObject
.OUTPUTS
    [System.Boolean]$CTX.Output
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Import-REGFile {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The deployment object that will be processed.')]
        [System.Collections.Hashtable]$DeploymentObject
    )
    
    begin {
        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            DeploymentObject    = $DeploymentObject
            REGExecutable       = Get-SystemPath -Name REGExecutable
            ArgumentPreFix      = 'import "{0}"'
            Output              = $null
        }
    }

    process {
        try {
            # PREPARATION
            # Add the source file to the context
            $CTX.SourceREGFilePath = Get-SourceItem -FileName $CTX.DeploymentObject.REGFileName -ErrorAction Stop

            # VALIDATION
            # Get the content of the original REG file
            [System.String[]]$REGFileContentLines = Get-Content $CTX.SourceREGFilePath -Encoding Unicode -ErrorAction Stop
            # If the content is empty, throw an error
            if ($REGFileContentLines.Length -eq 0) { throw "The content of the REG file is empty: $($CTX.SourceREGFilePath)" }
            # If the first line does not start with the expected header, throw an error
            if (-not $REGFileContentLines[0].StartsWith('Windows Registry Editor Version 5.00')) { throw "The content of the REG file is not valid. The first line should start with 'Windows Registry Editor Version 5.00': $($CTX.SourceREGFilePath)" }

            # EXECUTION
            # Execute the REG command to import the registry file
            Write-Line "Importing registry file: $($CTX.SourceREGFilePath)"
            $CTX.ArgumentList = $CTX.ArgumentPreFix -f $CTX.SourceREGFilePath
            $CTX.Output = Start-Executable -Path $CTX.REGExecutable -ArgumentList $CTX.ArgumentList -SuccessExitCodes @(0) -ErrorAction Stop
        }
        catch {
            # ERROR HANDLING
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
        
    }
    
    end {
        # OUTPUT
        # Return the output of the deployment process
        $CTX.Output
    }
}

### END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    This function creates an inversed REG file by inversing the content of the original REG file.
.DESCRIPTION
    The function takes the path of the original REG file as input and creates a new REG file with inversed content. 
    It processes each line of the original REG file, inversing parent keys and item properties based on the specified parameters. 
    The resulting inversed REG file can be used for uninstallation purposes.
.EXAMPLE
    New-InversedREGFile -Path "C:\Path\To\Original.reg" -InverseParentKeys
.EXAMPLE
    New-InversedREGFile -Path "C:\Path\To\Original.reg" -PassThru
.INPUTS
    [System.String]$Path,
    [System.Management.Automation.SwitchParameter]$InverseParentKeys
.OUTPUTS
    [System.String]$CTX.OutputPath
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function New-InversedREGFile {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The path of the REG file to be inversed.')]
        [System.String]$Path,
        
        [Parameter(Mandatory=$false,HelpMessage='Indicates whether to inverse the parent keys.')]
        [System.Management.Automation.SwitchParameter]$InverseParentKeys,

        [Parameter(Mandatory=$false,HelpMessage='Indicates whether to return the path of the inversed REG file.')]
        [System.Management.Automation.SwitchParameter]$PassThru
    )
    
    begin {
        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            Path    = $Path
            Output  = [System.String]::Empty
        }
        # Write the message
        Write-Line "Creating an inversed REG file by inversing the content of the original REG file: $($CTX.Path)"
    }
    
    process {
        try {
            # VALIDATION
            # Validate the input
            Approve-MandatoryPath -Path $CTX.Path -PathDescription 'Path' -ErrorAction Stop

            # PREPARATION - OUTPUT PATH
            # Set the output path for the inversed REG file by keeping the same directory as the original REG file and adding a suffix to its name
            [System.String]$OriginalDirectory   = Split-Path -Path $CTX.Path -Parent
            [System.String]$InversedREGFileName = ("{0}_Inversed.reg" -f (Get-Item -Path $CTX.Path).BaseName)
            [System.String]$InversedREGFilePath = Join-Path -Path $OriginalDirectory -ChildPath $InversedREGFileName

            # PREPARATION - CONTENT
            # Get the content of the original REG file
            [System.String[]]$REGFileContentLines = Get-Content $CTX.Path -Encoding Unicode -ErrorAction Stop

            # VALIDATION - CONTENT
            # If the content is empty, throw an error
            if ($REGFileContentLines.Length -eq 0) { throw "The content of the REG file is empty: $($CTX.Path)" }
            # If the first line does not start with the expected header, throw an error
            if (-not $REGFileContentLines[0].StartsWith('Windows Registry Editor Version 5.00')) { throw "The content of the REG file is not valid. The first line should start with 'Windows Registry Editor Version 5.00': $($CTX.Path)" }

            # EXECUTION
            # Process each line to create the content for the undo REG file
            [System.String[]]$InversedLines = foreach ($CurrentLine in $REGFileContentLines) {

                # PREPARATION - SKIP LINES
                # Test if the line can be skipped
                [System.Boolean]$LineCanBeSkipped = if ( ($CurrentLine.StartsWith('Windows Registry Editor')) ) { $true }
                elseif (Test-String -IsEmpty $CurrentLine) { $true }
                else { $false }
                # If the line can be skipped, write it as is, and continue to the next line
                if ($LineCanBeSkipped) { $CurrentLine ; continue }


                # EXECUTION - PARENT KEY LINES
                # Test if the line is a parent key (if it starts with [ and ends with ])
                if ( ($CurrentLine.StartsWith('[HKEY_') -and $CurrentLine.EndsWith(']')) ) {
                    # If the InverseParentKeys switch is present, inverse the parent key by replacing the root key with a dash (-) and keeping the subkey
                    if ($InverseParentKeys.IsPresent) {
                        # Create the new line with a dash as root key and the same subkey
                        [System.String]$InversedParentKey = $CurrentLine.Replace('[HKEY_', '[-HKEY_')
                        # Write the new line and continue to the next line
                        $InversedParentKey ; continue
                    }
                    else {
                        # Else write the line as is, and continue to the next line
                        $CurrentLine ; continue
                    }
                }

                # EXECUTION - ITEM PROPERTY LINES
                # Test if the line is an item property line (if it starts with a quote and contains an equal sign)
                if ( ($CurrentLine.TrimStart().StartsWith('"') -and $CurrentLine.Contains('=')) ) {

                    # If the InverseParentKeys switch is present
                    if ($InverseParentKeys.IsPresent) {
                        # Skip the line (do not include it in the output REG file)
                        continue
                    } else {
                        # Split the line
                        [System.String[]]$LineParts = $CurrentLine.Split('=')
                        [System.String]$FirstPart   = $LineParts[0]
                        [System.String]$ValueName   = $FirstPart.Trim()

                        # Create the new line with the value name and a dash as value data
                        "$ValueName=-" ; continue
                    }

                } else {
                    # If the line is not an item property line, write it as is
                    $CurrentLine ; continue
                }
            }

            # RESULT
            # Write the content to the output REG file
            $InversedLines | Set-Content $InversedREGFilePath -Encoding Unicode -ErrorAction Stop
            # Set the output path in the context
            $CTX.Output = $InversedREGFilePath
            # Write the message
            Write-Line "Successfully created the inversed REG file with inversed content at: $InversedREGFilePath"
        }
        catch {
            # ERROR HANDLING
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
    }
    
    end {
        # OUTPUT
        # Return the path of the created inversed REG file
        if ($PassThru.IsPresent) { $CTX.Output }
    }
}

### END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Tests if a path is a valid registry path.
.DESCRIPTION
    This function validates whether a path targets the registry provider and has valid registry path syntax.
    It returns $true when valid and $false when invalid.
.EXAMPLE
    Test-PathIsRegistryPath -Path "HKLM:\SOFTWARE\MyCompany\MyApp"
    Returns $true when the path format is valid for the registry provider.
.INPUTS
    [System.String]
.OUTPUTS
    [System.Boolean]
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : April 2026
#>
####################################################################################################
function Test-PathIsRegistryPath {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The path that will be tested.')]
        [AllowEmptyString()][System.String]$Path
    )

    begin {
        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            PathToTest  = $Path
            Output      = $false
        }
    }

    process {
        try {
            # VALIDATION
            # Reject empty or whitespace-only paths
            if ([System.String]::IsNullOrWhiteSpace($CTX.PathToTest)) {
                $CTX.Output = $false
                return
            }

            # VALIDATION
            # Ensure the path starts with a supported registry root
            [System.Boolean]$HasSupportedRegistryRoot = if ( ($CTX.PathToTest -match '^(HKLM|HKCU|HKCR|HKU|HKCC):\\') -or ($CTX.PathToTest -match '^Registry::HKEY_(LOCAL_MACHINE|CURRENT_USER|CLASSES_ROOT|USERS|CURRENT_CONFIG)\\') ) { $true }
            else { $false }

            if (-not $HasSupportedRegistryRoot) {
                $CTX.Output = $false
                return
            }

            # RESULT
            # Validate provider path syntax
            $CTX.Output = [System.Boolean](Test-Path -Path $CTX.PathToTest -IsValid)
        }
        catch {
            # ERROR HANDLING
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
    }

    end {
        # OUTPUT
        # Return true when valid, false otherwise
        $CTX.Output
    }
}

### END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Creates a new registry key at a specified path.
.DESCRIPTION
    This function creates a new registry key at a specified path. It also provides options to return the output and write the output to the host.
.EXAMPLE
    New-RegistryKeyUDF -Path "HKLM:\SOFTWARE\MyCompany\MyApp" -OutHost
    Creates the specified registry key and writes the output to the host.
.INPUTS
    [System.String]
    [System.Management.Automation.SwitchParameter]
.OUTPUTS
    [System.Boolean]
    A boolean value indicating whether the create operation was successful, returned when using -PassThru
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function New-RegistryKeyUDF {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$true,Position=0,HelpMessage='The registry path where the new key will be created.')]
        [System.String]$Path,

        [Parameter(Mandatory=$false,HelpMessage='Hashtable of properties to add to the registry key.')]
        [System.Collections.Hashtable]$AddProperties,

        [Parameter(Mandatory=$false,HelpMessage='Switch for removing the existing registry key if it exists.')]
        [System.Management.Automation.SwitchParameter]$RemoveExistingKey,

        [Parameter(Mandatory=$false,HelpMessage='Switch for returning the output.')]
        [System.Management.Automation.SwitchParameter]$PassThru
    )

    try {
        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            RegistryKey         = $Path
            PropertiesToSet     = $AddProperties
            RegistryKeyExists   = { [System.Boolean](Test-Path -Path $Path) }
            RemoveExistingKey   = $RemoveExistingKey
            Output              = $null
        }
Write-Object $Path
        # VALIDATION
        <# Validate that the provided path is a valid registry path before creating the key
        Approve-MandatoryString -String $CTX.RegistryKey -StringDescription 'Path' -ErrorAction Stop
        if (-not (Test-PathIsRegistryPath -Path $CTX.RegistryKey -ErrorAction Stop)) {
            throw "The provided Path ($($CTX.RegistryKey)) is not a valid registry path. Use a path like 'HKLM:\\SOFTWARE\\MyCompany\\MyApp' or 'Registry::HKEY_LOCAL_MACHINE\\SOFTWARE\\MyCompany\\MyApp': $($CTX.RegistryKey)."
        }#>

        # EXECUTION - REMOVE EXISTING REGISTRY KEY IF SPECIFIED
        # If the registry key already exists and RemoveExistingKey is specified, remove the existing registry key
        if (& $CTX.RegistryKeyExists -and $CTX.RemoveExistingKey) {
            Write-Line "The registry key already exists. Removing existing key: ($($CTX.RegistryKey))."
            Remove-ItemUDF -Path $CTX.RegistryKey -OutHost
            Write-Line "Successfully removed the existing registry key: ($($CTX.RegistryKey))."
        }

        # EXECUTION - CREATE REGISTRY KEY
        # If the registry key does not exist, create it
        if (& $CTX.RegistryKeyExists) {
            Write-Line "The registry key already exists. ($($CTX.RegistryKey))"
        } else {
            # Create the registry key
            Write-Line "Creating the registry key: ($($CTX.RegistryKey))."
            New-Item -Path $CTX.RegistryKey -Force -ErrorAction Stop | Out-Null
            Write-Line "Successfully created the registry key: ($($CTX.RegistryKey))."
        }

        # EXECUTION - ADD PROPERTIES
        # Create the properties for the registry key based on the AddProperties hashtable
        if ($CTX.PropertiesToSet) {
            foreach ($Property in $CTX.PropertiesToSet.GetEnumerator()) {
                Write-Line "Adding the following property: ($($Property.Key) = $($Property.Value))."
                Set-ItemProperty -Path $CTX.RegistryKey -Name $Property.Key -Value $Property.Value -Force -ErrorAction Stop
            }
        }

        # RESULT
        # Set the output to $true
        $CTX.Output = $true

        # OUTPUT
        # Return the output
        if ($PassThru) { $CTX.Output }
    }
    catch [System.UnauthorizedAccessException] {
        Write-Line "Failed to create or remove the registry key. Access is denied. ($($CTX.RegistryKey))." -Type Fail
        $PSCmdlet.ThrowTerminatingError($_)
    }
    catch [System.Security.SecurityException] {
        if ($Property.Key) {
            Write-Line "Failed to create or remove the Property ($($Property.Key) = $($Property.Value)). Access is denied. ($($CTX.RegistryKey))." -Type Fail
        } else {
            Write-Line "Failed to create or remove the registry key. Access is denied. ($($CTX.RegistryKey))." -Type Fail
        }
        $PSCmdlet.ThrowTerminatingError($_)
    }
    catch [System.Management.Automation.ItemNotFoundException] {
        Write-Line "Failed to create or remove the Property ($($Property.Key) = $($Property.Value)). The specified path was not found: ($($CTX.RegistryKey))." -Type Fail
        $PSCmdlet.ThrowTerminatingError($_)
    }
    catch {
        #Write-Line "Failed to create or remove the registry key: ($($CTX.RegistryKey))." -Type Fail
        Write-ErrorReport -ErrorRecord $_
        $PSCmdlet.ThrowTerminatingError($_)
    }
}

# END OF FUNCTION
####################################################################################################
