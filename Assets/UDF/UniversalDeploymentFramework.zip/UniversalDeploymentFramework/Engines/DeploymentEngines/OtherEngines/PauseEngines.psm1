#
# Module 'PauseEngines.psm1'
# Last Update: March 2026
#

####################################################################################################
<#
.SYNOPSIS
    Pauses the deployment process for a specified number of seconds.
.DESCRIPTION
    This function pauses the deployment process based on the 'SecondsToPause' property of the deployment object.
    It checks if the deployment is required and then executes a pause for the specified duration.
.EXAMPLE
    Start-PauseDeployment -DeploymentObject $DeploymentObject
.INPUTS
    [System.Collections.Hashtable]
.OUTPUTS
    [System.Boolean]
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Start-PauseDeployment {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The deployment object that will be processed.')]
        [System.Collections.Hashtable]$DeploymentObject
    )
    
    begin {
        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            DeploymentObject    = $DeploymentObject
            Output              = $null
        }
    }

    process {
        try {
            # EXECUTION
            # Execute the pause
            [System.Int32]$SecondsToPause = $CTX.DeploymentObject.SecondsToPause
            Write-Line "Pausing for ($SecondsToPause) seconds. One moment please..." -Type Busy
            Start-Sleep -Seconds $SecondsToPause
            $CTX.Output = $true
        }
        catch {
            # ERROR HANDLING
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
        
    }
    
    end {
        # OUTPUT
        # Return the output of the deployment process
        $CTX.Output
    }
}

### END OF FUNCTION
####################################################################################################
