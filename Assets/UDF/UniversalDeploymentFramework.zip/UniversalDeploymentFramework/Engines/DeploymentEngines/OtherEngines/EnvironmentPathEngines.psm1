#
# Module 'EnvironmentPathEngines.psm1'
# Last Update: March 2026
#

####################################################################################################
<#
.SYNOPSIS
    Pauses the deployment process for a specified number of seconds.
.DESCRIPTION
    This function pauses the deployment process based on the 'SecondsToPause' property of the deployment object.
    It checks if the deployment is required and then executes a pause for the specified duration.
.EXAMPLE
    Start-PauseDeployment -DeploymentObject $DeploymentObject
.INPUTS
    [System.Collections.Hashtable]
.OUTPUTS
    [System.Boolean]
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Start-EnvironmentPathDeployment {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The deployment object that will be processed.')]
        [System.Collections.Hashtable]$DeploymentObject
    )
    
    begin {
        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            DeploymentObject    = $DeploymentObject
            DirectoryToProcess  = ConvertTo-TrimmedPath -Path $DeploymentObject.Directory -OutHost
            Output              = $null
        }
    }

    process {
        try {
            # EXECUTION
            # Switch based on the deployment action
            $CTX.Output = switch ($CTX.DeploymentObject.DeploymentAction) {
                'Install'   { Add-EnvironmentPath -Directory $CTX.DirectoryToProcess -PassThru -OutHost }
                'Uninstall' { Remove-EnvironmentPath -Directory $CTX.DirectoryToProcess -PassThru -OutHost }
            }
        }
        catch {
            # ERROR HANDLING
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
        
    }
    
    end {
        # OUTPUT
        # Return the output of the deployment process
        $CTX.Output
    }
}

### END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Adds a specified directory to the environment variable PATH for a given scope (User or System).
.DESCRIPTION
    This function adds a specified directory to the PATH environment variable for either the User or System scope.
    It first retrieves the current PATH variable, checks if the directory is already included, and if not, it appends the directory to the PATH variable.
.EXAMPLE
    Add-EnvironmentPath -Directory 'C:\MyApp\Bin' -Scope 'User'
    This command adds 'C:\MyApp\Bin' to the User PATH environment variable if it is not already present.
.EXAMPLE
    Add-EnvironmentPath -Directory 'C:\MyApp\Bin' -Scope 'System'
    This command adds 'C:\MyApp\Bin' to the System PATH environment variable if it is not already present.
.INPUTS
    [System.String]
.OUTPUTS
    [System.Boolean]$CTX.Output - Indicates whether the specified directory is included in the environment variable PATH.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Add-EnvironmentPath {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The directory path to be added to the environment variable.')]
        [System.String]$Directory,

        [Parameter(Mandatory=$false,HelpMessage='The scope of the environment variable.')]
        [ValidateSet('User','Machine')]
        [System.String]$Scope = 'Machine',

        [Parameter(Mandatory=$false,HelpMessage='Switch for returning the output.')]
        [System.Management.Automation.SwitchParameter]$PassThru,

        [Parameter(Mandatory=$false,HelpMessage='Switch for writing the output to the host.')]
        [System.Management.Automation.SwitchParameter]$OutHost
    )
    
    begin {
        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            DirectoryToAdd  = ConvertTo-TrimmedPath -Path $Directory
            Scope           = $Scope
            Output          = $null
        }
        # Write the message
        if ($OutHost) { Write-Line "Adding the directory to the ($($CTX.Scope)) environment variable PATH. ($($CTX.DirectoryToAdd))" }
    }
    
    process {
        try {
            # PREPARATION
            # Get the current environment path based on the scope
            [System.String]$CurrentEnvironmentPath = switch ($CTX.Scope) {
                'User'      { Get-UserPath -Name EnvironmentVariablePATH }
                'Machine'   { Get-SystemPath -Name EnvironmentVariablePATH }
            }

            # PREPARATION - VALIDATION
            # Check if the directory is already included in the environment path
            if (Test-EnvironmentPath -Directory $CTX.DirectoryToAdd -Scope $CTX.Scope) {
                if ($OutHost) { Write-Line "The directory is already included in the ($($CTX.Scope)) environment variable PATH. ($($CTX.DirectoryToAdd))" }
                $CTX.Output = $true
                return
            }

            # PREPARATION - SET NEW ENVIRONMENT PATH
            # Add the directory to the environment path
            [System.String]$NewEnvironmentPath = "$CurrentEnvironmentPath;$($CTX.DirectoryToAdd)"

            # EXECUTION
            # Set the new environment path, and catch any errors related to administrative privileges
            try {
                [System.Environment]::SetEnvironmentVariable('PATH', $NewEnvironmentPath, $CTX.Scope)
            }
            catch [System.Management.Automation.MethodInvocationException] {
                throw "The directory could not be added to the environment variable PATH. Please check if you have Administrative privileges. ($($CTX.DirectoryToAdd))"
            }
            
            # RESULT
            # Set the output to true, and write the message to the host
            if ($OutHost) { Write-Line "The directory was successfully added to the ($($CTX.Scope)) environment variable PATH. ($($CTX.DirectoryToAdd))" }
            $CTX.Output = $true
        }
        catch {
            # ERROR HANDLING
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
    }
    
    end {
        # OUTPUT
        # Return whether the directory was added to the environment path
        if ($PassThru) { $CTX.Output }
    }
}

### END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Removes a specified directory from the environment variable PATH for a given scope (User or System).
.DESCRIPTION
    This function removes a specified directory from the PATH environment variable for either the User or System scope.
    It retrieves the current PATH variable, checks if the directory exists in PATH, and if found, removes it and updates
    the environment variable.
.EXAMPLE
    Remove-EnvironmentPath -Directory 'C:\MyApp\Bin' -Scope 'User'
    This command removes 'C:\MyApp\Bin' from the User PATH environment variable if it is present.
.EXAMPLE
    Remove-EnvironmentPath -Directory 'C:\MyApp\Bin' -Scope 'System'
    This command removes 'C:\MyApp\Bin' from the System PATH environment variable if it is present.
.INPUTS
    [System.String]
.OUTPUTS
    [System.Boolean]$CTX.Output - Indicates whether the specified directory is not present in the environment variable PATH.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Remove-EnvironmentPath {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The directory path to be removed from the environment variable.')]
        [System.String]$Directory,

        [Parameter(Mandatory=$false,HelpMessage='The scope of the environment variable.')]
        [ValidateSet('User','Machine')]
        [System.String]$Scope = 'Machine',

        [Parameter(Mandatory=$false,HelpMessage='Switch for returning the output.')]
        [System.Management.Automation.SwitchParameter]$PassThru,

        [Parameter(Mandatory=$false,HelpMessage='Switch for writing the output to the host.')]
        [System.Management.Automation.SwitchParameter]$OutHost
    )

    begin {
        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            DirectoryToRemove   = ConvertTo-TrimmedPath -Path $Directory
            Scope               = $Scope
            Output              = $null
        }
        # Write the message
        if ($OutHost) { Write-Line "Removing the directory from the ($($CTX.Scope)) environment variable PATH. ($($CTX.DirectoryToRemove))" }
    }

    process {
        try {
            # PREPARATION
            # Get the current environment path based on the scope
            [System.String]$CurrentEnvironmentPath = switch ($CTX.Scope) {
                'User'      { Get-UserPath -Name EnvironmentVariablePATH }
                'Machine'   { Get-SystemPath -Name EnvironmentVariablePATH }
            }
            # Split the environment path into individual paths
            [System.String[]]$PathEntries = $CurrentEnvironmentPath.Split(';')

            # PREPARATION - VALIDATION
            # Check if the directory is already absent from the environment path
            if (-not (Test-EnvironmentPath -Directory $CTX.DirectoryToRemove -Scope $CTX.Scope)) {
                if ($OutHost) { Write-Line "The directory is already absent from the ($($CTX.Scope)) environment variable PATH. ($($CTX.DirectoryToRemove))" }
                $CTX.Output = $true
                return
            }

            # PREPARATION - SET NEW ENVIRONMENT PATH
            # Remove all exact matches of the directory from PATH and write the updated value
            [System.String[]]$UpdatedPathEntries = $PathEntries | Where-Object {
                ($_ -ne '') -and ($_ -ne $CTX.DirectoryToRemove)
            }
            [System.String]$NewEnvironmentPath = ($UpdatedPathEntries -join [System.IO.Path]::PathSeparator)

            # EXECUTION
            # Set the new environment path, and catch any errors related to administrative privileges
            try {
                [System.Environment]::SetEnvironmentVariable('PATH', $NewEnvironmentPath, $CTX.Scope)
            }
            catch [System.Management.Automation.MethodInvocationException] {
                throw "The directory could not be removed from the environment variable PATH. Please check if you have Administrative privileges. ($($CTX.DirectoryToRemove))"
            }
            
            # RESULT
            # Set the output to true, and write the message to the host
            if ($OutHost) { Write-Line "The directory was successfully removed from the ($($CTX.Scope)) environment variable PATH. ($($CTX.DirectoryToRemove))" }
            $CTX.Output = $true
        }
        catch {
            # ERROR HANDLING
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
    }

    end {
        # OUTPUT
        # Return whether the directory was removed from the environment path
        if ($PassThru) { $CTX.Output }
    }
}

### END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Tests whether a specified directory is included in the environment variable PATH.
.DESCRIPTION
    This function checks if a given directory is present in the PATH environment variable for the specified scope (User or System).
    It retrieves the current PATH variable, splits it into individual paths, and checks for the presence of the specified directory.
.EXAMPLE
    Test-EnvironmentPath -Directory 'C:\MyApp\Bin' -Scope 'User'
    This command checks if 'C:\MyApp\Bin' is included in the User PATH environment variable and returns $true or $false accordingly.
.INPUTS
    [System.String]
.OUTPUTS
    [System.Boolean]$CTX.Output - Indicates whether the specified directory is included in the environment variable PATH.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Test-EnvironmentPath {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The directory path to be tested in the environment variable.')]
        [System.String]$Directory,

        [Parameter(Mandatory=$false,HelpMessage='The scope of the environment variable.')]
        [ValidateSet('User','Machine')]
        [System.String]$Scope = 'User',

        [Parameter(Mandatory=$false,HelpMessage='Switch for writing the output to the host.')]
        [System.Management.Automation.SwitchParameter]$OutHost
    )
    
    begin {
        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            DirectoryToTest = ConvertTo-TrimmedPath -Path $Directory
            Scope           = $Scope
            Output          = $null
        }
        # Write the message
        if ($OutHost) { Write-Line "Testing whether the directory is included in the ($($CTX.Scope)) environment variable PATH. ($($CTX.DirectoryToTest))" }
    }
    
    process {
        try {
            # PREPARATION
            # Get the current environment path based on the scope
            [System.String]$CurrentEnvironmentPath = switch ($CTX.Scope) {
                'User'      { Get-UserPath -Name EnvironmentVariablePATH }
                'Machine'   { Get-SystemPath -Name EnvironmentVariablePATH }
            }
            # Split the environment path into individual paths
            [System.String[]]$PathEntries = $CurrentEnvironmentPath.Split([System.IO.Path]::PathSeparator)

            # EXECUTION
            # Check if the specified directory is included in the environment path
            $CTX.Output = ($PathEntries -contains $CTX.DirectoryToTest)

            # RESULT
            # Write the result to the host
            $InFix = if ($CTX.Output) { 'IS' } else { 'IS NOT' }
            if ($OutHost) { Write-Line "The directory $InFix included in the ($($CTX.Scope)) environment variable PATH. ($($CTX.DirectoryToTest))" }

        }
        catch {
            # ERROR HANDLING
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }

    }
    
    end {
        # OUTPUT
        # Return whether the directory is in the environment path
        $CTX.Output
    }
}

### END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Tests if an environment path deployment should be performed based on deployment action and installation state.
.DESCRIPTION
    This function resolves the environment path from the deployment object, determines whether the path is already
    included in the environment variable PATH, and returns whether the deployment should be performed for the specified action.
.EXAMPLE
    Test-EnvironmentPathDeploymentRequired -DeploymentObject $MyDeploymentObject
.INPUTS
    [System.Collections.Hashtable]
    [System.String]
.OUTPUTS
    [System.Boolean]$CTX.Output
    Indicates whether the environment path deployment should be performed based on the deployment action and installation state.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Test-EnvironmentPathDeploymentRequired {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The deployment object that will be processed.')]
        [System.Collections.Hashtable]$DeploymentObject
    )

    begin {
        # VALIDATION - INPUT
        # Validate the DeploymentObject
        Approve-MandatoryHashtable -Hashtable $DeploymentObject -HashtableDescription 'DeploymentObject'

        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            # Input
            DeploymentObject    = $DeploymentObject
            DirectoryToTest     = ConvertTo-TrimmedPath -Path $DeploymentObject.Directory
            DeploymentAction    = $DeploymentObject.DeploymentAction
            # Text Handlers
            Text                = @{
                Action          = $DeploymentObject.DeploymentActionInBrackets
                FunctionName    = $DeploymentObject.FunctionNameInBrackets
            }
            # Output
            Output              = $null
        }
    }

    process {
        try {
            # PREPARATION - MESSAGE
            # Write the message
            Write-Line "Evaluating if the Deployment should be performed for the action $($CTX.Text.Action) by the function $($CTX.Text.FunctionName)..."

            # VALIDATION - BOOLEAN
            # If the RemoveDuringUninstall boolean is set to False, and if the deployment action is Uninstall
            if ($CTX.DeploymentAction -eq 'Uninstall') {
                if ($CTX.DeploymentObject.RemoveDuringUninstall -eq $false) {
                    # Set the output to false, write the message to the host, and return
                    Write-Line "The RemoveDuringUninstall boolean is set to False, so the Environment Path will NOT be removed during UNINSTALL. ($($CTX.DirectoryToTest))."
                    $CTX.Output = $false
                    return
                }
            }

            # PREPARATION
            # Test if the environment path contains the directory specified in the deployment object
            [System.Boolean]$EnvironmentPathContainsDirectory = Test-EnvironmentPath -Directory $CTX.DirectoryToTest -Scope Machine -OutHost

            # EXECUTION - EVALUATION
            # Evaluate whether deployment should be performed
            [System.Boolean]$EnvironmentPathDeploymentShouldBePerformed = switch ($CTX.DeploymentAction) {
                'Install'   { if ($EnvironmentPathContainsDirectory) { $false } else { $true } }
                'Uninstall' { if ($EnvironmentPathContainsDirectory) { $true } else { $false } }
            }

            # OUTPUT
            # Set the output
            $CTX.Output = $EnvironmentPathDeploymentShouldBePerformed
        }
        catch {
            # ERROR HANDLING
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
    }

    end {
        # OUTPUT
        # Return the output
        $CTX.Output
    }
}

### END OF FUNCTION
####################################################################################################
