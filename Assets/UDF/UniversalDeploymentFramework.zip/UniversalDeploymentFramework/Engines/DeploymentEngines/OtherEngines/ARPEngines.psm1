#
# Module 'ARPEngines.psm1'
# Last Update: March 2026
#

####################################################################################################
<#
.SYNOPSIS
    Pauses the deployment process for a specified number of seconds.
.DESCRIPTION
    This function pauses the deployment process based on the 'SecondsToPause' property of the deployment object.
    It checks if the deployment is required and then executes a pause for the specified duration.
.EXAMPLE
    Start-PauseDeployment -DeploymentObject $DeploymentObject
.INPUTS
    [System.Collections.Hashtable]
.OUTPUTS
    [System.Boolean]
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Start-ARPEntryDeployment {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The deployment object that will be processed.')]
        [System.Collections.Hashtable]$DeploymentObject
    )
    
    begin {
        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            DeploymentObject    = $DeploymentObject
            ARPParentPath       = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall'
            Output              = $null
        }
    }

    process {
        try {
            # PREPARATION
            # Get the ApplicationID from the DeploymentData and add it to the context
            $CTX.ApplicationID = Get-DeploymentData -PropertyName ApplicationID
            # Add the Application ARP Registry Key to the DeploymentObject
            $CTX.DeploymentObject.ApplicationARPRegistryKey = Join-Path -Path $CTX.ARPParentPath -ChildPath $CTX.ApplicationID

            # EXECUTION
            # Switch on the DeploymentAction
            $CTX.Output = switch ($CTX.DeploymentObject.DeploymentAction) {
                'Install'   { Install-ARPEntry -DeploymentObject $CTX.DeploymentObject -ErrorAction Stop }
                'Uninstall' { Uninstall-ARPEntry -DeploymentObject $CTX.DeploymentObject -ErrorAction Stop }
            }
        }
        catch [System.UnauthorizedAccessException] {
            $PSCmdlet.ThrowTerminatingError($_)
        }
        catch [System.Security.SecurityException] {
            $PSCmdlet.ThrowTerminatingError($_)
        }
        catch [System.Management.Automation.RuntimeException] {
            Write-Line "A runtime error has occurred." -Type Fail
            $PSCmdlet.ThrowTerminatingError($_)
        }
        catch {
            Write-ErrorReport -ErrorRecord $_
        }
        
    }
    
    end {
        # OUTPUT
        # Return the output of the deployment process
        $CTX.Output
    }
}

### END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Installs an ARP Entry for the application being deployed, based on the properties provided in the deployment object.
.DESCRIPTION
    This function installs an ARP Entry by creating it in the system's Add/Remove Programs (ARP) registry key, based on the parameters provided in the deployment object.
.EXAMPLE
    Install-ARPEntry -DeploymentObject $DeploymentObject
.INPUTS
    [System.Collections.Hashtable]$DeploymentObject
    The deployment object that will be processed. This object should contain the necessary properties for creating the ARP entry, such as DisplayName, DisplayVersion, PublisherName, DisplayIconFileName, and QuietUninstallString.
.OUTPUTS
    [System.Boolean]$DeploymentSuccess
    A boolean value indicating whether the deployment was successful or not.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Install-ARPEntry {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The deployment object that will be processed.')]
        [System.Collections.Hashtable]$DeploymentObject
    )

    begin {
        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            DeploymentObject        = $DeploymentObject
            DisplayName             = $DeploymentObject.DisplayName
            DisplayIconFileName     = $DeploymentObject.DisplayIconFileName
            QuietUninstallString    = $DeploymentObject.QuietUninstallString
            HideOriginalARPEntries  = $DeploymentObject.HideOriginalARPEntries
            ApplicationID           = Get-DeploymentData -PropertyName ApplicationID
            DefaultIcon             = 'shell32.dll,15'
            Output                  = $null
        }
    }

    process {
        try {
            # PREPARATION - ICON
            # If a DisplayIconFileName is provided, add the DisplayIcon path to the context
            $CTX.DisplayIconPath = if ($CTX.DisplayIconFileName) {
                Get-SourceItem -FileName $CTX.DisplayIconFileName -ErrorAction Stop
            } else {
                # If no DisplayIconFileName is provided, use the default icon
                $CTX.DefaultIcon
            }

            # PREPARATION - UNINSTALLSTRING
            # Set the UninstallString to the QuietUninstallString if it is provided, else set it to use this deployment framework with the -Uninstall switch.
            $CTX.UninstallString = if ($CTX.QuietUninstallString) {
                $CTX.QuietUninstallString
            } else {
                [System.String]$PowershellPath = Get-SystemPath -Name PowerShell64
                "$PowershellPath -ExecutionPolicy Bypass -File `"$($Global:DeploymentObject.Rootfolder)\Start-Deployment.ps1`" -Uninstall"
            }

            # PREPARATION - PROPERTIES
            # Set the properties for the ARP Entry based on the DeploymentObject
            [System.Collections.Hashtable]$PropertiesHashTable = @{
                DisplayName     = if ($CTX.DisplayName) { $CTX.DisplayName } else { $CTX.ApplicationID }
                DisplayVersion  = $CTX.DeploymentObject.DisplayVersion
                Publisher       = $CTX.DeploymentObject.PublisherName
                DisplayIcon     = $CTX.DisplayIconPath
                UninstallString = $CTX.UninstallString
            }

            # EXECUTION
            # Create the Registry Key for the ARP Entry with the specified properties
            New-RegistryKeyUDF -Path $CTX.DeploymentObject.ApplicationARPRegistryKey -AddProperties $PropertiesHashTable -RemoveExistingKey -ErrorAction Stop

            # HIDE ORIGINAL ARP ENTRIES
            # Hide ARP entries for the same application if specified in the deployment object
            if (Test-Array -IsPopulated $CTX.HideOriginalARPEntries) { $CTX.HideOriginalARPEntries | ForEach-Object { Hide-ARPEntry -DisplayName $_ -ErrorAction Stop } }

            # RESULT
            # Set the output to true
            $CTX.Output = $true
        }
        catch [System.UnauthorizedAccessException] {
            $PSCmdlet.ThrowTerminatingError($_)
        }
        catch [System.Security.SecurityException] {
            $PSCmdlet.ThrowTerminatingError($_)
        }
        catch [System.Management.Automation.RuntimeException] {
            Write-Line "A runtime error has occurred." -Type Fail
            $PSCmdlet.ThrowTerminatingError($_)
        }
        catch {
            Write-ErrorReport -ErrorRecord $_
        }
    }

    end{
        # OUTPUT
        # Return the output
        $CTX.Output
    }
}

# END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Uninstalls an ARP Entry for the application being deployed.
.DESCRIPTION
    This function uninstalls an ARP Entry by removing it from the system's Add/Remove Programs (ARP) registry key.
.EXAMPLE
    Uninstall-ARPEntry -DeploymentObject $DeploymentObject
.INPUTS
    [System.Collections.Hashtable]$DeploymentObject
    The deployment object that will be processed. This object should contain the necessary properties for removing the ARP entry.
.OUTPUTS
    [System.Boolean]$DeploymentSuccess
    A boolean value indicating whether the uninstallation was successful or not.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Uninstall-ARPEntry {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The deployment object that will be processed.')]
        [System.Collections.Hashtable]$DeploymentObject
    )

    begin {
        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            DeploymentObject        = $DeploymentObject
            HideOriginalARPEntries  = $DeploymentObject.HideOriginalARPEntries
            Output                  = $null
        }
    }

    process {
        try {
            # EXECUTION - SHOW ORIGINAL ARP ENTRIES
            # Show ARP entries for the same application if specified in the deployment object (in case they were hidden during installation)
            if (Test-Array -IsPopulated $CTX.HideOriginalARPEntries) { $CTX.HideOriginalARPEntries | ForEach-Object { Show-ARPEntry -DisplayName $_ -ErrorAction Stop } }

            # EXECUTION - REMOVE ARP ENTRY
            # Remove the Registry Key for the ARP Entry
            [System.String]$ARPRegistryKeyPath = $CTX.DeploymentObject.ApplicationARPRegistryKey
            $CTX.Output = Remove-ItemUDF -Path $ARPRegistryKeyPath -PassThru -OutHost -ErrorAction Stop
        }
        catch {
            Write-Line "The Entry for Add/Remove Programs could not be removed. ($ARPRegistryKeyPath)" -Type Fail
        }
    }

    end{
        # OUTPUT
        # Return the output
        $CTX.Output
    }
}

# END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Hides an ARP Entry for a specified application by setting the 'SystemComponent' registry value to 1.
.DESCRIPTION
    This function searches for an ARP entry with the specified display name in both 64-bit and 32-bit ARP registry paths.
    If the entry is found, it sets the 'SystemComponent' registry value to 1, which hides the entry from the Add/Remove Programs list.
.EXAMPLE
    Hide-ARPEntry -DisplayName 'WebViewer'
    This command will search for an ARP entry with the display name 'WebViewer' and hide it from the Add/Remove Programs list if found.
.INPUTS
    [System.String]$DisplayName
    The display name of the application whose ARP entry will be hidden. This should match the 'DisplayName' property of the ARP entry that you want to hide.
.OUTPUTS
    No objects are returned to the pipeline. All operational output is written to the host and logged to the deployment logfile.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Hide-ARPEntry {
    [CmdletBinding()]
    [OutputType([System.Void])]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The display name of the application whose ARP entry will be hidden.')]
        [System.String]$DisplayName
    )
    
    begin {
        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            DisplayName = $DisplayName
            ARPPaths    = Get-SystemPath -Name AddRemoveProgramsRegistryPaths
        }
    }
    
    process {
        # EXECUTION
        try {
            # Search for the ARP entry with the specified display name in both 64-bit and 32-bit ARP registry paths
            foreach ($ARPPath in $CTX.ARPPaths) {
                $ARPEntry = Get-ChildItem -Path $ARPPath -ErrorAction SilentlyContinue | Get-ItemProperty -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -eq $CTX.DisplayName }
                if ($ARPEntry) {
                    # If the ARP entry is found, set the 'SystemComponent' registry value to 1 to hide it from the Add/Remove Programs list
                    Set-ItemProperty -Path $ARPEntry.PSPath -Name 'SystemComponent' -Value 1 -Type DWord -ErrorAction Stop
                    Write-Line "The ARP entry for ($($CTX.DisplayName)) has been hidden in the registry path ($ARPPath)."
                    [System.Boolean]$ItemFoundAndHidden = $true
                }
            }
            # If no ARP entry was found and hidden, write a warning message to the host
            if (-not $ItemFoundAndHidden) {
                Write-Line "No ARP entry was found with the display name ($($CTX.DisplayName)) in any of the ARP registry paths. Please verify the display name and try again." -Type Warning
            }
        }
        catch [System.UnauthorizedAccessException] {
            $PSCmdlet.ThrowTerminatingError($_)
        }
        catch [System.Management.Automation.RuntimeException] {
            Write-Line "A runtime error has occurred." -Type Fail
            $PSCmdlet.ThrowTerminatingError($_)
        }
        catch {
            Write-ErrorReport -ErrorRecord $_
        }
    }
    
    end {
    }
}

# END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Shows an ARP Entry for a specified application by setting the 'SystemComponent' registry value to 0.
.DESCRIPTION
    This function searches for an ARP entry with the specified display name in both 64-bit and 32-bit ARP registry paths.
    If the entry is found, it sets the 'SystemComponent' registry value to 0, which shows the entry in the Add/Remove Programs list.
.EXAMPLE
    Show-ARPEntry -DisplayName 'WebViewer'
    This command will search for an ARP entry with the display name 'WebViewer' and show it in the Add/Remove Programs list if found.
.INPUTS
    [System.String]$DisplayName
    The display name of the application whose ARP entry will be shown. This should match the 'DisplayName' property of the ARP entry that you want to show.
.OUTPUTS
    No objects are returned to the pipeline. All operational output is written to the host and logged to the deployment logfile.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Show-ARPEntry {
    [CmdletBinding()]
    [OutputType([System.Void])]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The display name of the application whose ARP entry will be shown.')]
        [System.String]$DisplayName
    )
    
    begin {
        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            DisplayName = $DisplayName
            ARPPaths    = Get-SystemPath -Name AddRemoveProgramsRegistryPaths
        }
    }
    
    process {
        # EXECUTION
        try {
            # Search for the ARP entry with the specified display name in both 64-bit and 32-bit ARP registry paths
            foreach ($ARPPath in $CTX.ARPPaths) {
                $ARPEntry = Get-ChildItem -Path $ARPPath -ErrorAction SilentlyContinue | Get-ItemProperty -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -eq $CTX.DisplayName }
                if ($ARPEntry) {
                    # If the ARP entry is found, set the 'SystemComponent' registry value to 0 to show it in the Add/Remove Programs list
                    Set-ItemProperty -Path $ARPEntry.PSPath -Name 'SystemComponent' -Value 0 -Type DWord -ErrorAction Stop
                    Write-Line "The ARP entry for ($($CTX.DisplayName)) has been shown in the registry path ($ARPPath)."
                    [System.Boolean]$ItemFoundAndShown = $true
                }
            }
            # If no ARP entry was found and shown, write a warning message to the host
            if (-not $ItemFoundAndShown) {
                Write-Line "No ARP entry was found with the display name ($($CTX.DisplayName)) in any of the ARP registry paths. Please verify the display name and try again." -Type Warning
            }
        }
        catch [System.UnauthorizedAccessException] {
            $PSCmdlet.ThrowTerminatingError($_)
        }
        catch [System.Management.Automation.RuntimeException] {
            Write-Line "A runtime error has occurred." -Type Fail
            $PSCmdlet.ThrowTerminatingError($_)
        }
        catch {
            Write-ErrorReport -ErrorRecord $_
        }
    }
    
    end {
    }
}

# END OF FUNCTION
####################################################################################################

