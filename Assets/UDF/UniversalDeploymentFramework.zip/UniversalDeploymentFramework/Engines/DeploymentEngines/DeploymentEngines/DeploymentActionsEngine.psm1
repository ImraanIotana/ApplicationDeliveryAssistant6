#
# Module 'DeploymentActionsEngine.psm1'
# Last Update: March 2026
#

####################################################################################################
<#
.SYNOPSIS
    Starts the main Deployment Process.
.DESCRIPTION
    This function serves as the main entry point for the Deployment Process. It takes the file path to the deployment objects .psd1 file as input, imports the deployment data, validates it, and then processes each deployment object accordingly.
    The deployment objects are expected to be defined in a .psd1 file as a hashtable with a key named 'DeploymentObjects' that holds an array of deployment objects to be processed.
    Each deployment object should have a 'Type' property that indicates the type of deployment action to be performed, along with any other necessary properties required for that action.
.EXAMPLE
    Start-MainDeploymentProcess -DeploymentObjectsFilePath $DeploymentObjectsFilePath
.INPUTS
    [System.String]$DeploymentObjectsFilePath
    A string representing the file path to the deployment objects .psd1 file that will be used for processing.
    The .psd1 file must contain a hashtable with a key named 'DeploymentObjects' that holds an array of deployment objects to be processed.
.OUTPUTS
    No objects are returned to the pipeline. All operational output is written to the host and logged to the deployment logfile.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : February 2026
    Last Update     : March 2026
#>
####################################################################################################

function Start-MainDeploymentProcess {
    [CmdletBinding()]
    [OutputType([System.Void])]
    param (
        [Parameter(Mandatory=$false,HelpMessage='The path to the deployment data file that will be used for processing.')]
        [AllowEmptyString()][AllowNull()][System.String]$DeploymentDataFilePath
    )

    begin {
    }

    process {
        try {
            # PREPARATION - IMPORT
            # Import the Deployment Data (This action needs to happen before all else, as the deployment data contains all the necessary information for the Deployment Process)
            Import-DeploymentData -DeploymentDataFilePath $DeploymentDataFilePath -ErrorAction Stop

            # PREPARATION - ADMINISTRATION
            # Start the preparation for the Deployment Process, such as starting the logging and global timer, and setting up the work folders
            Start-DeploymentPreparation

            # PREPARATION - DEPLOYMENT CONTEXT
            # Get the DeploymentContext hashtable
            [System.Collections.Hashtable]$DeploymentContext = Get-DeploymentContext

            # VALIDATION - DEPLOYMENT OBJECTS
            # Validate the Deployment Objects in the DeploymentContext, and update the DeploymentContext
            [System.Collections.Hashtable]$CTX = Start-MainDeploymentValidation -DeploymentContext $DeploymentContext -ErrorAction Stop

            # EXECUTION - DEPLOYMENT OBJECTS
            # Process each DeploymentObject  
            Write-DeploymentMessage -DeploymentContext $CTX -Type StartingMessage  
            foreach ($DeploymentObject in $CTX.DeploymentObjects) {

                # PREPARATION
                # Write the message to the host
                Write-DeploymentMessage -DeploymentContext $CTX -Type DeployingObjectMessage

                # EXECUTION - DEPLOY THE OBJECT
                # Deploy the object
                [System.Boolean]$DeploymentSuccess = Start-SingleObjectDeployment -DeploymentObject $DeploymentObject -ErrorAction Stop
                # Add the result to the ResultArray
                [System.Void]($CTX.DeploymentResults.Add($DeploymentSuccess))

                # TESTING - VERIFY DEPLOYMENT SUCCESS
                # Test the output of the Deployment Process for the current DeploymentObject
                if ($DeploymentSuccess) {
                    # Write the success message
                    Write-DeploymentMessage -DeploymentContext $CTX -Type DeploymentSuccessMessage
                    # Increment the counter
                    $CTX.DeploymentObjectCounter++
                }
                else {
                    # Break the Deployment Process
                    break
                }
            }

            # FINAL RESULT
            # Test if all results in the ResultArray are true, and set the final result in the DeploymentContext
            $CTX.FinalDeploymentResult = (Test-ArrayContainsOnlyTrue -Array $CTX.DeploymentResults)
            # Write the final result
            Write-DeploymentMessage -DeploymentContext $CTX -Type FinalResultMessage
            # Add the final result to the DeploymentObject for later use in the finalization function (such as writing the deployment report to the registry)
            [System.String]$DeploymentResult = if ($CTX.FinalDeploymentResult) { 'SUCCESS' } else { 'FAIL' }
            Add-ToGlobalDeploymentObject -Name DeploymentResult -Value $DeploymentResult
        }
        catch [System.Management.Automation.RuntimeException] {
            # Return to properly stop the logging and global timer, and write the deployment report to the registry
            Write-Line "A Runtime Exception has occurred. The Deployment has been halted. Finalizing the process..." -Type Fail
            return
        }
        catch {
            # Write the error to the host and continue, to properly stop the logging and global timer, and write the deployment report to the registry
            Write-ErrorReport -ErrorRecord $_
        }
    }
    
    end {
        # FINALIZATION
        # Start the finalization for the Deployment Process, such as stopping the logging and global timer
        try {
            Start-DeploymentFinalization -ErrorAction Stop
        }
        catch [System.Management.Automation.RuntimeException] {
            Write-Line "Failed to finalize the Deployment Process. A Runtime Exception has occurred." -Type Fail
        }
        catch {
            Write-ErrorReport -ErrorRecord $_
        }
    }
}

# END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Starts the Deployment Process for a given deployment data file.
.DESCRIPTION
    This function serves as the main entry point for the Deployment Process. It takes the file path to the deployment data .psd1 file as input, imports the deployment data, validates it, and then processes each deployment object accordingly.
    The deployment data is expected to be defined in a .psd1 file as a hashtable with various keys that hold necessary information for the Deployment Process, including a key named 'DeploymentObjects' that holds an array of deployment objects to be processed.
    Each deployment object should have a 'Type' property that indicates the type of deployment action to be performed, along with any other necessary properties required for that action.
.EXAMPLE
    Start-SingleObjectDeployment -DeploymentObject $DeploymentObject
.INPUTS
    [System.Collections.Hashtable]$DeploymentObject
    A hashtable representing the deployment object that will be processed. The deployment object is expected to have a 'Type' property that indicates the type of deployment action to be performed, along with any other necessary properties required for that action.
.OUTPUTS
    No objects are returned to the pipeline. All operational output is written to the host and logged to the deployment logfile.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Start-SingleObjectDeployment {
    [CmdletBinding()]
    [OutputType([System.Void])]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The deployment object that will be processed.')]
        [System.Collections.Hashtable]$DeploymentObject
    )

    try {
        # VALIDATION - INPUT
        # Validate the DeploymentObject
        Approve-MandatoryHashtable -Hashtable $DeploymentObject -HashtableDescription 'DeploymentObject'

        # VALIDATION - EVALUATE DEPLOYMENT REQUIREMENT
        # If the deployment is not required, return true, and skip the deployment process for this object
        if (-not (Test-DeploymentRequired -DeploymentObject $DeploymentObject)) { return $true }

        # EXECUTION
        # If the DeploymentObject has a DeploymentFunction property
        if ($DeploymentObject.ContainsKey('DeploymentFunction')) {
            # Deploy the object using the specified DeploymentFunction, and return the output to the stream
            & $DeploymentObject.DeploymentFunction -DeploymentObject $DeploymentObject
        } else {
            # Otherwise switch on the DeploymentAction to select the appropriate function, and return the output to the stream
            switch ($DeploymentObject.DeploymentAction ) {
                'Install'   { & $DeploymentObject.InstallFunction   -DeploymentObject $DeploymentObject }
                'Uninstall' { & $DeploymentObject.UninstallFunction -DeploymentObject $DeploymentObject }
            }
        }
    }
    catch [System.Management.Automation.RuntimeException] {
        $PSCmdlet.ThrowTerminatingError($_)
    }
    catch [System.ArgumentException] {
        $PSCmdlet.ThrowTerminatingError($_)
    }
    catch [System.UnauthorizedAccessException] {
        $PSCmdlet.ThrowTerminatingError($_)
    }
    catch {
        # ERROR HANDLING
        Write-ErrorReport -ErrorRecord $_
        $PSCmdlet.ThrowTerminatingError($_)
    }
}

# END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Performs the necessary preparations before starting the Deployment Process.
.DESCRIPTION
    This function performs the necessary preparations before starting the Deployment Process.
    Such as starting the global timer, initializing logging, and setting up the source files and work folders.
.EXAMPLE
    Start-DeploymentPreparation
.INPUTS
    None. The function does not take any input parameters.
.OUTPUTS
    No objects are returned to the pipeline. All operational output is written to the host and logged to the deployment logfile.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Start-DeploymentPreparation {
    [CmdletBinding()]
    [OutputType([System.Void])]
    param (
    )

    begin {
    }

    process {
        # Start the logging process
        Start-Logging -ErrorAction Stop
        # Set the SourceFilesFolder based on the DeploymentData
        Set-SourceFilesFolder
        # Set the Workfolder for the Deployment Process
        Set-WorkFolder
        # Start the global timer for the Deployment Process
        Start-GlobalTimer
    }
    
    end {
    }
}

# END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Finalizes the Deployment Process by performing necessary cleanup actions.
.DESCRIPTION
    This function performs the necessary cleanup actions after the Deployment Process.
    Such as stopping the global timer, finalizing logging, and cleaning up the work folders.
.EXAMPLE
    Start-DeploymentFinalization
.INPUTS
    None. The function does not take any input parameters.
.OUTPUTS
    No objects are returned to the pipeline. All operational output is written to the host and logged to the deployment logfile.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Start-DeploymentFinalization {
    [CmdletBinding()]
    [OutputType([System.Void])]
    param (
    )

    begin {
    }

    process {
        try {
            # Stop the global timer and report elapsed time
            Stop-GlobalTimer
            # Write the deployment report to the registry
            Write-DeploymentReport -ErrorAction Stop
            # End the logging process
            Stop-Logging
            # Wait 5 seconds
            [System.Int32]$SecondsToWait = 0
            Write-Line "Waiting for $SecondsToWait seconds to ensure all processes are finished..."
            Start-Sleep -Seconds $SecondsToWait
        }
        catch [System.Management.Automation.RuntimeException] {
            $PSCmdlet.ThrowTerminatingError($_)
        }
        catch {
            # ERROR HANDLING
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
    }
    
    end {
    }
}

# END OF FUNCTION
####################################################################################################
