#
# Module 'DeploymentGetEngine.psm1'
# Last Update: March 2026
#

####################################################################################################
<#
.SYNOPSIS
    Returns a source item (file or directory) used in the Deployment Process.
.DESCRIPTION
    This function searches for a specified file or folder in the source files folder and its subfolders, and returns the full path of the item if found.
    It also handles cases where the item is not found or when multiple items with the same name are found.
.EXAMPLE
    Get-SourceItem -FileName 'ApplicationInstaller.exe'
    This command searches for a file named 'ApplicationInstaller.exe' in the source files folder and its subfolders, and returns the object if found.
.EXAMPLE
    Get-SourceItem -FileName 'ApplicationInstaller.exe' -AsPath
    This command searches for a file named 'ApplicationInstaller.exe' in the source files folder and its subfolders, and returns the full path of the file if found.
.EXAMPLE
    Get-SourceItem -FolderName 'ApplicationFiles' -FolderToSearch 'C:\CustomSourceFiles' -AsPath
    This command searches for a folder named 'ApplicationFiles' in the 'C:\CustomSourceFiles' folder and its subfolders, and returns the full path of the folder if found.
.INPUTS
    [System.String]$FileName - The name of the file to search for.
    [System.String]$FolderName - The name of the folder to search for.
    [System.String]$FolderToSearch - The path of the folder to search in. If not specified, it defaults to the SourceFilesFolder defined in the DeploymentData.
    [System.Management.Automation.SwitchParameter]$AsPath - A switch that indicates whether to return only the path of the item.
.OUTPUTS
    [System.String] The full path of the found item.
    [System.Object] The found item object if the -AsObject switch is used.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Get-SourceItem {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true,ParameterSetName='SearchFileName',HelpMessage='The name of the file of which the object will be obtained.')]
        [AllowEmptyString()][System.String]$FileName,

        [Parameter(Mandatory=$true,ParameterSetName='SearchFolder',HelpMessage='The name of the folder of which the object will be obtained.')]
        [AllowEmptyString()][System.String]$FolderName,

        [Parameter(Mandatory=$false,HelpMessage='The name of the folder to search.')]
        [AllowEmptyString()][System.String]$FolderToSearch = (Get-DeploymentData -PropertyName SourceFilesFolder),

        [Parameter(Mandatory=$false,HelpMessage='Returns the object instead of the full path.')]
        [System.Management.Automation.SwitchParameter]$AsObject
    )

    begin {
        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            FileName            = $FileName
            FolderName          = $FolderName
            FolderToSearch      = $FolderToSearch
            AsObject            = $AsObject
            ParameterSetName    = $PSCmdlet.ParameterSetName
            Output              = [System.Object]$null
        }
    }

    process {
        try {
            # VALIDATION - INPUT
            # Validate the input based on the ParameterSetName
            switch ($CTX.ParameterSetName) {
                'SearchFileName'    { Approve-MandatoryString -String $CTX.FileName -StringDescription 'FileName' -ErrorAction Stop }
                'SearchFolder'      { Approve-MandatoryString -String $CTX.FolderName -StringDescription 'FolderName' -ErrorAction Stop }
            }

            # VALIDATION - FOLDER TO SEARCH
            # Validate the FolderToSearch
            Approve-MandatoryPath -Path $CTX.FolderToSearch -PathDescription 'FolderToSearch' -ErrorAction Stop

            # PREPARATION - ITEMTYPE
            # Add the ItemType used for the lines, and for the Get-ChildItem parameter
            $CTX.ItemType = switch ($CTX.ParameterSetName) {
                'SearchFileName'    { 'file' }
                'SearchFolder'      { 'directory' }
            }

            # PREPARATION - ITEM TO FIND
            # Add the ItemToFind
            $CTX.ItemToFind = switch ($CTX.ParameterSetName) {
                'SearchFileName'    { $CTX.FileName }
                'SearchFolder'      { $CTX.FolderName }
            }

            # PREPARATION - SEARCH
            # Set the search parameters for Get-ChildItem based on the context
            [System.Collections.Hashtable]$SearchParameters = @{
                Path                        = $CTX.FolderToSearch
                Filter                      = $CTX.ItemToFind
                Recurse                     = $true
                ErrorAction                 = 'SilentlyContinue'
            }
            # Add the ItemType to the search parameters, which is either 'file' or 'directory', to help Get-ChildItem to find the correct item
            $SearchParameters[$CTX.ItemType] = $true

            # EXECUTION - SEARCH
            # Search for the item in the source files folder
            Write-Line "Searching for the $($CTX.ItemType) ($($CTX.ItemToFind)) in the folder ($($CTX.FolderToSearch)) and all subfolders..."
            [System.Object[]]$FoundItems = Get-ChildItem @SearchParameters

            # RESULT
            # Switch on the amount of found items
            switch ($FoundItems.Count) {
                0 {
                    # Throw an error if 0 items were found
                    throw "The $($CTX.ItemType) ($($CTX.ItemToFind)) was not found in the folder ($($CTX.FolderToSearch)) or any subfolders."
                }
                1 {
                    # If 1 was found, then return the item
                    [System.Object]$ItemToReturn = $FoundItems[0]
                    Write-Line "The $($CTX.ItemType) was found. The full path is: ($($ItemToReturn.FullName))"
                }
                default {
                    # If multiple items were found, then throw an error
                    $FoundItems | ForEach-Object { Write-Line "Found $($CTX.ItemType): ($($_.FullName))" -Type Fail }
                    throw "More than 1 $($CTX.ItemType) with the name ($($CTX.ItemToFind)) were found. Please make sure the item is unique."
                }
            }
        }
        catch {
            # ERROR HANDLING
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
    }

    end {
        # OUTPUT
        # If the $AsObject switch is used, return the object
        if ($AsObject -and $ItemToReturn) { $ItemToReturn }
        # Otherwise, return the full path
        else { $ItemToReturn.FullName }
    }
}

# END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Gets the deployment context for the current deployment process.
.DESCRIPTION
    Returns a hashtable containing the deployment context for the current deployment process, including information such as the application ID, build number, deployment action, deployment objects, and counters.
.EXAMPLE
    $DeploymentContext = Get-DeploymentContext
.INPUTS
    None. The function does not take any input parameters.
.OUTPUTS
    [System.Collections.Hashtable] The deployment context hashtable.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Get-DeploymentContext {
    [CmdletBinding()]
    [OutputType([System.Collections.Hashtable])]
    param (
    )
    
    begin {
    }
    
    process {
        # EXECUTION - HASHTABLE CREATION
        # Set the DeploymentContext hashtable with necessary information for the Deployment Process
        [System.Collections.Hashtable]$DeploymentContext = @{
            ApplicationID           = Get-DeploymentData -PropertyName ApplicationID
            BuildNumber             = Get-DeploymentData -PropertyName BuildNumber
            DeploymentAction        = Get-DeploymentData -PropertyName DeploymentAction
            DeploymentObjects       = [System.Collections.Hashtable[]](Get-DeploymentData -PropertyName DeploymentObjects) # Force the type to be an array, cause if there is only 1 object, it fails.
            DeploymentObjectCounter = 1
            DeploymentResults       = [System.Collections.Generic.List[System.Boolean]]::new()
        }

        # EXECUTION - ADDITIONAL PROPERTIES
        # Add the amount
        $DeploymentContext.AmountOfDeploymentObjects    = $DeploymentContext.DeploymentObjects.Count
        # Add the properties in brackets
        $DeploymentContext.ApplicationIDInBrackets      = "[$($DeploymentContext.ApplicationID)]"
        $DeploymentContext.BuildNumberInBrackets        = "[$($DeploymentContext.BuildNumber)]"
        $DeploymentContext.DeploymentActionInBrackets   = "[$($DeploymentContext.DeploymentAction)-Process]".ToUpper()
    }
    
    end {
        # OUTPUT
        # Return the DeploymentContext hashtable
        $DeploymentContext
        
    }
}

# END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Creates an installation marker content.
.DESCRIPTION
    This function creates an installation marker content for a deployment object. The content contains information about the deployment, such as the application ID, build number, installer, and object type.
    The content is used for detection, maintenance, and audit purposes to validate the deployment of the application.
.EXAMPLE
    $MarkerContent = Get-InstallationMarkerContent -DeploymentObject $DeploymentObject
    This example creates an installation marker content for the specified deployment object and stores it in the $MarkerContent variable.
.INPUTS
    [System.Collections.Hashtable]$DeploymentObject - The deployment object that will be processed. It should contain properties such as ApplicationID, BuildNumber, UDFName, and Type.
.OUTPUTS
    [PSCustomObject]$MarkerContent - The installation marker content for the specified deployment object.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Get-InstallationMarkerContent {
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The deployment object that will be processed.')]
        [System.Collections.Hashtable]$DeploymentObject
    )

    try {
        # VALIDATION
        # Validate the DeploymentObject
        Approve-MandatoryHashtable -Hashtable $DeploymentObject -HashtableDescription 'DeploymentObject'

        # EXECUTION - HASHTABLE CREATION
        # Set the MarkerContent Object with necessary information for the Installation Marker file, which is used for detection, maintenance, and audit purposes.
        $MarkerContent = [PSCustomObject]@{
            ApplicationID   = Get-DeploymentData -PropertyName ApplicationID
            BuildNumber     = Get-DeploymentData -PropertyName BuildNumber
            InstalledBy     = Get-DeploymentData -PropertyName UDFName
            ObjectType      = $DeploymentObject.Type
            Description     = 'This is a Marker file created by the Universal Deployment Framework to validate the deployment of this application. This file is required for detection, maintenance, and audit purposes.'
        }

        # Add the MarkerFilePath to the MarkerContent
        [System.String]$MarkerFileName = '.UDF_InstallMarker'
        [System.String]$MarkerFilePath = Join-Path -Path $DeploymentObject.MarkerFileDirectory  -ChildPath $MarkerFileName
        Add-Member -InputObject $MarkerContent -MemberType NoteProperty -Name 'MarkerFilePath' -Value $MarkerFilePath -Force

        # Add the keys to validate in the detection process as a property of the MarkerContent
        [System.String[]]$KeysToValidate = @('ApplicationID','BuildNumber','InstalledBy','ObjectType')
        Add-Member -InputObject $MarkerContent -MemberType NoteProperty -Name 'KeysToValidate' -Value $KeysToValidate -Force

        # OUTPUT
        # Return the MarkerContent hashtable
        $MarkerContent
    }
    catch {
        # ERROR HANDLING
        Write-ErrorReport -ErrorRecord $_
        $PSCmdlet.ThrowTerminatingError($_)
    }
}

# END OF FUNCTION
####################################################################################################
