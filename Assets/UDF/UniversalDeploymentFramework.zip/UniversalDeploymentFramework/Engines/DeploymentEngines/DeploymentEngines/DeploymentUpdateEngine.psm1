#
# Module 'DeploymentSetEngine.psm1'
# Last Update: March 2026
#

####################################################################################################
<#
.SYNOPSIS
    Sets the work folder for the Deployment Process.
.DESCRIPTION
    This function sets the work folder for the Deployment Process.
.EXAMPLE
    Set-WorkFolder
.INPUTS
    None
.OUTPUTS
    No objects are returned to the pipeline. All operational output is written to the host and logged to the deployment logfile.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : February 2026
    Last Update     : February 2026
#>
####################################################################################################
function Set-WorkFolder {
    [CmdletBinding()]
    [OutputType([System.Void])]
    param ()

    begin {
    }

    process {
        # Get the Workfolder from the Global DeploymentObject
        [System.String]$Workfolder = Get-DeploymentData -PropertyName Rootfolder
        # Set the FolderIdentifier
        [System.String]$FolderIdentifier = 'Workfolder'
        # Set the Workfolder as the current location
        Write-Line "Setting the Rootfolder as the $FolderIdentifier for the Deployment Process. ($Workfolder)"
        Set-Location -Path $Workfolder
        # Add the Workfolder to the Global DeploymentObject for later use
        Add-ToGlobalDeploymentObject -Name $FolderIdentifier -Value $Workfolder
        # Write the size of the Workfolder to the host
        Get-FolderSize -Path (Get-DeploymentData -PropertyName $FolderIdentifier) -FolderIdentifier $FolderIdentifier -OutHost
    }

    end {}
}

# END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Sets the source files folder for the Deployment Process.
.DESCRIPTION
    This function sets the source files folder for the Deployment Process. It retrieves the SourceFilesFolder property from the DeploymentData and validates it.
    If the value is 'Default', it uses the Rootfolder as the source files folder. The resolved source files folder is then stored in the Global DeploymentObject for later use.
.EXAMPLE
    Set-SourceFilesFolder
    Sets the source files folder for the Deployment Process.
.INPUTS
    None. The function does not take any input parameters.
.OUTPUTS
    No objects are returned to the pipeline. All operational output is written to the host and logged to the deployment logfile.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Set-SourceFilesFolder {
    [CmdletBinding()]
    [OutputType([System.Void])]
    param (
    )

    begin {
        #PREPARATION
        # Set the FolderIdentifier
        [System.String]$FolderIdentifier    = 'SourceFilesFolder'
        # Get the SourceFilesFolder from the DeploymentData
        [System.String]$SourceFilesFolder   = Get-DeploymentData -PropertyName $FolderIdentifier
    }

    process {
        try {
            # VALIDATION
            # Validate the SourceFilesFolder
            if (-not $SourceFilesFolder) { Write-Line "The $FolderIdentifier property was not found in the DeploymentData." -Type Fail ; return }

            # EXECUTION
            # If the SourceFilesFolder is set to 'Default'
            if ($SourceFilesFolder -eq 'Default') {
                # Write the message
                Write-Line "The value of '$FolderIdentifier' is set to 'Default'."
                # Set the SourceFilesFolder to the Rootfolder
                $SourceFilesFolder = Get-DeploymentData -PropertyName Rootfolder
                # Set the resolved source files folder in the Global DeploymentObject for later use
                $Global:DeploymentObject.DeploymentData.$FolderIdentifier = $SourceFilesFolder
            }
            # Write the resolved source files folder to the host
            Write-Line "The following source files folder will be used: ($SourceFilesFolder)"
            # Write the size of the SourceFilesFolder to the host
            Get-FolderSize -Path (Get-DeploymentData -PropertyName $FolderIdentifier) -FolderIdentifier $FolderIdentifier -OutHost
        }
        catch {
            # ERROR HANDLING
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
    }

    end {
    }
}

# END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Adds the function properties for a given deployment object.
.DESCRIPTION
    This function takes a deployment object as input and adds the corresponding function properties based on the deployment object's type.
    It updates the deployment object with the function name and mandatory strings required for the deployment type.
.EXAMPLE
    $UpdatedDeploymentObject = Add-FunctionProperties -DeploymentObject $DeploymentObject
.INPUTS
    [System.Collections.Hashtable]$DeploymentObject
    The deployment object that will be processed. It should contain a 'Type' property that indicates the deployment type.
.OUTPUTS
    [System.Collections.Hashtable]
    The updated deployment object with the function properties set. The output deployment object will have additional properties such as 'DeploymentFunction' and 'MandatoryStrings' based on the deployment type.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Add-FunctionProperties {
    [CmdletBinding()]
    [OutputType([System.Collections.Hashtable])]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The deployment object that will be processed.')]
        [System.Collections.Hashtable]$DeploymentObject
    )

    process {
        try {
            # PREPARATION
            # Create a copy of the DeploymentObject to update and return at the end of the function
            [System.Collections.Hashtable]$UpdatedDO = $DeploymentObject
            # Set the Type
            [System.String]$DeploymentType = $DeploymentObject.Type

            # PREPARATION
            # Set the mapping hashtable for deployment types and corresponding function names (and give it an abbreviated name for easier use in the code below)
            [System.Collections.Hashtable]$MH = @{
                # INSTALLERS
                DEPLOYMSI                       = @{
                    DeploymentFunction          = { Start-MSIDeployment }
                    TestInstallFunction    = { Test-MSIDeploymentRequired }
                    MandatoryStrings            = @('MSIFileName')
                    MandatorySourceFiles        = @('MSIFileName')
                }
                # FILES AND FOLDERS
                DEPLOYBASICFOLDERCOPY           = @{
                    DeploymentFunction          = { Start-BasicFolderDeployment }
                    TestInstallFunction    = { Test-FolderDeploymentRequired }
                    MandatoryStrings            = @('FolderToCopy','DestinationFolder')
                    MandatoryBooleans           = @('KeepCurrentFolderName')
                    MandatorySourceFolders      = @('FolderToCopy')
                }
                DEPLOYCOMPRESSEDFOLDER          = @{
                    DeploymentFunction          = { Start-CompressedFolderDeployment }
                    InstallFunction             = { Install-CompressedFolder }
                    UninstallFunction           = { Uninstall-CompressedFolder }
                    TestInstallFunction    = { Test-MarkerApplicationIsInstalled }
                    MandatoryStrings            = @('ZipFileName','DestinationFolder')
                    MandatoryBooleans           = @('SkipTopFolderInsideZipFile')
                    MandatorySourceFiles        = @('ZipFileName')
                    FriendlyObjectName          = $DeploymentObject.ZipFileName
                    MarkerFileDirectory         = $DeploymentObject.DestinationFolder
                }
                DEPLOYBASICFILECOPY             = @{
                    DeploymentFunction          = { Start-BasicFileDeployment }
                    TestInstallFunction    = { Test-FileDeploymentRequired }
                    MandatoryStrings            = @('FileToCopy','DestinationFolder')
                    MandatoryBooleans           = @('OverwriteExistingFile')
                    MandatorySourceFiles        = @('FileToCopy')
                }
                # SHORTCUTS
                DEPLOYSHORTCUT                  = @{
                    DeploymentFunction          = { Start-ShortcutDeployment }
                    MandatoryStrings            = @('DisplayName','TargetPath')
                    MandatoryBooleans           = @('AlsoPlaceOnDesktop')
                }
                REMOVESHORTCUT                  = @{
                    DeploymentFunction          = { Remove-Shortcut }
                    MandatoryStrings            = @('ShortcutFileName')
                    MandatoryBooleans           = @('PerformDuringInstall','PerformDuringUninstall','AlsoRemoveFromStartMenu')
                }
                # REGISTRY
                DEPLOYREGFILE                   = @{
                    DeploymentFunction          = { Start-REGFileDeployment }
                    MandatoryStrings            = @('REGFileName')
                    MandatoryBooleans           = @('AlsoRemoveParentKeys')
                    MandatorySourceFiles        = @('REGFileName')
                }
                IMPORTREGFILE                   = @{
                    DeploymentFunction          = { Import-REGFile }
                    MandatoryStrings            = @('REGFileName')
                    MandatoryBooleans           = @('PerformDuringInstall','PerformDuringUninstall')
                    MandatorySourceFiles        = @('REGFileName')
                }
                # OTHER
                DEPLOYPAUSE                     = @{
                    DeploymentFunction          = { Start-PauseDeployment }
                    MandatoryStrings            = @('SecondsToPause')
                    MandatoryBooleans           = @('PerformDuringInstall','PerformDuringUninstall')
                    FriendlyObjectName          = "Pause for $($DeploymentObject.SecondsToPause) seconds"
                }
                DEPLOYARPENTRY                  = @{
                    DeploymentFunction          = { Start-ARPEntryDeployment }
                    MandatoryStrings            = @('DisplayVersion','PublisherName')
                }
                ADDENVIRONMENTPATH              = @{
                    DeploymentFunction          = { Start-EnvironmentPathDeployment }
                    TestFunction                = { Test-EnvironmentPathDeploymentRequired }
                    MandatoryStrings            = @('Directory')
                    MandatoryBooleans           = @('RemoveDuringUninstall')
                }
            }

            # EXECUTION
            # If the deployment type is supported
            if ($MH.ContainsKey($DeploymentType)) {

                # EXECUTION - GET PROPERTIES
                # Get the corresponding functions
                Write-Line "Adding function properties to the deployment object based on its type: [$DeploymentType]"
                [System.String]$DeploymentFunction  = $MH[$DeploymentType].DeploymentFunction.ToString().Trim()
                [System.String]$InstallFunction     = if ($MH[$DeploymentType].ContainsKey('InstallFunction')) { $MH[$DeploymentType].InstallFunction.ToString().Trim() }
                [System.String]$UninstallFunction   = if ($MH[$DeploymentType].ContainsKey('UninstallFunction')) { $MH[$DeploymentType].UninstallFunction.ToString().Trim() }
                [System.String]$TestInstallFunction = if ($MH[$DeploymentType].ContainsKey('TestInstallFunction')) { $MH[$DeploymentType].TestInstallFunction.ToString().Trim() }
                # Get the corresponding mandatory items
                [System.String[]]$MandStrings       = $MH[$DeploymentType].MandatoryStrings
                [System.String[]]$MandBooleans      = $MH[$DeploymentType].MandatoryBooleans
                [System.String[]]$MandSourceFiles   = $MH[$DeploymentType].MandatorySourceFiles
                [System.String[]]$MandSourceFolders = $MH[$DeploymentType].MandatorySourceFolders
                # Get the other properties
                [System.String]$FriendlyObjectName  = $MH[$DeploymentType].FriendlyObjectName
                [System.String]$MarkerFileDirectory = $MH[$DeploymentType].MarkerFileDirectory

                # EXECUTION - ADD PROPERTIES TO DEPLOYMENT OBJECT
                # Add the Functions to the UpdatedDeploymentObject
                if (Test-String -IsPopulated $DeploymentFunction)   { $UpdatedDO.DeploymentFunction = $DeploymentFunction ; Write-Line "The DeploymentFunction for DeploymentType [$DeploymentType] is [$DeploymentFunction]." }
                if (Test-String -IsPopulated $InstallFunction)      { $UpdatedDO.InstallFunction = $InstallFunction ; Write-Line "The InstallFunction is: [$InstallFunction]." }
                if (Test-String -IsPopulated $UninstallFunction)    { $UpdatedDO.UninstallFunction = $UninstallFunction ; Write-Line "The UninstallFunction is: [$UninstallFunction]." }
                if (Test-String -IsPopulated $TestInstallFunction)  { $UpdatedDO.TestInstallFunction = $TestInstallFunction ; Write-Line "The TestInstallFunction is: [$TestInstallFunction]." }
                # Add the Mandatory Items to the UpdatedDeploymentObject
                if (Test-Array -IsPopulated $MandStrings)           { $UpdatedDO.MandatoryStrings = $MandStrings ; Write-Line "The Mandatory Strings are: [$($MandStrings -join (','))]" }
                if (Test-Array -IsPopulated $MandBooleans)          { $UpdatedDO.MandatoryBooleans = $MandBooleans ; Write-Line "The Mandatory Booleans are: [$($MandBooleans -join (','))]" }
                if (Test-Array -IsPopulated $MandSourceFiles)       { $UpdatedDO.MandatorySourceFiles = $MandSourceFiles ; Write-Line "The Mandatory Source Files are: [$($MandSourceFiles -join (','))]" }
                if (Test-Array -IsPopulated $MandSourceFolders)     { $UpdatedDO.MandatorySourceFolders = $MandSourceFolders ; Write-Line "The Mandatory Source Folders are: [$($MandSourceFolders -join (','))]" }
                # Add the other properties to the UpdatedDeploymentObject
                if (Test-String -IsPopulated $FriendlyObjectName)   { $UpdatedDO.FriendlyObjectName = $FriendlyObjectName ; Write-Line "The Friendly Object Name is: [$FriendlyObjectName]" }
                if (Test-String -IsPopulated $MarkerFileDirectory)  { $UpdatedDO.MarkerFileDirectory = $MarkerFileDirectory ; Write-Line "The Marker File Directory is: [$MarkerFileDirectory]" }

            } else {
                # If the deployment type is not supported, throw an error
                throw "A corresponding function for this DeploymentType is not defined: [$DeploymentType)]"
            }

            # Return the updated deployment object
            $UpdatedDO
        }
        catch {
            # ERROR HANDLING
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
    }
}

# END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Adds text properties to the deployment object.
.DESCRIPTION
    This function adds text properties to the deployment object.
    It takes the deployment object as input and adds a property with the function name in brackets for later use in the validation and execution engines.
.EXAMPLE
    $UpdatedDeploymentObject = Add-TextProperties -DeploymentObject $DeploymentObject
.INPUTS
    [System.Collections.Hashtable]$DeploymentObject
    The deployment object that will be processed.
.OUTPUTS
    [System.Collections.Hashtable]
    The updated deployment object with the function properties set.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Add-TextProperties {
    [CmdletBinding()]
    [OutputType([System.Collections.Hashtable])]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The deployment object that will be processed.')]
        [System.Collections.Hashtable]$DeploymentObject
    )

    begin {
        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            DeploymentObject        = $DeploymentObject
            UpdatedDeploymentObject = $DeploymentObject
        }
        # Write the message
        Write-Line "Adding text properties to the deployment object for later use in the validation and execution engines."
    }
    
    process {
        try {
            # Add the function name in brackets to the UpdatedDeploymentObject for later use in the validation and execution engines
            $CTX.UpdatedDeploymentObject.FunctionNameInBrackets     = "[$($CTX.DeploymentObject.DeploymentFunction)]"
            # Add the test function name in brackets
            $CTX.UpdatedDeploymentObject.TestFunctionNameInBrackets = "[$($CTX.DeploymentObject.TestFunctionName)]"
            # Add the ObjectType in brackets
            $CTX.UpdatedDeploymentObject.ObjectTypeInBrackets       = "[$($CTX.DeploymentObject.Type)]"
            # Add the ActionText in brackets
            $CTX.UpdatedDeploymentObject.DeploymentActionInBrackets = "[$($CTX.DeploymentObject.DeploymentAction.ToUpper())]-action"
            # Add the ApplicationID in brackets
            $CTX.UpdatedDeploymentObject.ApplicationIDInBrackets    = "[$($CTX.DeploymentObject.ApplicationID)]"
            # Add the BuildNumber in brackets
            $CTX.UpdatedDeploymentObject.BuildNumberInBrackets      = "[$($CTX.DeploymentObject.BuildNumber)]"
        }
        catch {
            # ERROR HANDLING
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
        
    }
    
    end {
        # OUTPUT
        # Return the updated deployment object
        $CTX.UpdatedDeploymentObject
    }
}

# END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Adds a property to the Global DeploymentObject.
.DESCRIPTION
    This function adds a property to the Global DeploymentObject. If the property already exists, its value will be updated.
.EXAMPLE
    Add-ToGlobalDeploymentObject -Name "PropertyName" -Value "PropertyValue"
.INPUTS
    [System.String]$Name - The name of the property to add to the Global DeploymentObject.
    [System.Object]$Value - The value of the property to add to the Global DeploymentObject.
.OUTPUTS
    No objects are returned to the pipeline. All operational output is written to the host and logged to the deployment logfile.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Add-ToGlobalDeploymentObject {
    [CmdletBinding()]
    [OutputType([System.Void])]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The name of the property to add to the Global DeploymentObject.')]
        [System.String]$Name,

        [Parameter(Mandatory=$true,HelpMessage='The value of the property to add to the Global DeploymentObject.')]
        [System.Object]$Value
    )

    process {
        try {
            # Add the property to the Global DeploymentObject
            $Global:DeploymentObject | Add-Member -MemberType NoteProperty -Name $Name -Value $Value -Force
        }
        catch {
            # ERROR HANDLING
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
    }
}

# END OF FUNCTION
####################################################################################################
