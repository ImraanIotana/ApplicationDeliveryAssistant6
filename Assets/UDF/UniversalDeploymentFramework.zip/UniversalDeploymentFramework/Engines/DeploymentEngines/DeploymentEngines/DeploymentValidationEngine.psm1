#
# Module 'DeploymentValidationEngine.psm1'
# Last Update: March 2026
#

####################################################################################################
<#
.SYNOPSIS
    Tests if a deployment should be performed based on the properties of the deployment object.
.DESCRIPTION
    This function evaluates the deployment object to determine if the deployment should be performed.
    It checks the DeploymentAction and the corresponding properties of the deployment object to make this determination.
.EXAMPLE
    Test-DeploymentRequired -DeploymentObject $MyDeploymentObject
.INPUTS
    [System.Collections.Hashtable]
.OUTPUTS
    [System.Boolean]
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Start-MainDeploymentValidation {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The deployment context containing all relevant information about the deployment process.')]
        [System.Collections.Hashtable]$DeploymentContext
    )
    
    begin {
        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            DeploymentContext           = $DeploymentContext
            DeploymentObjects           = $DeploymentContext.DeploymentObjects
            AppIDInBrackets             = $DeploymentContext.ApplicationIDInBrackets
            BuildInBrackets             = $DeploymentContext.BuildNumberInBrackets
            ResultArrayList             = [System.Collections.ArrayList]@()
            UpdatedDeploymentContext    = $DeploymentContext
        }

        # Write the message
        Write-Line "Starting the validation of [$($CTX.DeploymentObjects.Count)] DeploymentObjects for the Application $($CTX.AppIDInBrackets) Build $($CTX.BuildInBrackets)..."
    }
    
    process {
        try {
            # VALIDATION - INPUT
            # Validate the DeploymentContext
            Approve-MandatoryHashtable -Hashtable $CTX.DeploymentContext -HashtableDescription 'DeploymentContext'
            
            # PREPARATION
            # Remove the DeploymentObjects from the UpdatedDeploymentContext
            $CTX.UpdatedDeploymentContext.Remove('DeploymentObjects')
            # Add the DeploymentObjects as an empty arraylist to the UpdatedDeploymentContext, which will be populated with the updated deployment objects with the added properties during the execution of the validation process
            $CTX.UpdatedDeploymentContext.DeploymentObjects = [System.Collections.ArrayList]@()

            # EXECUTION
            # Validate each DeploymentObject in the DeploymentContext
            foreach ($DeploymentObject in $CTX.DeploymentObjects) {

                # PREPARATION - ADD PROPERTIES TO THE DEPLOYMENT OBJECT
                # Create a copy of the deployment object
                $UpdatedDeploymentObject = $DeploymentObject
                # Add the DeploymentAction to the deployment object for later use in the processing function
                $UpdatedDeploymentObject.DeploymentAction = $CTX.DeploymentContext.DeploymentAction
                # Add the function properties to the deployment object based on its type
                $UpdatedDeploymentObject = Add-FunctionProperties -DeploymentObject $UpdatedDeploymentObject
                # Add the text properties to the deployment object for better output messages
                $UpdatedDeploymentObject = Add-TextProperties -DeploymentObject $UpdatedDeploymentObject

                # UPDATE THE DEPLOYMENT CONTEXT
                # Add the updated deployment object with the added properties to the UpdatedDeploymentContext
                $CTX.UpdatedDeploymentContext.DeploymentObjects.Add($UpdatedDeploymentObject) | Out-Null

                # EXECUTION - VALIDATE THE DEPLOYMENT OBJECT
                # Validate the deployment object and add the result to the ResultArrayList
                $CTX.ResultArrayList.Add((Approve-DeploymentObject -DeploymentObject $UpdatedDeploymentObject)) | Out-Null
            }

            # RESULT
            # If the ResultArrayList contains only valid DeploymentObjects, set the output to $true, otherwise set it to $false
            if (Test-ArrayContainsOnlyTrue -Array $CTX.ResultArrayList) {
                Write-Line "All DeploymentObjects have been validated successfully."
            } else {
                throw "One or more DeploymentObjects failed validation."
            }
        }
        catch {
            # ERROR HANDLING
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
    }
    
    end {
        # OUTPUT
        # Return the UpdatedDeploymentContext
        $CTX.UpdatedDeploymentContext
    }
}

### END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Tests if a deployment should be performed based on the properties of the deployment object.
.DESCRIPTION
    This function evaluates the deployment object to determine if the deployment should be performed.
    It checks the DeploymentAction and the corresponding properties of the deployment object to make this determination.
.EXAMPLE
    Test-DeploymentRequired -DeploymentObject $MyDeploymentObject
.INPUTS
    [System.Collections.Hashtable]
.OUTPUTS
    [System.Boolean]
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Test-DeploymentRequired {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The deployment object that will be processed.')]
        [System.Collections.Hashtable]$DeploymentObject        
    )

    try {
        # VALIDATION - INPUT
        # Validate the DeploymentObject
        Approve-MandatoryHashtable -Hashtable $DeploymentObject -HashtableDescription 'DeploymentObject'

        # PREPARATION
        # Set the text properties for the messages
        [System.Collections.Hashtable]$Text = @{ Action = $DeploymentObject.DeploymentActionInBrackets ; ObjectType = $DeploymentObject.ObjectTypeInBrackets }
        # Write the message
        Write-Line "Evaluating if the $($Text.Action) for the application ($($DeploymentObject.FriendlyObjectName)) must be [PERFORMED OR SKIPPED]..."

        # PREPARATION - GET THE PERFORM-PROPERTY NAME
        # Get the property from the DeploymentAction based on the DeploymentAction
        [System.String]$ExplicitPerformPropertyName = switch ($DeploymentObject.DeploymentAction) {
            'Install'   { 'PerformDuringInstall' }
            'Uninstall' { 'PerformDuringUninstall' }
        }

        # EXECUTION - DETERMINE IF THE DEPLOYMENT IS REQUIRED
        # If the DeploymentObject contains the Perform property
        [System.Boolean]$DeploymentIsRequired = if ($DeploymentObject.ContainsKey($ExplicitPerformPropertyName)) {
            # Write the message, and return the value of the Perform property
            [System.Boolean]$ValueOfPerformProperty = $DeploymentObject.$ExplicitPerformPropertyName
            Write-Line "The DeploymentObject contains the property [$ExplicitPerformPropertyName] with the value [$ValueOfPerformProperty]."
            $ValueOfPerformProperty
        } else {
            # Write the message, and continue with the evaluation process
            Write-Line "The DeploymentObject does not contain the property [$ExplicitPerformPropertyName]. The requirement will be determined by the evaluation process."

            # If the DeploymentObject has a TestInstallationFunction, then the requirement will be determined by testing if the application is installed, and evaluating the result based on the DeploymentAction. Else, an error will be thrown, because the requirement cannot be determined without a TestInstallationFunction.
            if ($DeploymentObject.TestInstallationFunction) {

                # Test if the application is installed
                # (This needs to be updated for the other types of deployment objects)
                Write-Line "The DeploymentObject contains the property [$TestInstallationFunction]. The requirement will be determined by evaluating the installation state."
                [System.Boolean]$ApplicationIsInstalled = & $DeploymentObject.TestInstallationFunction -DeploymentObject $DeploymentObject

                # Evaluate the requirement based on the DeploymentAction and the installation status of the application
                [System.String]$PostFix,[System.Boolean]$SpecificDeploymentActionIsRequired = switch ($DeploymentObject.DeploymentAction) {
                    # If the application is already installed, return $false to indicate that the installation is not required, else return $true to indicate that the installation is required
                    'Install'   { if ($ApplicationIsInstalled) { "already installed." ; $false } else { "not installed yet." ; $true } }
                    # If the application is installed, return $true to indicate that the uninstallation is required, else return $false to indicate that the uninstallation is not required
                    'Uninstall' { if ($ApplicationIsInstalled) { "installed." ; $true } else { "not installed." ; $false } }
                }

                # Write the message about the evaluation of the requirement
                Write-Line "The application ($($DeploymentObject.FriendlyObjectName)) is $PostFix"

                # Return the result of the evaluation of the requirement
                $SpecificDeploymentActionIsRequired
            } else {
                Write-Line "The DeploymentObject does not have a TestInstallationFunction. The action will be performed."
                $true
            }
        }

        # RESULT - WRITE THE RESULT
        # Write the result to the host
        Write-Line "The $($Text.Action) for the DeploymentObject $($Text.ObjectType) will be $(if ($DeploymentIsRequired) { "[PERFORMED]" } else { "[SKIPPED]" })" -Type Info

        # OUTPUT
        # Return the output
        $DeploymentIsRequired
    }
    catch [System.Management.Automation.RuntimeException] {
        $PSCmdlet.ThrowTerminatingError($_)
    }
    catch {
        # ERROR HANDLING
        Write-ErrorReport -ErrorRecord $_
        $PSCmdlet.ThrowTerminatingError($_)
    }
}

### END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Approves a deployment object by validating its properties based on its type.
.DESCRIPTION
    Approves a deployment object by validating its properties based on its type.
    The function checks if the mandatory properties for the specific type of deployment object are populated, and returns $true if all validations are passed, or $false if any validation fails.
.EXAMPLE
    Approve-DeploymentObject -DeploymentObject $MyDeploymentObject
.INPUTS
    [System.Collections.Hashtable]
.OUTPUTS
    [System.Boolean]
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Approve-DeploymentObject {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The deployment object that will be processed.')]
        [System.Collections.Hashtable]$DeploymentObject
    )

    begin {
        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            DeploymentObject        = $DeploymentObject
            DeploymentType          = $DeploymentObject.Type
            ObjectTypeInBrackets    = $DeploymentObject.ObjectTypeInBrackets
            ResultArrayList         = [System.Collections.ArrayList]@()
            Output                  = $null
        }
        # Write the message
        Write-Line "Approving the DeploymentObject $($CTX.ObjectTypeInBrackets)..."
    }

    process {        
        try {
            # VALIDATION - INPUT
            # Validate the DeploymentObject
            Approve-MandatoryHashtable -Hashtable $CTX.DeploymentObject -HashtableDescription 'DeploymentObject'

            # EXECUTION - APPROVE THE FUNCTION
            # If the Deployment function does not exist, throw an error
            if (-not (Get-Command $CTX.DeploymentObject.DeploymentFunction -CommandType Function -ErrorAction SilentlyContinue)) {
                throw "The corresponding Deployment-function [$($CTX.DeploymentObject.DeploymentFunction)] does not exist. The DeploymentObject $($CTX.ObjectTypeInBrackets) cannot be deployed."
            }
            # If the Deployment function exists, add true to the ResultArrayList
            Write-Line "The corresponding Deployment-function [$($CTX.DeploymentObject.DeploymentFunction)] exists."
            $CTX.ResultArrayList.Add($true) | Out-Null
        

            # EXECUTION - APPROVE THE MANDATORY STRINGS
            # Test the mandatory strings for the deployment object
            [System.String[]]$MandatoryStrings = $CTX.DeploymentObject.MandatoryStrings
            if (Test-Array -IsPopulated $MandatoryStrings) {
                foreach ($StringName in $MandatoryStrings) {
                    # Get the value of the string from the deployment object
                    [System.String]$StringValue = $CTX.DeploymentObject.$StringName
                    # Test if the string is populated, write the result to the host, and return the result as a boolean
                    [System.Boolean]$StringIsPopulated = if (Test-String -IsPopulated $StringValue) {
                        Write-Line "The Mandatory String [$StringName] is populated. ($StringValue)" ; $true
                    } else {
                        #Write-Line "The Mandatory String [$StringName] is empty." -Type Fail ; $false
                        throw "The Mandatory String [$StringName] is empty."
                    }
                    # Add the result to the ResultArrayList
                    $CTX.ResultArrayList.Add($StringIsPopulated) | Out-Null
                }
            }

            # EXECUTION - APPROVE THE MANDATORY BOOLEANS
            # Test the mandatory booleans for the deployment object
            [System.String[]]$MandatoryBooleanNames = $CTX.DeploymentObject.MandatoryBooleans
            if (Test-Array -IsPopulated $MandatoryBooleanNames) {
                foreach ($BooleanName in $MandatoryBooleanNames) {
                    # Test if the boolean is not $null, write the result to the host, and return the result as a boolean
                    # (The Original property must be used:CTX.DeploymentObject.$BooleanName, otherwise it will be translated to $false, if the value is $null)
                    [System.Boolean]$BooleanIsValid = if ($null -eq $CTX.DeploymentObject.$BooleanName) {
                        Write-Line ('The Mandatory Boolean [{0}] is $null. Please provide a valid value ($true or $false).' -f $BooleanName) -Type Fail ; $false
                    } else {
                        Write-Line "The value of the Mandatory Boolean [$BooleanName] is valid. ($($CTX.DeploymentObject.$BooleanName))" ; $true
                    }
                    # Add the result to the ResultArrayList
                    $CTX.ResultArrayList.Add($BooleanIsValid) | Out-Null
                }
            }

            # EXECUTION - APPROVE THE SOURCE FILES
            # Test the source files for the deployment object
            [System.String[]]$MandatorySourceFiles = $CTX.DeploymentObject.MandatorySourceFiles
            if (Test-Array -IsPopulated $MandatorySourceFiles) {
                foreach ($SourceFileIdentifier in $MandatorySourceFiles) {
                    # Search for the source file
                    [System.String]$SourceFileName = $CTX.DeploymentObject.$SourceFileIdentifier
                    Write-Line "Approving the mandatory source file ($SourceFileName)..."
                    [System.String]$SourceFilePath = Get-SourceItem -FileName $SourceFileName
                    # If the source file is found, add the result to the ResultArrayList. If not, then an error is thrown by the Get-SourceItem function
                    if (Test-String -IsPopulated $SourceFilePath) {
                        # Add the result to the ResultArrayList
                        Write-Line "The Mandatory source file ($SourceFileName) was found at the path: ($SourceFilePath)."
                        $CTX.ResultArrayList.Add($true) | Out-Null
                    }
                }
            }

            # EXECUTION - APPROVE THE SOURCE FOLDERS
            # Test the source folders for the deployment object
            [System.String[]]$MandatorySourceFolders = $CTX.DeploymentObject.MandatorySourceFolders
            if (Test-Array -IsPopulated $MandatorySourceFolders) {
                foreach ($SourceFolderIdentifier in $MandatorySourceFolders) {
                    # Search for the source folder
                    [System.String]$SourceFolderName = $CTX.DeploymentObject.$SourceFolderIdentifier
                    Write-Line "Approving the mandatory source folder ($SourceFolderName)..."
                    [System.String]$SourceFolderPath = Get-SourceItem -FolderName $SourceFolderName
                    # If the source folder is found, add the result to the ResultArrayList. If not, then an error is thrown by the Get-SourceItem function
                    if (Test-String -IsPopulated $SourceFolderPath) {
                        # Add the result to the ResultArrayList
                        Write-Line "The Mandatory source folder ($SourceFolderName) was found at the path: ($SourceFolderPath)."
                        $CTX.ResultArrayList.Add($true) | Out-Null
                    }
                }
            }
            
            # RESULT
            # Test if the ArrayList contains only $true values
            if (Test-ArrayContainsOnlyTrue -Array $CTX.ResultArrayList) {
                Write-Line "The DeploymentObject $($CTX.ObjectTypeInBrackets) has been approved."
                $CTX.Output = $true
            } else {
                throw "One or more properties of the DeploymentObject $($CTX.ObjectTypeInBrackets) are not valid."
            }
        }
        catch {
            # ERROR HANDLING
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
    }

    end {
        # OUTPUT
        # Return the approval status of the deployment object
        $CTX.Output
    }
}

### END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Tests if an application is installed on the system by checking for its product code in the registry.
.DESCRIPTION
    This function tests if an application is installed on the system by checking for its product code in the registry.
.EXAMPLE
    Test-ApplicationIsInstalled -Path "C:\Path\To\Your.msi"
    Tests if the application at the specified path is installed.
.EXAMPLE
    Test-ApplicationIsInstalled -ProductCode "{12345678-1234-1234-1234-1234567890AB}"
    Tests if the application with the specified product code is installed.
.INPUTS
    [System.String]
    [System.Management.Automation.SwitchParameter]
.OUTPUTS
    [System.Boolean]
    A boolean value indicating whether the application is installed on the system (true) or not (false).
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Test-ApplicationIsInstalled {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$true,ParameterSetName='ByKeyName',HelpMessage='The key name of the application.')]
        [AllowEmptyString()][System.String]$KeyName,

        [Parameter(Mandatory=$true,ParameterSetName='ByDisplayName',HelpMessage='The display name of the application.')]
        [AllowEmptyString()][System.String]$DisplayName,

        [Parameter(Mandatory=$true,ParameterSetName='ByDeploymentObject',HelpMessage='The deployment object that will be processed.')]
        [System.Collections.Hashtable]$DeploymentObject
    )

    # VALIDATION - INPUT
    # Set the parameter set name
    [System.String]$ParameterSetName = $PSCmdlet.ParameterSetName
    # Switch on the parameter set name to determine which parameters to validate
    switch ($ParameterSetName) {
        'ByKeyName'             { Approve-MandatoryString -String $KeyName -StringDescription 'KeyName' }
        'ByDisplayName'         { Approve-MandatoryString -String $DisplayName -StringDescription 'DisplayName' }
        'ByDeploymentObject'    { Approve-MandatoryHashtable -Hashtable $DeploymentObject -HashtableDescription 'DeploymentObject'}
    }
    
    # PREPARATION
    # Set the context
    [System.Collections.Hashtable]$CTX = @{
        DisplayName         = $DisplayName
        ParameterSetName    = $ParameterSetName
        Output              = $false
    }

    try {
        # Switch on the parameter set name
        $CTX.Output = switch ($ParameterSetName) {
            'ByKeyName' {

                # PREPARATION
                # Write the message
                Write-Line "Testing if the application is installed by checking the registry for the key name: ($KeyName)"
                # Get the installed applications
                [System.String[]]$InstalledApplications = Get-InstalledApplications -ReturnKeyNames
                # EXECUTION
                # Test if the key name is in the list of installed applications
                [System.Boolean]$ApplicationIsInstalled = $InstalledApplications -contains $KeyName
                # Write the message
                [System.String]$InFix = if ($ApplicationIsInstalled) { "is" } else { "is not" }
                Write-Line "The application with key name ($KeyName) $InFix installed."
                # OUTPUT
                # Return the output
                $ApplicationIsInstalled

            }
            'ByDeploymentObject' {
                # PREPARATION
                # Write the message
                Write-Line "Testing if the application is installed for ObjectType $($DeploymentObject.ObjectTypeInBrackets)" -Type Info
                # Switch on the type of deployment object to determine how to test if the application is installed
                switch ($DeploymentObject.Type) {
                    'DEPLOYCOMPRESSEDFOLDER' { Test-MarkerApplicationIsInstalled -DeploymentObject $DeploymentObject }
                    default {
                        # This function still needs to be implemented for the other types
                        throw "The function for this type of DeploymentObject is not (yet) implemented. ($($DeploymentObject.Type))"
                    }
                }
            }
            default {
                # This function still needs to be implemented for the other types
                throw "The function for this ParameterSetName is not (yet) implemented. ($($ParameterSetName))"
            }
        }

        # RESULT - OUTPUT
        # Write the result to the host
        [System.String]$InstallationStatus = if ($CTX.Output) { 'is' } else { 'is not' }
        Write-Line "The application $InstallationStatus installed."
        # Return the output
        $CTX.Output
    }
    catch {
        # ERROR HANDLING
        Write-ErrorReport -ErrorRecord $_
        $PSCmdlet.ThrowTerminatingError($_)
    }
}

### END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Tests whether the marker application is installed by checking for the presence of a marker file that was created during installation.
.DESCRIPTION
    This function tests whether a marker application is installed by checking for the presence of a marker file that was created during installation.
.EXAMPLE
    Test-MarkerApplicationIsInstalled -DeploymentObject $DeploymentObject
.INPUTS
    [System.Collections.Hashtable]$DeploymentObject
.OUTPUTS
    [System.Boolean]
    Indicates whether the marker application is installed.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Test-MarkerApplicationIsInstalled {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The deployment object that will be processed.')]
        [System.Collections.Hashtable]$DeploymentObject
    )

    try {
        # VALIDATION - INPUT
        # Validate the DeploymentObject
        Approve-MandatoryHashtable -Hashtable $DeploymentObject -HashtableDescription 'DeploymentObject'

        # PREPARATION
        # Set the ExpectedMarkerContent
        [PSCustomObject]$ExpectedMarkerContent = Get-InstallationMarkerContent -DeploymentObject $DeploymentObject
        # Get the MarkerFilePath from the ExpectedMarkerContent
        [System.String]$ExpectedMarkerFilePath = $ExpectedMarkerContent.MarkerFilePath

        # EXECUTION - CHECK MARKER FILE
        # Check if the Marker file exists at the expected location
        [System.Boolean]$MarkerFileIsPresent = Test-Path -Path $ExpectedMarkerFilePath -PathType Leaf

        # EXECUTION - CHECK MARKER FILE CONTENT
        # If the Marker file is NOT present, the marker application is considered NOT installed.
        [System.Boolean]$MarkerApplicationIsInstalled = if (-not $MarkerFileIsPresent) {
            Write-Line "The marker file was NOT found at the expected location. The marker application is considered NOT installed. ($ExpectedMarkerFilePath)"
            $false
        }
        else {
            # If the Marker file IS present, the content of the Marker file is checked to determine if the marker application is installed.
            Write-Line "Checking the marker file content... ($ExpectedMarkerFilePath)"
            [PSCustomObject]$MarkerFileContent = Get-Content -Path $ExpectedMarkerFilePath -Raw | ConvertFrom-Json

            # Compare the content of the Marker file with the expected content
            Test-MarkerFileEquality -MarkerFileContent $MarkerFileContent -ExpectedMarkerContent $ExpectedMarkerContent
        }

        # RESULT - OUTPUT
        # Write the result to the host
        Write-Line "The marker application $(if ($MarkerApplicationIsInstalled) { 'is' } else { 'is not' }) installed."
        # Return the output
        $MarkerApplicationIsInstalled
    }
    catch {
        # ERROR HANDLING
        Write-ErrorReport -ErrorRecord $_
        $PSCmdlet.ThrowTerminatingError($_)
    }
}

### END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Tests the equality of the content of a marker file with expected content.
.DESCRIPTION
    This function compares the content of a marker file with the expected content to determine if they are equal.
.EXAMPLE
    Test-MarkerFileEquality -MarkerFileContent $MarkerFileContent -ExpectedMarkerContent $ExpectedMarkerContent
.INPUTS
    [PSCustomObject]$MarkerFileContent
    The content of the marker file that was read from the marker file during uninstallation.
    [PSCustomObject]$ExpectedMarkerContent
    The expected content of the marker file based on the properties that were set during installation.
.OUTPUTS
    [System.Boolean]
    Indicates whether the content of the marker file matches the expected content.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Test-MarkerFileEquality {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The first object to compare.')]
        [PSCustomObject]$MarkerFileContent,

        [Parameter(Mandatory=$true,HelpMessage='The second object to compare.')]
        [PSCustomObject]$ExpectedMarkerContent
    )
    
    try {
        # PREPARATION
        # Write the message
        Write-Line "Comparing the content of the marker file with the expected content to verify the installation..."

        # Set the content equality flag
        [System.Boolean]$MarkerFilesAreEqual = $true

        # EXECUTION - CHECK MARKER FILE CONTENT
        # Compare the content of the Marker file with the expected content
        foreach ($Key in $MarkerFileContent.KeysToValidate) {
            if (-not ($ExpectedMarkerContent.PSObject.Properties.Name -contains $Key)) {
                Write-Line "The Expected Content is missing the key [$Key]." -Type Info
                $MarkerFilesAreEqual = $false
            }
            elseif ($MarkerFileContent.PSObject.Properties[$Key].Value -ne $ExpectedMarkerContent.PSObject.Properties[$Key].Value) {
                Write-Line "The value for the key [$Key] in Marker File ($($MarkerFileContent.PSObject.Properties[$Key].Value)) does not match the value in the Expected Content: ($($ExpectedMarkerContent.PSObject.Properties[$Key].Value))." -Type Info
                $MarkerFilesAreEqual = $false
            }
            else {
                Write-Verbose "The value for the key [$Key] in Marker File matches the value in the Expected Content`t: ($($MarkerFileContent.PSObject.Properties[$Key].Value))"
            }
        }

        # RESULT - OUTPUT
        # Write the result to the host
        Write-Line "The Marker Files are $(if ($MarkerFilesAreEqual) { '' } else { 'NOT ' })equal."
        # Return the result of the content comparison
        $MarkerFilesAreEqual
    }
    catch {
        # ERROR HANDLING
        Write-ErrorReport -ErrorRecord $_
        $PSCmdlet.ThrowTerminatingError($_)
    }
}

### END OF FUNCTION
####################################################################################################
