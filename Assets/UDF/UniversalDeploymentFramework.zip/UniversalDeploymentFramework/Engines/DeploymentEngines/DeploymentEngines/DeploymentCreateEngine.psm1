#
# Module 'DeploymentCreateEngine.psm1'
# Last Update: March 2026
#

####################################################################################################
<#
.SYNOPSIS
    Creates an installation marker file for a deployment object.
.DESCRIPTION
    This function creates an installation marker file for a deployment object. The marker file is created at the specified location and contains information about the deployment, such as the application ID, build number, installer, and object type.
    The marker file is used for detection, maintenance, and audit purposes to validate the deployment of the application.
.EXAMPLE
    New-InstallationMarkerFile -DeploymentObject $DeploymentObject -MarkerFileDirectory  "C:\Program Files\Contoso\WebViewer"
    This example creates an installation marker file for the specified deployment object at the given location.
.INPUTS
    [System.Collections.Hashtable]$DeploymentObject - The deployment object that will be processed. It should contain properties such as ApplicationID, BuildNumber, UDFName, and Type.
    [System.String]$MarkerFileDirectory  - The location where the marker file will be created. This should be a valid file path where the deployment has write access.
.OUTPUTS
    No objects are returned to the pipeline. All operational output is written to the host and logged to the deployment logfile.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function New-InstallationMarkerFile {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The deployment object that will be processed.')]
        [System.Collections.Hashtable]$DeploymentObject
    )

    try {
        # VALIDATION
        # Validate the input parameters
        Approve-MandatoryHashtable -Hashtable $DeploymentObject -HashtableDescription 'DeploymentObject'

        # EXECUTION - MARKER FILE
        # Write the message
        Write-Line "Creating the Installation marker file for the function $($DeploymentObject.FunctionNameInBrackets)..."

        # Set the MarkerContent
        [PSCustomObject]$MarkerContent = Get-InstallationMarkerContent -DeploymentObject $DeploymentObject

        # Define the content of the Marker file as a JSON string
        [System.String]$MarkerContentAsString = ConvertTo-Json -InputObject $MarkerContent -Depth 10

        # Create the Marker file at the destination path
        Set-Content -Path $MarkerContent.MarkerFilePath -Value $MarkerContentAsString -Encoding UTF8 -ErrorAction Stop

        # RESULT
        # Write the success message to the host
        Write-Line "Successfully created the Installation marker file at: ($($MarkerContent.MarkerFilePath))"
    }
    catch {
        # ERROR HANDLING
        Write-ErrorReport -ErrorRecord $_
        $PSCmdlet.ThrowTerminatingError($_)
    }
}

# END OF FUNCTION
####################################################################################################
