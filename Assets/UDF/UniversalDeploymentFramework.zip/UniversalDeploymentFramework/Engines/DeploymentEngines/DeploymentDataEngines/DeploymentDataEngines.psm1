#
# Module 'DeploymentDataEngines.psm1'
# Last Update: March 2026
#

####################################################################################################
<#
.SYNOPSIS
    Imports the deployment data from the specified .psd1 file and adds it to the global deployment object for later use.
.DESCRIPTION
    This function takes the file path to the deployment data .psd1 file as input, validates the file, imports the data, and then adds it to the global deployment object for later use in the Deployment Process.
    The deployment data is expected to be defined in a .psd1 file as a hashtable with a key named 'DeploymentObjects' that holds an array of deployment objects to be processed.
.EXAMPLE
    Import-DeploymentData -DeploymentDataFilePath $DeploymentDataFilePath
.INPUTS
    [System.String]$DeploymentDataFilePath
    A string representing the file path to the deployment data .psd1 file that will be used for processing.
.OUTPUTS
    [System.Boolean]$ImportSuccessful
    A boolean value indicating whether the import process was successful or not. Returns $true if the import was successful, and $false if it failed.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : February 2026
    Last Update     : March 2026
#>
####################################################################################################
function Import-DeploymentData {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$false,HelpMessage='The path to the deployment data file that will be imported.')]
        [AllowEmptyString()][AllowNull()][System.String]$DeploymentDataFilePath,

        [Parameter(Mandatory=$false,HelpMessage='Switch for returning the output.')]
        [System.Management.Automation.SwitchParameter]$PassThru
    )

    begin {
        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            DeploymentDataFilePath  = $DeploymentDataFilePath
            Output                  = $null
        }

        # Write the message
        Write-Line "Importing the Deployment Data from the file path ($($CTX.DeploymentDataFilePath))..."
    }

    process {
        try {
            # VALIDATION
            # Validate the Deployment Data file
            Approve-MandatoryPath -Path $CTX.DeploymentDataFilePath -PathDescription 'DeploymentDataFilePath' -ErrorAction Stop

            # EXECUTION - IMPORT
            # Import the Deployment Data from the .psd1 file
            [System.Collections.Hashtable]$DeploymentData = Import-PowerShellDataFile -Path $CTX.DeploymentDataFilePath -ErrorAction Stop
            # Validate the DeploymentData
            $CTX.Output = Test-DeploymentData -DeploymentData $DeploymentData -ErrorAction Stop

            # EXECUTION - ADD TO GLOBAL DEPLOYMENT OBJECT
            # Add the DeploymentData to the Global DeploymentObject for later use
            Add-ToGlobalDeploymentObject -Name DeploymentData -Value $DeploymentData
        }
        catch [System.Management.Automation.RuntimeException] {
            Write-Line "A Runtime Error occurred while importing the Deployment Data." -Type Fail
            $PSCmdlet.ThrowTerminatingError($_)
        }
        catch {
            # ERROR HANDLING
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
    }

    end {
        # OUTPUT
        # Return the output
        if ($PassThru) { $CTX.Output }
    }
}

# END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Retrieves the DeploymentData from the Global DeploymentObject. If a specific property name is provided, it returns the value of that property from the DeploymentData.
.DESCRIPTION
    This function accesses the Global DeploymentObject to retrieve the DeploymentData. If a specific property name is provided as a parameter, it checks if that property exists within the DeploymentData and returns its value. If the property does not exist, it issues a warning and returns null. If no property name is provided, it returns the entire DeploymentData object.
.EXAMPLE
    Get-DeploymentData -PropertyName "ApplicationID"
.INPUTS
    [System.String]$PropertyName 
.OUTPUTS
    [System.Object] The value of the specified property from the DeploymentData. If the property does not exist, it returns null.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : February 2026
    Last Update     : March 2026
#>
####################################################################################################
function Get-DeploymentData {
    [CmdletBinding()]
    [OutputType([System.Object])]
    param (
        [Parameter(Mandatory=$true,HelpMessage='Specify the name of the property to retrieve from the DeploymentData.')]
        [System.String]$PropertyName
    )

    begin{
        # Set the output variable
        [System.Object]$OutputObject = $null
        # Set the DeploymentObject
        [PSCustomObject]$GDO = $Global:DeploymentObject
        # Set the DeploymentData
        [System.Collections.Hashtable]$DeploymentData = $GDO.DeploymentData
    }

    process {
        # VALIDATION
        # Validate the DeploymentObject
        if (-not $GDO) {
            Write-Line "The Global DeploymentObject was not found." -Type Fail
            throw [System.Management.Automation.RuntimeException]
        }
        # Check if the DeploymentData exists in the DeploymentObject
        if (-not $DeploymentData) {
            Write-Line "The DeploymentData hashtable was not found in the Global DeploymentObject." -Type Fail
            throw [System.Management.Automation.RuntimeException]
        }

        # EXECUTION
        # Get the DeploymentData from the DeploymentObject
        $OutputObject = switch ($PropertyName) {
            # Properties from DeploymentData
            'ApplicationID'         { $DeploymentData.ApplicationID }
            'BuildNumber'           { $DeploymentData.BuildNumber }
            'SourceFilesFolder'     { $DeploymentData.SourceFilesFolder }
            'DeploymentObjects'     { $DeploymentData.DeploymentObjects }
            # Properties from DeploymentObject
            'DeploymentAction'      { $GDO.DeploymentAction }
            'DeploymentResult'      { $GDO.DeploymentResult }
            'Rootfolder'            { $GDO.Rootfolder }
            'Workfolder'            { $GDO.Workfolder }
            'LogFolderPath'         { $GDO.LogFolderPath }
            'LogFilePath'           { $GDO.LogFilePath }
            'MSILogFilePath'        { $GDO.MSILogFilePath }
            'UDFName'               { $GDO.Name }
            'UDFVersion'            { $GDO.UDFVersion }
            'DeploymentStartTime'   { $GDO.DeploymentStartTime }
            'DeploymentStopTime'    { $GDO.DeploymentStopTime }
            'DeploymentElapsedTime' { $GDO.DeploymentElapsedTime }
            # Other properties
            #'RegistryPath'          { "HKLM:\SOFTWARE\Application Administration UDF" }
            # test
            'AdministrationRegistryKey' { "SOFTWARE\Application Administration UDF" }
            Default                     { Write-Line "The PropertyName was not found: ($PropertyName)" -Type Fail ; $null }
        }
    }

    end {
        # Return the output
        $OutputObject
    }
    
}

# END OF FUNCTION
####################################################################################################
