#
# Module 'DeploymentDataValidation.psm1'
# Last Update: March 2026
#

####################################################################################################
<#
.SYNOPSIS
    Tests if the provided DeploymentData hashtable contains valid properties.
.DESCRIPTION
    Checks the DeploymentData hashtable for validity. Ensures it is not null or empty, contains the 'ApplicationID' key, and that the value is not null, empty, or a default placeholder. Can be extended to validate additional keys or formats as required by your deployment standards.
.EXAMPLE
    Test-DeploymentData -DeploymentData $DeploymentData
.INPUTS
    [System.Collections.Hashtable]
.OUTPUTS
    [System.Boolean] Returns $true if valid, $false otherwise.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : February 2026
    Last Update     : March 2026
#>
####################################################################################################
function Test-DeploymentData {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The DeploymentData hashtable to test.')]
        [AllowNull()][System.Collections.Hashtable]$DeploymentData
    )

    begin {
        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            DeploymentData  = $DeploymentData
            Output          = $null
        }

        # Write the message
        Write-Line "Validating the Deployment Data..."
    }

    process {
        try {
            # VALIDATION - INPUT
            # Validate the DeploymentData hashtable
            Approve-MandatoryHashtable -Hashtable $CTX.DeploymentData -HashtableDescription 'DeploymentData'

            # EXECUTION
            # Validate the ApplicationID
            Test-ApplicationID -DeploymentData $CTX.DeploymentData -ErrorAction Stop | Out-Null
            # Validate the SourceFilesFolder
            Test-SourceFilesFolder -DeploymentData $CTX.DeploymentData -ErrorAction Stop | Out-Null
            # Validate the BuildNumber
            Test-BuildNumber -DeploymentData $CTX.DeploymentData -ErrorAction Stop | Out-Null
            # Validate the DeploymentObjects
            Test-DeploymentObjects -DeploymentData $CTX.DeploymentData -ErrorAction Stop | Out-Null

            # RESULT
            # Set the output to true if all validations pass
            $CTX.Output = $true
            # Write the success message
            Write-Line "The Deployment Data has been validated. The Deployment Process will now start. (ApplicationID: $($CTX.DeploymentData.ApplicationID))"
        }
        catch [System.Management.Automation.RuntimeException] {
            Write-Line "A runtime error has occurred." -Type Fail
            $PSCmdlet.ThrowTerminatingError($_)
        }
        catch {
            # ERROR HANDLING
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
    }

    end {
        # OUTPUT
        # Return the output
        $CTX.Output
    }
}

# END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Tests if the provided ApplicationID is valid (non-null, non-empty, not default placeholder).
.DESCRIPTION
    Checks the ApplicationID for validity. Ensures it is not null, empty, or a default placeholder value.
.EXAMPLE
    Test-ApplicationID -DeploymentData $DeploymentData
.INPUTS
    [System.Collections.Hashtable] The DeploymentData hashtable containing the ApplicationID key to test.
.OUTPUTS
    [System.Boolean] Returns $true if valid, $false otherwise.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : February 2026
    Last Update     : March 2026
#>
####################################################################################################
function Test-ApplicationID {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$false, HelpMessage='The DeploymentData hashtable to test.')]
        [AllowNull()][System.Collections.Hashtable]$DeploymentData
    )

    begin {
        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            DeploymentData  = $DeploymentData
            PropertyName    = 'ApplicationID'
            DefaultValue    = '<<APPLICATIONID>>'
            RegexPattern    = '^(?<VendorName>[A-Za-z][A-Za-z0-9-]*[A-Za-z0-9])_(?<ApplicationName>[A-Za-z][A-Za-z0-9-]*[A-Za-z0-9])_(?<ApplicationVersion>\d+\.\d+(?:\.\d+)?)$'
            Output          = $null
        }

        # VALIDATION - INPUT
        # Validate the keyname
        Test-DeploymentDataProperty -Hashtable $CTX.DeploymentData -Key $CTX.PropertyName -ErrorAction Stop | Out-Null
    }

    process {
        try {
            # EXECUTION
            # Validate the ApplicationID value
            [System.String]$ApplicationID = $CTX.DeploymentData[$CTX.PropertyName]
            # Test if the ApplicationID is null or empty
            if (Test-String -IsEmpty $ApplicationID) {
                Write-Line "The $($CTX.PropertyName) value is null or empty." -Type Fail
                throw [System.Management.Automation.RuntimeException] }
            # Test if the ApplicationID is still set to the default placeholder value
            if ($ApplicationID -eq $CTX.DefaultValue) {
                Write-Line "The $($CTX.PropertyName) is still set to the default placeholder value ($($CTX.DefaultValue)). Please provide a valid ApplicationID." -Type Fail
                throw [System.Management.Automation.RuntimeException]
            }
            # Validate the format of the ApplicationID using a regex pattern
            if ($ApplicationID -match $CTX.RegexPattern) {
                # Add the elements of the ApplicationID to the Global DeploymentObject for later use
                Add-ToGlobalDeploymentObject -Name VendorName -Value $Matches.VendorName
                Add-ToGlobalDeploymentObject -Name ApplicationName -Value $Matches.ApplicationName
                Add-ToGlobalDeploymentObject -Name ApplicationVersion -Value $Matches.ApplicationVersion
            } else {
                Write-Line "The $($CTX.PropertyName) value ('$ApplicationID') does not match the expected format (VendorName_ApplicationName_ApplicationVersion)." -Type Fail
                throw [System.Management.Automation.RuntimeException]
            }

            # RESULT
            # Set the output to true if all validations pass
            $CTX.Output = $true
            # Write the success message
            Write-Line "The $($CTX.PropertyName) is valid. ($ApplicationID)"
        }
        catch [System.Management.Automation.RuntimeException] {
            Write-Line "A runtime error has occurred." -Type Fail
            $PSCmdlet.ThrowTerminatingError($_)
        }
        catch {
            # ERROR HANDLING
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
    }

    end {
        # OUTPUT
        # Return the output
        $CTX.Output
    }
}

# END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Tests if the provided SourceFilesFolder is valid (non-null, non-empty).
.DESCRIPTION
    Checks the SourceFilesFolder for validity. Ensures it is not null or empty.
.EXAMPLE
    Test-SourceFilesFolder -DeploymentData $DeploymentData
.INPUTS
    [System.Collections.Hashtable] The DeploymentData hashtable containing the SourceFilesFolder key to test.
.OUTPUTS
    [System.Boolean] Returns $true if valid, $false otherwise.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : February 2026
    Last Update     : March 2026
#>
####################################################################################################
function Test-SourceFilesFolder {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$false, HelpMessage='The DeploymentData hashtable to test.')]
        [AllowNull()][System.Collections.Hashtable]$DeploymentData
    )
    begin {
        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            DeploymentData  = $DeploymentData
            PropertyName    = 'SourceFilesFolder'
            Output          = $null
        }

        # VALIDATION
        # Validate the SourceFilesFolder key
        Test-DeploymentDataProperty -Hashtable $CTX.DeploymentData -Key $CTX.PropertyName -ErrorAction Stop | Out-Null
    }
    process {
        try {
            # EXECUTION
            # Validate the SourceFilesFolder value
            [System.String]$SourceFilesFolder = $CTX.DeploymentData[$CTX.PropertyName]
            if (Test-String -IsEmpty $SourceFilesFolder) {
                Write-Line "The $($CTX.PropertyName) value is null or empty." -Type Fail
                throw [System.Management.Automation.RuntimeException]
            }
            # If the SourceFilesFolder value is not 'Default', validate that the folder exists
            if (($SourceFilesFolder -ne 'Default') -and -not(Test-Path -Path $SourceFilesFolder -PathType Container)) {
                Write-Line "The $($CTX.PropertyName) ($SourceFilesFolder) cannot be found." -Type Fail
                throw [System.Management.Automation.RuntimeException]
            }

            # RESULT
            # Set the output to true if all validations pass
            $CTX.Output = $true
            # Write the success message
            Write-Line "The $($CTX.PropertyName) is valid. ($SourceFilesFolder)"
        }
        catch [System.Management.Automation.RuntimeException] {
            Write-Line "A runtime error has occurred." -Type Fail
            $PSCmdlet.ThrowTerminatingError($_)
        }
        catch {
            # ERROR HANDLING
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
    }

    end {
        # OUTPUT
        # Return the output
        $CTX.Output
    }
}

# END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Tests if the provided BuildNumber is valid (non-null, non-empty).
.DESCRIPTION
    Checks the BuildNumber for validity. Ensures it is not null or empty.
.EXAMPLE
    Test-BuildNumber -DeploymentData $DeploymentData
.INPUTS
    [System.Collections.Hashtable] The DeploymentData hashtable containing the BuildNumber key to test.
.OUTPUTS
    [System.Boolean] Returns $true if valid, $false otherwise.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : February 2026
    Last Update     : March 2026
#>
####################################################################################################
function Test-BuildNumber {
    param (
        [Parameter(Mandatory=$false, HelpMessage='The DeploymentData hashtable to test.')]
        [AllowNull()][System.Collections.Hashtable]$DeploymentData
    )
    begin {
        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            DeploymentData  = $DeploymentData
            PropertyName    = 'BuildNumber'
            Output          = $null
        }

        # VALIDATION
        # Validate the BuildNumber key
        Test-DeploymentDataProperty -Hashtable $CTX.DeploymentData -Key $CTX.PropertyName -ErrorAction Stop | Out-Null
    }
    process {
        try {
            # EXECUTION
            # Validate the BuildNumber value
            [System.String]$BuildNumber = $CTX.DeploymentData[$CTX.PropertyName]
            if (Test-String -IsEmpty $BuildNumber) {
                Write-Line "The $($CTX.PropertyName) value is null or empty." -Type Fail
                throw [System.Management.Automation.RuntimeException]
            }
            # Validate the numeric format of the BuildNumber value
            [System.Int32]$ParsedBuildNumber = [System.Int32]::TryParse($BuildNumber, [ref]$null)
            if (-not $ParsedBuildNumber) {
                Write-Line "The $($CTX.PropertyName) value ('$BuildNumber') is not in a valid numeric format." -Type Fail
                throw [System.Management.Automation.RuntimeException]
            }

            # RESULT
            # Set the output to true if all validations pass
            $CTX.Output = $true
            # Write the success message
            Write-Line "The $($CTX.PropertyName) is valid. ($BuildNumber)"
        }
        catch [System.Management.Automation.RuntimeException] {
            Write-Line "A runtime error has occurred." -Type Fail
            $PSCmdlet.ThrowTerminatingError($_)
        }
        catch {
            # ERROR HANDLING
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
    }

    end {
        # OUTPUT
        # Return the output
        $CTX.Output
    }
    
}

# END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Tests if the provided DeploymentObjects property is valid (non-null, non-empty).
.DESCRIPTION
    Checks the DeploymentObjects property for validity. Ensures it is not null or empty.
.EXAMPLE
    Test-DeploymentObjects -DeploymentData $DeploymentData
.INPUTS
    [System.Collections.Hashtable] The DeploymentData hashtable containing the DeploymentObjects key to test.
.OUTPUTS
    [System.Boolean] Returns $true if valid, $false otherwise.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : February 2026
    Last Update     : March 2026
#>
####################################################################################################
function Test-DeploymentObjects {
    param (
        [Parameter(Mandatory=$false, HelpMessage='The DeploymentData hashtable to test.')]
        [AllowNull()][System.Collections.Hashtable]$DeploymentData
    )

    begin {
        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            DeploymentData  = $DeploymentData
            PropertyName    = 'DeploymentObjects'
            Output          = $null
        }

        # VALIDATION - INPUT
        # Validate the DeploymentObjects key
        Test-DeploymentDataProperty -Hashtable $CTX.DeploymentData -Key $CTX.PropertyName -ErrorAction Stop | Out-Null
    }

    process {
        try {
            # EXECUTION
            # Validate the DeploymentObjects value
            [System.Collections.Hashtable[]]$DeploymentObjects = $CTX.DeploymentData[$CTX.PropertyName]
            if (Test-Array -IsEmpty $DeploymentObjects) {
                Write-Line "The $($CTX.PropertyName) value is null or empty." -Type Fail ; throw [System.Management.Automation.RuntimeException]
            }

            # RESULT
            # Set the output to true if all validations pass
            $CTX.Output = $true
            # Write the success message
            Write-Line "The $($CTX.PropertyName) array is valid."
        }
        catch [System.Management.Automation.RuntimeException] {
            Write-Line "A runtime error has occurred." -Type Fail
            $PSCmdlet.ThrowTerminatingError($_)
        }
        catch {
            # ERROR HANDLING
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
    }

    end {
        # OUTPUT
        # Return the output
        $CTX.Output
    }
}

# END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Helper function to test if a hashtable contains a key.
.DESCRIPTION
    Checks if the specified key exists in the hashtable.
.EXAMPLE
    Test-DeploymentDataProperty -Hashtable $DeploymentData -Key 'ApplicationID'
.INPUTS
    [System.Collections.Hashtable] The hashtable to check.
    [System.String] The key to look for in the hashtable.
.OUTPUTS
    [System.Boolean] Returns $true if the key exists, $false otherwise.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : February 2026
    Last Update     : March 2026
#>
####################################################################################################
function Test-DeploymentDataProperty {
    param (
        [Parameter(Mandatory=$true, HelpMessage='The hashtable to check.')]
        [System.Collections.Hashtable]$Hashtable,

        [Parameter(Mandatory=$true, HelpMessage='The key to look for in the hashtable.')]
        [System.String]$KeyName
    )
    begin {
        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            Hashtable   = $Hashtable
            KeyName     = $KeyName
            Output      = $null
        }
    }

    process {
        try {
            # Check if the hashtable contains the specified keyname
            if (-not $CTX.Hashtable.ContainsKey($CTX.KeyName)) {
                Write-Line "DeploymentData does not contain the key ($($CTX.KeyName))." -Type Fail
                throw [System.Management.Automation.RuntimeException]
            } else {
                # Set the output to true if the keyname exists
                $CTX.Output = $true
            }
        }
        catch [System.Management.Automation.RuntimeException] {
            Write-Line "A runtime error has occurred." -Type Fail
            $PSCmdlet.ThrowTerminatingError($_)
        }
        catch {
            # ERROR HANDLING
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
    }

    end {
        # Return the output
        $CTX.Output
    }
}

# END OF FUNCTION
####################################################################################################

