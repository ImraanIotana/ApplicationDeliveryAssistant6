#
# Module 'ExecutableEngine.psm1'
# Last Update: March 2026
#

####################################################################################################
<#
.SYNOPSIS
    Starts a local executable with the specified arguments.
.DESCRIPTION
    This function executes a local executable based on the provided parameters.
    It checks if the executable path is valid and then runs the executable with the specified arguments.
.EXAMPLE
    Start-Executable -Path "C:\Demo\Executable.exe" -ArgumentList "arg1", "arg2"
.INPUTS
    [System.String]$Path
    The path to the executable that will be run.
    [System.String[]]$ArgumentList
    The list of arguments that will be passed to the executable.
    [System.Int32[]]$SuccessExitCodes
    The list of exit codes that will be considered as a successful deployment.
.OUTPUTS
    [System.Boolean]$DeploymentSuccess
    A boolean value indicating whether the deployment was successful or not.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Start-Executable {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The path to the executable that will be run.')]
        [System.String]$Path,

        [Parameter(Mandatory=$false,HelpMessage='The list of arguments that will be passed to the executable.')]
        [System.String[]]$ArgumentList,

        [Parameter(Mandatory=$false,HelpMessage='The list of exit codes that will be considered as a successful deployment.')]
        [System.Int32[]]$SuccessExitCodes = @(0)
    )
    
    begin {
        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            ExecutablePath      = $Path
            ArgumentList        = $ArgumentList
            SuccessExitCodes    = $SuccessExitCodes
            Output              = $null
        }
        # Add the known MSI Error codes to the context
        $CTX.KnownMSIErrorCodes = @{
            1603    = "Please check if you have Administrative privileges."
            1622    = "There was an issue with the log file."
            1639    = "There was an issue with the command line options."
        }
    }

    process {
        try {
            # VALIDATION
            # Check if the executable path is valid
            Approve-MandatoryPath -Path $CTX.ExecutablePath -PathDescription 'Path' -ErrorAction Stop

            # EXECUTION
            # Run the executable
            if (Test-Array -IsEmpty $CTX.ArgumentList) {
                Write-Line "Running the executable without arguments: ($($CTX.ExecutablePath))"
                [System.Diagnostics.Process]$ParentProcess = (Start-Process -FilePath $CTX.ExecutablePath -PassThru)
            } else {
                Write-Line "Running the executable: ($($CTX.ExecutablePath))"
                Write-Line "With the following arguments: ($($CTX.ArgumentList -join ' '))."
                [System.Diagnostics.Process]$ParentProcess = (Start-Process -FilePath $CTX.ExecutablePath -ArgumentList $CTX.ArgumentList -PassThru)
            }
            # Wait for the executable to finish and get the exit code
            Write-Line "One moment please. Waiting for the Process to finish... (Process Name: ($($ParentProcess.Name)) - Process PID: ($($ParentProcess.Id)))" -Type Busy
            $ParentProcess.WaitForExit()
            # Set the exit code of the executable
            [System.Int32]$ExitCode = $ParentProcess.ExitCode

            # RESULT - WRITE RESULT
            # Write the exit code to the host
            Write-Line "The exit code of the executable is: $ExitCode"
            # Check if the exit code is in the list of success exit codes
            [System.Boolean]$ExecutableRanSuccessfully = ($CTX.SuccessExitCodes -contains $ExitCode)
            if ($ExecutableRanSuccessfully) {
                # If the executable ran successfully, write a success message to the host
                Write-Line "The exit code ($ExitCode) is in the list of success exit codes ($($CTX.SuccessExitCodes -join ',')). The deployment was successful."
            } else {
                # If the executable did not run successfully, write a failure message to the host
                Write-Line "The exit code ($ExitCode) is NOT in the list of success exit codes ($($CTX.SuccessExitCodes -join ',')). The deployment has failed." -Type Fail
                # If the exit code is a known MSI error code, write the specific MSI error message to the host
                if ((Split-Path -Path $CTX.ExecutablePath -Leaf) -eq 'msiexec.exe') {
                    if ($CTX.KnownMSIErrorCodes.ContainsKey($ExitCode)) {
                        Write-Line "MSI Error $($ExitCode): $($CTX.KnownMSIErrorCodes[$ExitCode])" -Type Fail
                    }
                }
            }

            # RESULT - SET OUTPUT
            # Set the output
            $CTX.Output = $ExecutableRanSuccessfully
        }
        catch [System.Management.Automation.RuntimeException] {
            $PSCmdlet.ThrowTerminatingError($_)
        }
        catch {
            # ERROR HANDLING
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
    }
    
    end {
        # OUTPUT
        # Return the output
        $CTX.Output
    }
}

### END OF FUNCTION
####################################################################################################
