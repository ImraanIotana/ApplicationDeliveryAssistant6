#
# Module 'MSIMainEngines.psm1'
# Last Update: March 2026
#

####################################################################################################
<#
.SYNOPSIS
    Installation and Uninstallation of MSI packages based on the deployment object.
.DESCRIPTION
    This function handles the deployment of MSI packages based on the provided deployment object.
    It checks if the deployment is required and then executes the appropriate installation or uninstallation actions.
.EXAMPLE
    Start-MSIDeployment -DeploymentObject $DeploymentObject
.INPUTS
    [System.Collections.Hashtable]
.OUTPUTS
    [System.Boolean]
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Start-MSIDeployment {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The deployment object that will be processed.')]
        [System.Collections.Hashtable]$DeploymentObject
    )
    
    begin {
        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            DeploymentObject    = $DeploymentObject
            Output              = $null
        }
    }

    process {
        try {
            # EXECUTION
            # Switch on the DeploymentAction
            $CTX.Output = switch ($CTX.DeploymentObject.DeploymentAction ) {
                'Install'   { Install-MSI -DeploymentObject $CTX.DeploymentObject -ErrorAction Stop }
                'Uninstall' { Uninstall-MSI -DeploymentObject $CTX.DeploymentObject -ErrorAction Stop }
            }
        }
        catch [System.Management.Automation.RuntimeException] {
            Write-Line "A runtime error has occurred during the MSI deployment." -Type Fail
            $PSCmdlet.ThrowTerminatingError($_)
        }
        catch {
            # ERROR HANDLING
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
        
    }
    
    end {
        # OUTPUT
        # Return the output of the deployment process
        $CTX.Output
    }
}

### END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    This function installs an MSI package based on the properties provided in the deployment object.
.DESCRIPTION
    The Install-MSI function takes a deployment object as input, which contains the necessary information to identify and install an MSI package.
    It constructs the appropriate command-line arguments for msiexec.exe and executes the installation process. The function also handles logging and error reporting.
.EXAMPLE
    Install-MSI -DeploymentObject $DeploymentObject
.INPUTS
    [System.Collections.Hashtable]$DeploymentObject
    The deployment object that will be processed.
.OUTPUTS
    [System.Boolean]$DeploymentSuccess
    A boolean value indicating whether the deployment was successful or not.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Install-MSI {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The deployment object that will be processed.')]
        [System.Collections.Hashtable]$DeploymentObject
    )

    begin {
        # PREPARATION - CONTEXT
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            # Input
            DeploymentObject    = $DeploymentObject
            # Handlers
            ArgumentList        = [System.Collections.ArrayList]@()
            MSPFullPathList     = [System.Collections.ArrayList]@()
            InstallResultList   = [System.Collections.ArrayList]@()
            MSIExecutablePath   = Get-SystemPath -Name Msiexec -ErrorAction Stop
            MSIArgumentFix      = '/I "{0}"'
            MSTArgumentFix      = 'TRANSFORMS="{0}"'
            DisplayArgument     = '/QN'
            LoggingArgumentFix  = '/L*V "{0}"'
            MSILogFilePath      = Get-DeploymentData -PropertyName MSILogFilePath -ErrorAction Stop
            # Output
            Output              = $null
        }
    }

    process {
        try {
            # VALIDATION - VALIDATE THE MSP'S IF SPECIFIED
            # If MSP patches are specified, validate that they exist before proceeding with the MSI installation.
            if (Test-Array -IsPopulated $CTX.DeploymentObject.MSPFileNames) {
                foreach ($MSPFileName in $CTX.DeploymentObject.MSPFileNames) {
                    $CTX.MSPFullPathList.Add((Get-SourceItem -FileName $MSPFileName -ErrorAction Stop)) | Out-Null
                }
            }

            # PREPARATION - MSI ARGUMENT
            # Add the MSI Properties to the context
            $CTX.MSIFilePath = Get-SourceItem -FileName $CTX.DeploymentObject.MSIFileName -ErrorAction Stop
            # Add the MSI Argument for the MSI file to the context
            $CTX.ArgumentList.Add($CTX.MSIArgumentFix -f $CTX.MSIFilePath) | Out-Null

            # PREPARATION - MST ARGUMENT
            # If an MST file is specified, add it to the context
            if ($CTX.DeploymentObject.MSTFileName) {
                $CTX.MSTFilePath = Get-SourceItem -FileName $CTX.DeploymentObject.MSTFileName -ErrorAction Stop
                $CTX.ArgumentList.Add(($CTX.MSTArgumentFix -f $CTX.MSTFilePath)) | Out-Null
            }

            # PREPARATION - ADDITIONAL ARGUMENTS
            # If AdditionalArguments are specified, add them to the context
            if (Test-Array -IsPopulated $CTX.DeploymentObject.AdditionalArguments) {
                $CTX.ArgumentList.AddRange($CTX.DeploymentObject.AdditionalArguments) | Out-Null
            } else {
                Write-Line "No additional arguments specified for this MSI deployment."
            }

            # PREPARATION - DISPLAY ARGUMENT
            # Add the display argument to the context
            $CTX.ArgumentList.Add($CTX.DisplayArgument) | Out-Null

            # PREPARATION - LOGGING ARGUMENT
            # Add the logging argument to the context
            $CTX.ArgumentList.Add(($CTX.LoggingArgumentFix -f $CTX.MSILogFilePath)) | Out-Null

            # EXECUTION - INSTALL MSI
            # Install the MSI by running the msiexec executable with the appropriate arguments
            $CTX.InstallResultList.Add((Start-Executable -Path $CTX.MSIExecutablePath -ArgumentList $CTX.ArgumentList -SuccessExitCodes $CTX.DeploymentObject.InstallSuccessExitCodes -ErrorAction Stop)) | Out-Null

            # EXECUTION - MSP PATCHES
            # If MSP patches are specified, install them after the MSI installation.
            if (Test-Array -IsPopulated $CTX.MSPFullPathList) {
                foreach ($MSPFullPath in $CTX.MSPFullPathList) {
                    $CTX.InstallResultList.Add((Install-MSP -Path $MSPFullPath -ErrorAction Stop)) | Out-Null
                }
            }

            # RESULT EVALUATION
            # If any of the installation steps failed, set the output to false. Otherwise, set it to true.
            $CTX.Output = (Test-ArrayContainsOnlyTrue -Array $CTX.InstallResultList)
        }
        catch {
            # ERROR HANDLING
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
    }

    end{
        # OUTPUT
        # Return the output
        $CTX.Output
    }
}

# END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Installs an MSP patch for an MSI package based on the provided path.
.DESCRIPTION
    The Install-MSP function takes the path of an MSP file as input, validates it, and then constructs the appropriate command-line arguments to install the patch using msiexec.exe.
    The function also handles logging and error reporting to ensure that any issues during the installation process are properly captured and reported.
.EXAMPLE
    Install-MSP -Path "C:\Patches\Update.msp"
.INPUTS
    [System.String]$Path
    The file path of the MSP patch to be installed.
.OUTPUTS
    [System.Boolean]$CTX.Output
    A boolean value indicating whether the MSP patch was successfully installed or not.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Install-MSP {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The path of the MSP file to be installed.')]
        [System.String]$Path
    )

    begin {
        # PREPARATION - CONTEXT
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            # Input
            MSPPath             = $Path
            # Handlers
            ArgumentList        = [System.Collections.ArrayList]@()
            MSIExecutablePath   = Get-SystemPath -Name Msiexec -ErrorAction Stop
            MSPArgumentFix      = '/P "{0}"'
            DisplayArgument     = '/QN'
            LoggingArgumentFix  = '/L*V "{0}"'
            MSILogFilePath      = Get-DeploymentData -PropertyName MSILogFilePath -ErrorAction Stop
            # Output
            Output              = $true
        }
    }

    process {
        try {
            # VALIDATION - INPUT
            # Validate the MSP path
            Approve-MandatoryPath -Path $CTX.MSPPath -PathDescription 'Path' -ErrorAction Stop

            # PREPARATION - MSP ARGUMENT
            # Add the MSP path to the argument list.
            $CTX.ArgumentList.Add(($CTX.MSPArgumentFix -f $CTX.MSPPath)) | Out-Null

            # PREPARATION - DISPLAY ARGUMENT
            # Add the display argument.
            $CTX.ArgumentList.Add($CTX.DisplayArgument) | Out-Null

            # PREPARATION - LOGGING ARGUMENT
            # Add the logging argument.
            $CTX.ArgumentList.Add(($CTX.LoggingArgumentFix -f $CTX.MSILogFilePath)) | Out-Null

            # EXECUTION - INSTALL MSP
            # Install the MSP by running msiexec with the prepared arguments.
            [System.Boolean]$PatchInstalled = (Start-Executable -Path $CTX.MSIExecutablePath -ArgumentList $CTX.ArgumentList -SuccessExitCodes $CTX.DeploymentObject.InstallSuccessExitCodes -ErrorAction Stop)
            if (-not $PatchInstalled) { $CTX.Output = $false }
        }
        catch {
            # ERROR HANDLING
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
    }

    end {
        # OUTPUT
        # Return the output
        $CTX.Output
    }
}

# END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    This function uninstalls an MSI package based on the properties provided in the deployment object.
.DESCRIPTION
    The Uninstall-MSI function takes a deployment object as input, which contains the necessary information to identify and uninstall an MSI package.
    It constructs the appropriate command-line arguments for msiexec.exe and executes the uninstallation process. The function also handles logging and error reporting.
.EXAMPLE
    Uninstall-MSI -DeploymentObject $DeploymentObject
.INPUTS
    [System.Collections.Hashtable]$DeploymentObject
    The deployment object that will be processed.
.OUTPUTS
    [System.Boolean]$DeploymentSuccess
    A boolean value indicating whether the deployment was successful or not.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Uninstall-MSI {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The deployment object that will be processed.')]
        [System.Collections.Hashtable]$DeploymentObject
    )

    begin {
        # PREPARATION - CONTEXT
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            # Input
            DeploymentObject    = $DeploymentObject
            # Handlers
            ArgumentList        = [System.Collections.ArrayList]@()
            MSIExecutablePath   = Get-SystemPath -Name Msiexec -ErrorAction Stop
            MSIArgumentFix      = '/X "{0}"'
            DisplayArgument     = '/QN'
            LoggingArgumentFix  = '/L*V "{0}"'
            MSILogFilePath      = Get-DeploymentData -PropertyName MSILogFilePath -ErrorAction Stop
            # Output
            Output              = $null
        }
    }

    process {
        try {
            # PREPARATION - MSI ARGUMENT
            # Add the MSI Properties to the context
            $CTX.MSIFilePath = Get-SourceItem -FileName $CTX.DeploymentObject.MSIFileName -ErrorAction Stop
            # Add the MSI Argument for the MSI file to the context
            $CTX.ArgumentList.Add($CTX.MSIArgumentFix -f $CTX.MSIFilePath) | Out-Null

            # PREPARATION - DISPLAY ARGUMENT
            # Add the display argument to the context
            $CTX.ArgumentList.Add($CTX.DisplayArgument) | Out-Null

            # PREPARATION - LOGGING ARGUMENT
            # Add the logging argument to the context
            $CTX.ArgumentList.Add(($CTX.LoggingArgumentFix -f $CTX.MSILogFilePath)) | Out-Null

            # EXECUTION - UNINSTALL MSI
            # Uninstall the MSI by running the msiexec executable with the appropriate arguments
            $CTX.Output = Start-Executable -Path $CTX.MSIExecutablePath -ArgumentList $CTX.ArgumentList -SuccessExitCodes $CTX.DeploymentObject.UninstallSuccessExitCodes -ErrorAction Stop
        }
        catch {
            # ERROR HANDLING
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
    }

    end{
        # OUTPUT
        # Return the output
        $CTX.Output
    }
}

# END OF FUNCTION
####################################################################################################
