#
# Module 'MSIHelperEngines.psm1'
# Last Update: March 2026
#

####################################################################################################
<#
.SYNOPSIS
    Tests if an MSI package is installed on the system by checking for its product code in the registry.
.DESCRIPTION
    This function tests if an MSI package is installed on the system by checking for its product code in the registry.
.EXAMPLE
    Test-MSIIsInstalled -Path "C:\Path\To\Your.msi"
    Tests if the MSI package at the specified path is installed.
.EXAMPLE
    Test-MSIIsInstalled -ProductCode "{12345678-1234-1234-1234-1234567890AB}"
    Tests if the MSI package with the specified product code is installed.
.INPUTS
    [System.String]
    [System.Management.Automation.SwitchParameter]
.OUTPUTS
    [System.Boolean]
    A boolean value indicating whether the MSI package is installed on the system (true) or not (false).
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Test-MSIIsInstalled {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$true,ParameterSetName='ByPath',HelpMessage='The path to the MSI file.')]
        [AllowEmptyString()][System.String]$Path,

        [Parameter(Mandatory=$true,ParameterSetName='ByProductCode',HelpMessage='The product code of the MSI package.')]
        [AllowEmptyString()][System.String]$ProductCode,

        [Parameter(Mandatory=$false,HelpMessage='Switch for writing the output to the host.')]
        [System.Management.Automation.SwitchParameter]$OutHost
    )
    
    begin {
        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            Path                = $Path
            ProductCode         = $ProductCode
            ParameterSetName    = $PSCmdlet.ParameterSetName
            Output              = $false
        }
    }
    
    process {
        try {
            # VALIDATION - INPUT
            # Switch on the parameter set name to determine which parameters to validate
            switch ($CTX.ParameterSetName) {
                'ByPath'        { Approve-MandatoryPath -Path $CTX.Path -PathDescription 'Path' -ErrorAction Stop }
                'ByProductCode' { Approve-MandatoryString -String $CTX.ProductCode -StringDescription 'ProductCode' -ErrorAction Stop }
            }

            # PREPARATION
            # If the parameter set is ByPath, get the product code from the MSI file
            if ($CTX.ParameterSetName -eq 'ByPath') {
                if ($OutHost) { Write-Line "Adding the product code from the MSI file to the context: ($($CTX.Path))" }
                $CTX.ProductCode = Get-MSIProperty -Path $CTX.Path -PropertyName ProductCode -PassThru -OutHost -ErrorAction Stop
            }

            # EXECUTION
            # Write the message
            if ($OutHost) { Write-Line "Testing if the MSI package is installed by checking the registry for the product code: ($($CTX.ProductCode))" }
            # Test if the MSI package is installed by checking the registry for the product code
            $CTX.Output = Test-ApplicationIsInstalled -KeyName $CTX.ProductCode -OutHost -ErrorAction Stop
            # Write the message
            if ($OutHost) {
                [System.String]$InFix = if ($CTX.Output) { "IS" } else { "IS NOT" }
                Write-Line "The MSI package with product code ($($CTX.ProductCode)) $InFix installed."
            }
        }
        catch [System.Management.Automation.RuntimeException] {
            $PSCmdlet.ThrowTerminatingError($_)
        }
        catch {
            # ERROR HANDLING
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
    }
    
    end {
        # OUTPUT
        # Return the output
        $CTX.Output
    }
}

### END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Tests if an MSI deployment should be performed based on deployment action and installation state.
.DESCRIPTION
    This function resolves the MSI file from the deployment object, determines whether the MSI is already
    installed, and returns whether the deployment should be performed for the specified action.
.EXAMPLE
    Test-MSIDeploymentRequired -DeploymentObject $MyDeploymentObject
.INPUTS
    [System.Collections.Hashtable]
    [System.String]
.OUTPUTS
    [System.Boolean]
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Test-MSIDeploymentRequired {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The deployment object that will be processed.')]
        [System.Collections.Hashtable]$DeploymentObject
    )

    begin {
        # VALIDATION - INPUT
        # Validate the DeploymentObject
        Approve-MandatoryHashtable -Hashtable $DeploymentObject -HashtableDescription 'DeploymentObject'

        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            # Input
            DeploymentObject            = $DeploymentObject
            DeploymentAction            = $DeploymentObject.DeploymentAction
            # Text Handlers
            Text                = @{
                Action          = $DeploymentObject.DeploymentActionInBrackets
                FunctionName    = $DeploymentObject.FunctionNameInBrackets
            }
            # Output
            Output                      = $null
        }
    }

    process {
        try {
            # PREPARATION
            # Write the message
            Write-Line "Evaluating if the Deployment should be performed for the action $($CTX.Text.Action) by the function $($CTX.Text.FunctionName)..."
            # Get the MSI path
            [System.String]$MSIFilePath = Get-SourceItem -FileName $CTX.DeploymentObject.MSIFileName
            # Test if the MSI is installed
            [System.Boolean]$MSIIsInstalled = Test-MSIIsInstalled -Path $MSIFilePath 

            # EXECUTION - EVALUATION
            # Evaluate whether deployment should be performed
            [System.Boolean]$MSIDeploymentShouldBePerformed = switch ($CTX.DeploymentAction) {
                'Install'   { if ($MSIIsInstalled) { $false } else { $true } }
                'Uninstall' { if ($MSIIsInstalled) { $true } else { $false } }
            }

            # OUTPUT
            # Set the output
            $CTX.Output = $MSIDeploymentShouldBePerformed
        }
        catch {
            # ERROR HANDLING
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
    }

    end {
        # OUTPUT
        # Return the output
        $CTX.Output
    }
}

### END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Retrieves a specified property value from an MSI file.
.DESCRIPTION
    This function retrieves the value of a specified property from an MSI file. It uses the Windows Installer API to access the MSI database and extract the property value.
.EXAMPLE
    Get-MSIProperty -Path "C:\Path\To\File.msi" -PropertyName "ProductCode"
.INPUTS
    [System.String]$Path
    The path to the MSI file from which the property will be retrieved.
    [System.String]$PropertyName
    The name of the property to retrieve from the MSI file.
.OUTPUTS
    [System.String]$PropertyValue
    The value of the specified property from the MSI file.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Get-MSIProperty {
    [CmdletBinding()]
    [OutputType([System.String])]
    param (
        [Parameter(Mandatory=$false,HelpMessage='The path to the MSI file.')]
        [AllowEmptyString()][System.String]$Path,

        [Parameter(Mandatory=$false,HelpMessage='The name of the property to retrieve.')]
        [AllowEmptyString()][System.String]$PropertyName,

        [Parameter(Mandatory=$false,HelpMessage='Switch for returning the output.')]
        [System.Management.Automation.SwitchParameter]$PassThru,

        [Parameter(Mandatory=$false,HelpMessage='Switch for writing the output to the host.')]
        [System.Management.Automation.SwitchParameter]$OutHost
    )
    
    begin {
        # VALIDATION - INPUT
        # Test if the Path parameter is empty
        if (Test-String -IsEmpty $Path) {
            Write-Line "The Path parameter is empty. The property cannot be retrieved from the MSI file." -Type Fail
            throw [System.Management.Automation.RuntimeException]
        }
        # Test if the PropertyName parameter is empty
        if (Test-String -IsEmpty $PropertyName) {
            Write-Line "The PropertyName parameter is empty. The property cannot be retrieved from the MSI file." -Type Fail
            throw [System.Management.Automation.RuntimeException]
        }

        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            MSIFilePath         = $Path
            PropertyToRetrieve  = $PropertyName
            Output              = [System.String]::Empty
        }
    }
    
    process {
        try {
            # PREPARATION
            # Write the message
            if ($OutHost) { Write-Line "Retrieving the property ($($CTX.PropertyToRetrieve)) from the MSI file: ($($CTX.MSIFilePath))" }

            # PREPARATION - SUBFUNCTIONS
            # Define the needed subfunctions
            function Get-Property ( $Object, $PropertyName, [object[]]$ArgumentList ) {
                $Object.GetType().InvokeMember($PropertyName, 'Public, Instance, GetProperty', $null, $Object, $ArgumentList)
            }
            function Invoke-Method ( $Object, $MethodName, $ArgumentList ) {
                $Object.GetType().InvokeMember( $MethodName, 'Public, Instance, InvokeMethod', $null, $Object, $ArgumentList )
            }

            # EXECUTION - GET THE PROPERTY VALUE
            # Set the value for read-only mode
            [System.Int32]$OpenMSIReadOnlyMode      = 0
            # Create a new installer object
            [System.__ComObject]$InstallerObject    = New-Object -ComObject WindowsInstaller.Installer
            # Create a new database object
            [System.__ComObject]$DatabaseObject     = Invoke-Method -Object $InstallerObject -MethodName OpenDatabase -ArgumentList ($CTX.MSIFilePath,$OpenMSIReadOnlyMode)
            # Create a view
            [System.__ComObject]$View               = Invoke-Method -Object $DatabaseObject -MethodName OpenView -ArgumentList "SELECT Value FROM Property WHERE Property='$($CTX.PropertyToRetrieve)'"
            # Execute the view
            [Void]( Invoke-Method -Object $View -MethodName Execute )
            # Get the record that contains the property
            Write-Verbose '[Get-MSIPropertyInternal]: Getting the record containing the property...'
            [System.__ComObject]$Record             = Invoke-Method -Object $View -MethodName Fetch
            # Get the stringdata from the record
            Write-Verbose '[Get-MSIPropertyInternal]: Getting the property value from the stringdata of the record...'
            [System.String]$PropertyValue           = Get-Property -Object $Record -PropertyName StringData -ArgumentList 1
            # Close the view
            [Void](Invoke-Method -Object $View -MethodName Close -ArgumentList @())

            # RESULT
            # Write the message
            if ($OutHost) { Write-Line "The value of the property ($($CTX.PropertyToRetrieve)) is: $PropertyValue" }
            # Set the output
            $CTX.Output = $PropertyValue
        }
        catch [System.Management.Automation.RuntimeException] {
            Write-Line "A runtime error has occurred." -Type Fail
            $PSCmdlet.ThrowTerminatingError($_)
        }
        catch {
            Write-ErrorReport -ErrorRecord $_
        }
    }
    
    end {
        # OUTPUT
        # Return the output
        if ($PassThru) { $CTX.Output }
    }
}

### END OF FUNCTION
####################################################################################################
