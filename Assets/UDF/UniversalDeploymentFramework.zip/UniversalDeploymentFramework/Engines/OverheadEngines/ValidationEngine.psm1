#
# Module 'ValidationEngine..psm1'
# Last Update: March 2026
#

####################################################################################################
<#
.SYNOPSIS
    This function tests if a String is empty or populated.
.DESCRIPTION
    Tests if a String is empty or populated. The function has two parameter sets: one for testing if a string is empty, and another for testing if a string is populated.
    Depending on the parameter set used, it returns $true or $false accordingly.
.EXAMPLE
    Test-String -IsEmpty $MyString
.EXAMPLE
    Test-String -IsPopulated $MyString
.INPUTS
    [System.String]
.OUTPUTS
    [System.Boolean]
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : February 2026
    Last Update     : March 2026
#>
####################################################################################################
function Test-String {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$true,ParameterSetName='TestIsEmpty',HelpMessage='The string that will be handled.')]
        [AllowNull()][AllowEmptyString()][System.String]$IsEmpty,

        [Parameter(Mandatory=$true,ParameterSetName='TestIsPopulated',HelpMessage='The string that will be handled.')]
        [AllowNull()][AllowEmptyString()][System.String]$IsPopulated
    )

    begin {
        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            StringToTest        = switch ($PSCmdlet.ParameterSetName) {
                'TestIsEmpty'       { $IsEmpty }
                'TestIsPopulated'   { $IsPopulated }
            }
            ParameterSetName    = $PSCmdlet.ParameterSetName
            Output              = $null
        }
    }
    
    process {
        # Test if the string is empty
        [System.Boolean]$StringIsEmpty = if ( [System.String]::IsNullOrWhiteSpace($CTX.StringToTest) -or [System.String]::IsNullOrEmpty($CTX.StringToTest) ) { $true } else { $false }

        # Set the OutputObject based on the ParameterSetName
        $CTX.Output = switch ($CTX.ParameterSetName) {
            'TestIsEmpty'       { $StringIsEmpty }
            'TestIsPopulated'   { -Not($StringIsEmpty) }
        }
    }
    
    end {
        # Return the output
        $CTX.Output
    }
}

### END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    This function tests if a collection is empty or populated.
.DESCRIPTION
    Tests if a collection is empty or populated. The function has two parameter sets: one for testing if a collection is empty, and another for testing if a collection is populated.
    Depending on the parameter set used, it returns $true or $false accordingly.
.EXAMPLE
    Test-Array -IsEmpty $MyArray
.EXAMPLE
    Test-Array -IsPopulated $MyArray
.INPUTS
    [System.Object[]]
.OUTPUTS
    [System.Boolean]
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Test-Array {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$true,ParameterSetName='TestIsEmpty',HelpMessage='The collection that will be handled.')]
        [AllowNull()][AllowEmptyCollection()][System.Object[]]$IsEmpty,

        [Parameter(Mandatory=$true,ParameterSetName='TestIsPopulated',HelpMessage='The collection that will be handled.')]
        [AllowNull()][AllowEmptyCollection()][System.Object[]]$IsPopulated
    )

    begin {
        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            CollectionToTest    = switch ($PSCmdlet.ParameterSetName) {
                'TestIsEmpty'       { $IsEmpty }
                'TestIsPopulated'   { $IsPopulated }
            }
            ParameterSetName    = $PSCmdlet.ParameterSetName
            Output              = $null
        }
    }

    process {
        # EXECUTION
        # Test if the collection is empty
        [System.Boolean]$CollectionIsEmpty = if ($null -eq $CTX.CollectionToTest) {
            $true
        }
        elseif ($CTX.CollectionToTest.Count -eq 0) {
            $true
        }
        else {
            $false
        }

        # RESULT
        # Set the OutputObject based on the ParameterSetName
        $CTX.Output = switch ($CTX.ParameterSetName) {
            'TestIsEmpty'       { $CollectionIsEmpty }
            'TestIsPopulated'   { -Not($CollectionIsEmpty) }
        }
    }

    end {
        # OUTPUT
        # Return the output
        $CTX.Output
    }
}

### END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    This function tests if a hashtable is empty or populated.
.DESCRIPTION
    Tests if a hashtable is empty or populated. The function has two parameter sets: one for testing if a hashtable is empty,
    and another for testing if a hashtable is populated. Depending on the parameter set used, it returns $true or $false accordingly.
.EXAMPLE
    Test-Hashtable -IsEmpty $MyHashtable
.EXAMPLE
    Test-Hashtable -IsPopulated $MyHashtable
.INPUTS
    [System.Collections.Hashtable]
.OUTPUTS
    [System.Boolean]
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Test-Hashtable {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$true,ParameterSetName='TestIsEmpty',HelpMessage='The hashtable that will be handled.')]
        [AllowNull()][System.Collections.Hashtable]$IsEmpty,

        [Parameter(Mandatory=$true,ParameterSetName='TestIsPopulated',HelpMessage='The hashtable that will be handled.')]
        [AllowNull()][System.Collections.Hashtable]$IsPopulated
    )

    begin {
        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            HashtableToTest     = switch ($PSCmdlet.ParameterSetName) {
                'TestIsEmpty'       { $IsEmpty }
                'TestIsPopulated'   { $IsPopulated }
            }
            ParameterSetName    = $PSCmdlet.ParameterSetName
            Output              = $null
        }
    }

    process {
        # EXECUTION
        # Test if the hashtable is empty
        [System.Boolean]$HashtableIsEmpty = if ($null -eq $CTX.HashtableToTest) {
            $true
        }
        elseif ($CTX.HashtableToTest.Count -eq 0) {
            $true
        }
        else {
            $false
        }

        # RESULT
        # Set the OutputObject based on the ParameterSetName
        $CTX.Output = switch ($CTX.ParameterSetName) {
            'TestIsEmpty'       { $HashtableIsEmpty }
            'TestIsPopulated'   { -Not($HashtableIsEmpty) }
        }
    }

    end {
        # OUTPUT
        # Return the output
        $CTX.Output
    }
}

### END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    This function tests if an array contains only $true values. 
.DESCRIPTION
    Tests if an array contains only $true values. The function returns $true if all elements in the array are $true, and $false otherwise.
.EXAMPLE
    Test-ArrayContainsOnlyTrue -Array $MyArray
.INPUTS
    [System.Object[]]
.OUTPUTS
    [System.Boolean]
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Test-ArrayContainsOnlyTrue {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param(
        [Parameter(Mandatory=$true,HelpMessage='The array that will be tested.')]
        [AllowNull()][AllowEmptyCollection()][System.Object[]]$Array
    )

    begin {
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            ArrayToTest    = $Array
            Output         = $null
        }
    }

    process {
        $CTX.Output = try {
            # Test if the array is null
            if ($null -eq $CTX.ArrayToTest) { Write-Verbose "The Array is null." ; $false }
            # Test if the array is empty
            elseif ($CTX.ArrayToTest.Count -eq 0) { Write-Verbose "The Array is empty." ; $false }
            # Test if the array contains any non-boolean values
            elseif ($CTX.ArrayToTest | Where-Object { $_ -isnot [System.Boolean] }) { Write-Verbose "The Array contains non-boolean values." ; $false }
            # Test if the array contains any $false 
            elseif ($CTX.ArrayToTest -contains $false) { Write-Verbose "The Array contains at least one $false." ; $false }
            # Test if the array contains any $null
            elseif ($CTX.ArrayToTest -contains $null)  { Write-Verbose "The Array contains at least one $null." ; $false }
            # If all tests are passed, return $true
            else { $true }
        }
        catch {
            # ERROR HANDLING
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
    }

    end {
        # Return the output
        $CTX.Output
    }
}

### END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Tests if a file is signed with a valid signature.
.DESCRIPTION
    Tests if a file is signed with a valid signature. The function checks if the file supports signatures, and if so, whether the signature is valid and trusted.
.EXAMPLE
    Test-FileIsSigned -Path "C:\Path\To\File.exe" -OutHost
.INPUTS
    [System.String]$Path
    The path to the file that will be tested.
.OUTPUTS
    [System.Boolean]
    A boolean value indicating whether the file is signed with a valid signature or not.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Test-FileIsSigned {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The path to the file that will be checked.')]
        [AllowEmptyString()][System.String]$Path,

        [Parameter(Mandatory=$false,HelpMessage='Switch for writing the output to the host.')]
        [System.Management.Automation.SwitchParameter]$OutHost
    )
    
    begin {
        # VALIDATION - INPUT
        # Test if the Path parameter is empty
        if (Test-String -IsEmpty $Path) {
            Write-Line "The Path parameter is empty. The file cannot be tested for a signature." -Type Fail
            throw [System.Management.Automation.RuntimeException]
        }

        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            FileToTest  = $Path
            Output      = $null
        }
    }
    
    process {
        try {
            # PREPARATION
            # Write the message
            if ($OutHost) { Write-Line "Testing if the file is signed: $($CTX.FileToTest)" }
            # Get the Authenticode signature of the file
            [System.Management.Automation.Signature]$SignatureObject = Get-AuthenticodeSignature -FilePath $CTX.FileToTest

            # EXECUTION - TEST IF THE FILE SUPPORTS SIGNATURES
            # Test if the file is signable
            [System.Boolean]$DoesNotSupportSignatures = $SignatureObject.SignatureType -eq 'None'
            if ($DoesNotSupportSignatures) {
                if ($OutHost) { Write-Line "The file does not support signatures. ($($CTX.FileToTest))" }
                $CTX.Output = $false
                return
            }

            # EXECUTION - TEST IF THE SIGNATURE IS VALID
            # Get the message based on the signature status
            [System.String]$Message,[System.Boolean]$SignatureIsValid = switch ($SignatureObject.Status) {
                'Valid'         { "The file is signed and the signature is valid. ($($CTX.FileToTest))", $true }
                'NotSigned'     { "The file is not signed. ($($CTX.FileToTest))", $false }
                'UnknownError'  { "An unknown error occurred while testing the file. The signature might be corrupted or unsupported. ($($CTX.FileToTest))", $false }
                'NotTrusted'    { "The file is signed but the signature is not trusted. It may be expired or revoked. ($($CTX.FileToTest))", $false }
                Default         { "An unrecognized signature status was returned: ($($SignatureObject.Status))", $false }
            }

            # RESULT
            # Write the result
            if ($OutHost) { Write-Line $Message }
            # Set the output
            $CTX.Output = $SignatureIsValid
        }
        catch [System.Management.Automation.RuntimeException] {
            Write-Line "A runtime error has occurred." -Type Fail
            $PSCmdlet.ThrowTerminatingError($_)
        }
        catch {
            Write-ErrorReport -ErrorRecord $_
        }
    }
    
    end {
        # OUTPUT
        # Return the output
        $CTX.Output
    }
}

### END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Tests if a mandatory string property of a deployment object is populated.
.DESCRIPTION
    This function tests if a mandatory string is populated.
    If it is populated, it returns $true, otherwise it throws an error.
.EXAMPLE
    Approve-MandatoryString -String $MyString -StringDescription "My String"
    Tests if the string $MyString is populated, and uses "My String" in the error message if it is not populated.
.INPUTS
    [System.String]$String
    The string that will be tested.
    [System.String]$StringDescription
    The name of the string that will be used in the error message if the string is not populated.
.OUTPUTS
    [System.Boolean]
    A boolean value indicating whether the string is populated (true) or not (null).
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Approve-MandatoryString {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The string that will be tested.')]
        [AllowEmptyString()][System.String]$String,

        [Parameter(Mandatory=$true,HelpMessage='The name of the string that will be tested.')]
        [AllowEmptyString()][System.String]$StringDescription,

        [Parameter(Mandatory=$false,HelpMessage='Switch for returning the output.')]
        [System.Management.Automation.SwitchParameter]$PassThru
    )
    
    begin {
        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            StringToTest            = $String
            StringDescription       = $StringDescription
            FirstCallingFunction    = (Get-PSCallStack)[1].Command
            SecondCallingFunction   = (Get-PSCallStack)[2].Command
            Output                  = $null
        }
    }
    
    process {
        try {
            # EXECUTION
            # Test the StringDescription
            if (Test-String -IsEmpty $CTX.StringDescription) {
                throw "The Input Parameter 'StringDescription' string is empty. (Called by [$($CTX.FirstCallingFunction)] <- [$($CTX.SecondCallingFunction)])"
            }
            # Test the String
            if (Test-String -IsEmpty $CTX.StringToTest) {
                throw "The '$($CTX.StringDescription)' string is empty. (Called by [$($CTX.FirstCallingFunction)] <- [$($CTX.SecondCallingFunction)])"
            }

            # RESULT
            # If all tests are passed, set the output to true
            $CTX.Output = $true
        }
        catch {
            # ERROR HANDLING
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
    }
    
    end {
        # OUTPUT
        # Return the output
        if ($PassThru) { $CTX.Output }
    }
}

### END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Approves if a mandatory path exists.
.DESCRIPTION
    This function tests if a mandatory path is populated, and accessible. If it is, it returns $true, otherwise it throws an error.
.EXAMPLE
    Approve-MandatoryPath -Path $MyPath -PathDescription "My Path"
    Tests if the path $MyPath is populated, and uses "My Path" in the error message if it is not populated.
.INPUTS
    [System.String]$Path
    The path that will be tested.
    [System.String]$PathDescription
    The name of the path that will be used in the error message if the path is not populated.
.OUTPUTS
    [System.Boolean]
    A boolean value indicating whether the path is populated (true) or not (null).
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Approve-MandatoryPath {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The path that will be tested.')]
        [AllowEmptyString()][System.String]$Path,

        [Parameter(Mandatory=$true,HelpMessage='The name of the path that will be tested.')]
        [AllowEmptyString()][System.String]$PathDescription,

        [Parameter(Mandatory=$false,HelpMessage='Switch for returning the output.')]
        [System.Management.Automation.SwitchParameter]$PassThru
    )
    
    begin {
        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            PathToTest              = $Path
            PathDescription         = $PathDescription
            CallingFunction         = (Get-PSCallStack)[1].Command
            SecondCallingFunction   = (Get-PSCallStack)[2].Command
            Output                  = $null
        }
    }
    
    process {
        try {
            # VALIDATION
            # Validate the input
            Approve-MandatoryString -String $CTX.PathToTest -StringDescription $CTX.PathDescription -ErrorAction Stop

            # EXECUTION
            # Test the Path
            if (-not (Test-Path -Path $CTX.PathToTest)) {
                throw "The '$($CTX.PathDescription)' path does not exist: $($CTX.PathToTest). (Called by [$($CTX.SecondCallingFunction)] -> [$($CTX.CallingFunction)])"
            }

            # RESULT
            # If all tests are passed, set the output to true
            $CTX.Output = $true
        }
        <#catch [System.Management.Automation.RuntimeException] {
            $PSCmdlet.ThrowTerminatingError($_)
        }#>
        catch {
            # ERROR HANDLING
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
    }
    
    end {
        # OUTPUT
        # Return the output
        if ($PassThru) { $CTX.Output }
    }
}

### END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Approves if a mandatory hashtable is populated.
.DESCRIPTION
    This function tests if a mandatory hashtable is populated. If it is, it returns $true, otherwise it throws an error.
.EXAMPLE
    Approve-MandatoryHashtable -Hashtable $MyHashtable -HashtableDescription 'My Hashtable'
    Tests if the hashtable $MyHashtable is populated, and uses 'My Hashtable' in the error message if it is not populated.
.INPUTS
    [System.Collections.Hashtable]$Hashtable
    The hashtable that will be tested.
    [System.String]$HashtableDescription
    The name of the hashtable that will be used in the error message if the hashtable is not populated.
.OUTPUTS
    [System.Boolean]
    A boolean value indicating whether the hashtable is populated (true) or not (null).
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Approve-MandatoryHashtable {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The hashtable that will be tested.')]
        [AllowNull()][System.Collections.Hashtable]$Hashtable,

        [Parameter(Mandatory=$true,HelpMessage='The name of the hashtable that will be tested.')]
        [AllowEmptyString()][System.String]$HashtableDescription,

        [Parameter(Mandatory=$false,HelpMessage='Switch for returning the output.')]
        [System.Management.Automation.SwitchParameter]$PassThru
    )

    begin {
        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            HashtableToTest         = $Hashtable
            HashtableDescription    = $HashtableDescription
            CallingFunction         = (Get-PSCallStack)[1].Command
            SecondCallingFunction   = (Get-PSCallStack)[2].Command
            Output                  = $null
        }
    }

    process {
        try {
            # VALIDATION
            # Validate the input
            Approve-MandatoryString -String $CTX.HashtableDescription -StringDescription $CTX.HashtableDescription -ErrorAction Stop

            # EXECUTION
            # Test the hashtable
            if (Test-Hashtable -IsEmpty $CTX.HashtableToTest) {
                throw "The '$($CTX.HashtableDescription)' hashtable is empty. (Called by [$($CTX.SecondCallingFunction)] -> [$($CTX.CallingFunction)])"
            }

            # RESULT
            # If all tests are passed, set the output to true
            $CTX.Output = $true
        }
        catch {
            # ERROR HANDLING
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
    }

    end {
        # OUTPUT
        # Return the output
        if ($PassThru) { $CTX.Output }
    }
}

### END OF FUNCTION
####################################################################################################
