#
# Module 'WriteEngine.psm1'
# Last Update: March 2026
#

####################################################################################################
<#
.SYNOPSIS
    Outputs a formatted message to the host with customizable colors for enhanced readability and status indication.
.DESCRIPTION
    Provides a function for writing messages to the host in various colors, supporting multiple message types for deployment and automation scenarios.
.EXAMPLE
    Write-Line "Hello World!"
.EXAMPLE
    Write-Line "Deployment completed successfully." -Type Success
.INPUTS
    [System.String]
.OUTPUTS
    No objects are returned to the pipeline. All operational output is written to the host and logged to the deployment logfile.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : August 2025
    Last Update     : March 2026
#>
####################################################################################################

function Write-Line {
    [CmdletBinding()]
    [OutputType([System.Void])]
    param (
        [Parameter(Mandatory=$false,Position=0,HelpMessage='The message that will be written to the host.')]
        [AllowNull()][AllowEmptyString()]
        [System.String]$Message,

        [Parameter(Mandatory=$false,HelpMessage='Type for deciding the colors.')]
        [ValidateSet('Busy','Success','Fail','Normal','Info','Warning','Special','NoAction',
        'DeploymentStart','FinalSuccess','FinalFail','SuccessNoAction','ValidationSuccess','ValidationFail',
        'Separator','DoubleSeparator','ErrorSeparator')]
        [AllowNull()][AllowEmptyString()]
        [System.String]$Type
    )

    begin {
        ####################################################################################################
        ### MAIN PROPERTIES ###

        # Set the main properties for the message
        [System.String]$OriginalMessage         = $Message
        [System.String]$MessageType             = $Type
        [System.String]$TimeStamp               = Get-TimeStamp -ForHost
        [System.String]$DeploymentAction        = $Global:DeploymentObject.DeploymentAction # When using "Get-DeploymentData -PropertyName DeploymentAction", it causes a loop.
        # Set the calling function
        [System.String]$FirstCallingFunction    = (Get-PSCallStack)[1].Command
        [System.String]$SecondCallingFunction   = (Get-PSCallStack)[2].Command
        [System.String]$CallingFunctionName     = if ($FirstCallingFunction -eq 'Write-DeploymentMessage' -or $FirstCallingFunction -eq 'Write-ErrorReport') { $SecondCallingFunction } else { $FirstCallingFunction }
        [System.String]$CallingFunction         = "[$CallingFunctionName]:"

        ####################################################################################################
    }
    
    process {
        # PREPARATION - MESSAGE FORMATTING
        # Set the message based on the MessageType
        [System.String]$FullMessage = switch ($MessageType) {
            'NoAction'          { 'No action has been taken.' }
            'SuccessNoAction'   { "$TimeStamp $CallingFunction $OriginalMessage`n$TimeStamp $CallingFunction The $($DeploymentAction)-process is considered successful. No action has been taken." }
            'Separator'         { "$TimeStamp ----------------------------------------------------------------------------------------------------" }
            'DoubleSeparator'   { "$TimeStamp ====================================================================================================" }
            'ErrorSeparator'    { "$TimeStamp -------------------------------------ERROR-REPORT---------------------------------------------------" }
            'ValidationSuccess' { "$TimeStamp $CallingFunction The validation is successful. The process will now start." }
            'ValidationFail'    { "$TimeStamp $CallingFunction $OriginalMessage`n$TimeStamp $CallingFunction The validation failed. The process will NOT start." }
            'DeploymentStart'   { "$TimeStamp $CallingFunction [START] $($OriginalMessage.ToUpper())" }
            'FinalSuccess'      { "$TimeStamp $CallingFunction [SUCCESS] $($OriginalMessage.ToUpper())" }
            'FinalFail'         { "$TimeStamp $CallingFunction [FAIL] $($OriginalMessage.ToUpper())" }
            Default             { "$TimeStamp $CallingFunction $OriginalMessage" }
        }

        # PREPARATION - FOREGROUND COLOR SELECTION
        # Set the foreground color based on the MessageType
        [System.String]$ForegroundColor = switch ($MessageType) {
            'Busy'              { 'Yellow' }
            'Success'           { 'Green' }
            'SuccessNoAction'   { 'DarkGray' }
            'FinalSuccess'      { 'Green' }
            'FinalFail'         { 'Yellow' }
            'DeploymentStart'   { 'Cyan' }
            'Normal'            { 'White' }
            'Fail'              { 'Red' }
            'Special'           { 'Cyan' }
            'Separator'         { 'DarkGray' }
            'DoubleSeparator'   { 'Cyan' }
            'ErrorSeparator'    { 'Cyan' }
            'ValidationFail'    { 'Red' }
            'Info'              { 'White' }
            'Warning'           { 'Yellow' }
            Default             { 'DarkGray' }
        }

        # PREPARATION - BACKGROUND COLOR SELECTION
        # Set the background color based on the MessageType
        [System.String]$BackgroundColor = switch ($MessageType) {
            'FinalSuccess'      { 'DarkGreen' }
            'FinalFail'         { 'DarkRed' }
            'DeploymentStart'   { 'DarkCyan' }
            Default             { '' }
        }

        # EXECUTION
        # Write the message
        switch ([System.String]::IsNullOrEmpty($BackgroundColor)) {
            $false  { Write-Host $FullMessage -ForegroundColor $ForegroundColor -BackgroundColor $BackgroundColor }
            $true   { Write-Host $FullMessage -ForegroundColor $ForegroundColor }
        }
    }
    
    end {
    }
}

### END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Writes the full details of an error to the host and logs it to a file.
.DESCRIPTION
    Provides a function for writing the full details of an error to the host in yellow color, including the error message, exception type, invoking function hierarchy and error details.
    The error is also logged to a file in the log folder.
.EXAMPLE
    Write-ErrorReport -ErrorRecord $_
.INPUTS
    [System.Management.Automation.ErrorRecord]$ErrorRecord
    The error record of which the details will be written.
.OUTPUTS
    No objects are returned to the pipeline. All operational output is written to the host and logged to the deployment logfile.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : February 2026
    Last Update     : February 2026
#>
####################################################################################################

function Write-ErrorReport {
    [CmdletBinding()]
    [OutputType([System.Void])]
    param (
        [Parameter(Mandatory=$true,Position=0,HelpMessage='The error record of which the details will be written.')]
        [System.Management.Automation.ErrorRecord]$ErrorRecord
    )
    
    begin {
        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            ErrorRecord     = $ErrorRecord
            ErrorFullName   = $ErrorRecord.Exception.GetType().FullName
            StackTrace      = $ErrorRecord.ScriptStackTrace
            CallingFunction  = (Get-PSCallStack)[1].Command
        }
    }
    
    process {
        # Write the error message and details to the host
        Write-Line -Type ErrorSeparator
        Write-Line "ERRORMESSAGE: [$($CTX.CallingFunction)] has encountered an error." -Type Special
        # Write the original error message (colored)
        [System.String]$ErrorText = ($ErrorRecord | Out-String).Trim()
        Write-Line $ErrorText -Type Warning
        # Write the details to the host
        Write-Line "Please use the following StackTrace of Calling Functions to pinpoint the issue:" -Type Special
        Write-Line "Exception Type: $($CTX.ErrorFullName)"
        # Write the stack trace
        [System.String[]]$TraceLines = $CTX.StackTrace -split "`n"
        # Remove the last 2 lines of the stack trace as they are not relevant (they only contain the line where the error was caught and the line where Write-ErrorReport was called)
        $TraceLines = $TraceLines[0..($TraceLines.Length - 3)]
        # Write the remaining stack trace lines to the host in dark gray color
        foreach ($TraceLine in $TraceLines) {
            if ($TraceLine.TrimStart().StartsWith('at ')) {
                # Remove the "at " from the beginning of the line
                [System.String]$ShortTraceLine = $TraceLine.TrimStart().Substring(3)
                # Split the line into the function part and the file part
                [System.String[]]$Parts = $ShortTraceLine -split ',\s*'
                # Add labels to the parts for better readability
                [System.String[]]$PartsWithLabel = @(("Function`t: " +  $Parts[0]),("In File`t: " +  $Parts[1]))
            }
            $PartsWithLabel | ForEach-Object { Write-Line $_ }
        }
        # Write a separator line
        Write-Line -Type ErrorSeparator
    }
    
    end {
    }
}

### END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Writes deployment information to the Windows Registry for tracking or auditing purposes.
.DESCRIPTION
    This function records key deployment details (such as application name, version, deployment date, and status) to a specified registry path.
    It is useful for maintaining deployment logs or for integration with other management tools.
.EXAMPLE
    Write-DeploymentReport -DeploymentObject $DeploymentObject -RegistryPath "HKLM:\Software\MyCompany\DeploymentLog"
.INPUTS
    None. The function does not take any input parameters.
.OUTPUTS
    No objects are returned to the pipeline. All operational output is written to the host and logged to the deployment logfile.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Write-DeploymentReport {
    [CmdletBinding()]
    [OutputType([System.Void])]
    param (
    )

    begin {
        # PREPARATION
        try {
            # Collect deployment information into a hashtable
            [System.Collections.Hashtable]$DeploymentInformationHashtable = @{
                Deployment_ApplicationID        = Get-DeploymentData -PropertyName ApplicationID
                Deployment_BuildNumber          = Get-DeploymentData -PropertyName BuildNumber
                Deployment_Action               = (Get-DeploymentData -PropertyName DeploymentAction).ToUpper()
                Deployment_Result               = Get-DeploymentData -PropertyName DeploymentResult
                Overhead_LogFilePath            = Get-DeploymentData -PropertyName LogFilePath
                Overhead_Rootfolder             = Get-DeploymentData -PropertyName Rootfolder
                Overhead_ScriptName             = Get-DeploymentData -PropertyName UDFName
                Overhead_ScriptVersion          = Get-DeploymentData -PropertyName UDFVersion
                Overhead_SourceFilesFolder      = Get-DeploymentData -PropertyName SourceFilesFolder
                Timer_DeploymentStartTimeUTC    = Get-DeploymentData -PropertyName DeploymentStartTime
                Timer_DeploymentStopTimeUTC     = Get-DeploymentData -PropertyName DeploymentStopTime
                Timer_ElapsedDeploymentTime     = Get-DeploymentData -PropertyName DeploymentElapsedTime
            }
        }
        catch [System.Management.Automation.RuntimeException] {
            Write-Line "Failed to collect the necessary deployment information for the Deployment Report." -Type Fail
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
        catch {
            Write-ErrorReport -ErrorRecord $_
        }
    }

    process {
        try {
            # PREPARATION - SET REGISTRY KEY
            # Set the registry path where the deployment information will be written
            #[System.String]$RegistryPath            = Get-DeploymentData -PropertyName RegistryPath
            # test
            [System.String]$AdministrationRegistryKey   = Get-DeploymentData -PropertyName AdministrationRegistryKey
            [System.String]$ApplicationLeaf             = "$($DeploymentInformationHashtable.Deployment_ApplicationID)"
            [System.String]$BuildNumberLeaf             = "Build $($DeploymentInformationHashtable.Deployment_BuildNumber)"
            [System.String]$ApplicationRegistryPath     = [System.IO.Path]::Combine($AdministrationRegistryKey, $ApplicationLeaf, $BuildNumberLeaf) #; Write-Object $ApplicationRegistryPath

            # test - open the base registry key with write access to check if we have permissions to write to the registry before attempting to create the key and write the values
            [Microsoft.Win32.RegistryKey]$HKLM64BitsBase = [Microsoft.Win32.RegistryKey]::OpenBaseKey(
                [Microsoft.Win32.RegistryHive]::LocalMachine,
                [Microsoft.Win32.RegistryView]::Registry64
            )
            #write-object $HKLM64BitsBase
            # Attempt to open the registry key with write access to check permissions
            [Microsoft.Win32.RegistryKey]$KeyToWriteInto = $HKLM64BitsBase.OpenSubKey($ApplicationRegistryPath, $true)
            #Write-Object $KeyToWriteInto
            #$TESTPATH = $KeyToWriteInto.Name
            #Write-Object $TESTPATH

            if ($null -eq $KeyToWriteInto) {
                # Add the prefix
                $ApplicationRegistryPath = "HKLM:\$ApplicationRegistryPath"
                Write-Line "The registry key does not exist yet. Creating it now... ($ApplicationRegistryPath)" -Type Busy
                New-RegistryKeyUDF -Path $ApplicationRegistryPath
            }

            # Test if you have Write access to the registry key by trying to open it with write access
            #$HKLM64BitsBase.OpenSubKey($RegistryPath, $true)
            Write-Line "Successfully accessed the Registry with write permissions. Proceeding to write the Deployment Report. ($($KeyToWriteInto.Name))" -Type Success
            

            # EXECUTION - WRITE DEPLOYMENT REPORT INTO REGISTRY
            # Create the Registry key for the application and write the deployment information into it
            Write-Line "Writing the Deployment Report into the Registry ($ApplicationRegistryPath)"
            New-RegistryKeyUDF -Path $ApplicationRegistryPath -AddProperties $DeploymentInformationHashtable -RemoveExistingKey
            # Write the success message
            Write-Line "The Deployment Report has been written into the Registry. ($ApplicationRegistryPath)" -Type Success
        }
        catch [System.Management.Automation.MethodInvocationException] {
            Write-Line "Failed to write into the Registry (MethodInvocationException). Access is denied. ($($KeyToWriteInto.Name))" -Type Fail
            Write-ErrorReport -ErrorRecord $_
        }
        catch [System.Security.SecurityException] {
            Write-Line "Failed to write the new Deployment Report into the Registry (SecurityException). Access is denied. ($ApplicationRegistryPath)" -Type Fail
        }
        catch [System.UnauthorizedAccessException] {
            Write-Line "Failed to write the new Deployment Report into the Registry (UnauthorizedAccessException). Access is denied. ($ApplicationRegistryPath)" -Type Fail
        }
        catch [System.Management.Automation.ItemNotFoundException] {
            Write-Line "Failed to write the new Deployment Report into the Registry (ItemNotFoundException). ($ApplicationRegistryPath)" -Type Fail
        }
        catch {
            Write-ErrorReport -ErrorRecord $_
        }
        finally {
            # Close the base registry key
            $HKLM64BitsBase.Close()
        }
    }

    end {
    }
}

### END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Writes the final result of the deployment process to the host, indicating whether the deployment was successful or if it failed.
.DESCRIPTION
    This function evaluates the overall success of the deployment process based on the results collected in the DeploymentContext.
    It then writes a clear and formatted message to the host indicating whether the deployment was successful or if it failed, along with relevant details such as the application ID and build number.
.EXAMPLE
    Write-DeploymentFinalResult -DeploymentContext $DeploymentContext
.INPUTS
    [System.Collections.Hashtable]$DeploymentContext
    The deployment context containing all relevant information about the deployment process, including the results of each deployment object and overall deployment details.
.OUTPUTS
    No objects are returned to the pipeline. All operational output is written to the host and logged to the deployment logfile.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Write-DeploymentMessage {
    [CmdletBinding()]
    [OutputType([System.Void])]
    param (
        [Parameter(Mandatory=$true,HelpMessage='The deployment context containing all relevant information about the deployment process.')]
        [System.Collections.Hashtable]$DeploymentContext,

        [Parameter(Mandatory=$true,HelpMessage='The type of message to write.')]
        [ValidateSet('StartingMessage','DeployingObjectMessage','DeploymentSuccessMessage','FinalResultMessage')]
        [System.String]$Type
    )
    
    begin {
        # PREPARATION
        # Set the abbreviation
        [System.Collections.Hashtable]$DC = $DeploymentContext
        # Set the ObjectTypeInBrackets for better readability in the messages
        [System.Collections.Hashtable]$CurrentDeploymentObject = $DC.DeploymentObjects[$DC.DeploymentObjectCounter - 1]
        [System.String]$ObjectTypeInBrackets = $CurrentDeploymentObject.ObjectTypeInBrackets        
    }
    #### UPDATE THE TEXT (de brackets) ####
    process {
        try {
            # EXECUTION
            # Switch on the Type
            switch ($Type) {
                'StartingMessage' {
                    # Write the starting message
                    Write-Line -Type DoubleSeparator
                    Write-Line "Starting the $($DC.DeploymentActionInBrackets) of $($DC.ApplicationIDInBrackets) Build $($DC.BuildNumberInBrackets)" -Type DeploymentStart
                    Write-Line "Amount of DeploymentObjects that will be processed: [$($DC.AmountOfDeploymentObjects)]" -Type DeploymentStart
                }
                'DeployingObjectMessage' {
                    # Write the message to the host
                    Write-Line -Type DoubleSeparator
                    Write-Line "[$($DC.DeploymentObjectCounter) of $($DC.AmountOfDeploymentObjects)] Starting the $($DC.DeploymentActionInBrackets) of $ObjectTypeInBrackets..." -Type Special
                }
                'DeploymentSuccessMessage' {
                    # Write the success message
                    Write-Line "[$($DC.DeploymentObjectCounter) of $($DC.AmountOfDeploymentObjects)] The $($DC.DeploymentActionInBrackets) of $ObjectTypeInBrackets was [SUCCESSFUL]." -Type Success
                }
                'FinalResultMessage' {
                    # Write a separator line before the final result for better visibility
                    Write-Line -Type DoubleSeparator
                    if ($DC.FinalDeploymentResult) {
                        # Write the success message
                        Write-Line "The $($DC.DeploymentActionInBrackets) of $($DC.ApplicationIDInBrackets) Build $($DC.BuildNumberInBrackets) was successful." -Type FinalSuccess
                        Write-Line "Build $($DC.BuildNumberInBrackets) - Processed DeploymentObjects [$($DC.AmountOfDeploymentObjects)]" -Type FinalSuccess
                    }
                    else {
                        # Write the failure message
                        Write-Line "The $($DC.DeploymentActionInBrackets) of $ObjectTypeInBrackets of $($DC.ApplicationIDInBrackets) Build $($DC.BuildNumberInBrackets) has failed." -Type FinalFail
                        Write-Line "The $($DC.DeploymentActionInBrackets) has been halted. The remaining DeploymentObjects will not be processed." -Type FinalFail
                    }
                    # Write a separator line after the final result for better visibility
                    Write-Line -Type DoubleSeparator
                }
                Default {}
            }

        }
        catch {
            Write-ErrorReport -ErrorRecord $_
        }
        
    }
    
    end {
    }    
}
### END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Writes an object to the host in a formatted way for enhanced readability.
.DESCRIPTION
    Provides a function for writing an object to the host in a formatted way, including all properties and their values.
.EXAMPLE
    Write-Object -Object $MyObject
.INPUTS
    [System.Object]$Object
    The object that will be written to the host.
.OUTPUTS
    No objects are returned to the pipeline. All operational output is written to the host and logged to the deployment logfile.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Write-Object {
    [CmdletBinding()]
    [OutputType([System.Void])]
    param (
        [Parameter(Mandatory=$true,Position=0,HelpMessage='The object that will be written to the host.')]
        [Alias('InputObject')]
        [AllowNull()][Object]$Object
    )

    begin {
        # Set the calling function
        [System.String]$CallingFunction = (Get-PSCallStack)[1].Command
        # Set the default color
        [System.String]$DefaultColor = 'Cyan'
    }

    process {
        try {
            # VALIDATION
            if ($null -eq $Object) {
                Write-Line "[$CallingFunction] - The Object is null." -Type Info
                return
            }

            # PREPARATION
            [System.String]$ObjectType = $Object.GetType().FullName
            Write-Line "[$CallingFunction] - Object Type: $ObjectType" -Type Info

            # EXECUTION
            # Array: Write each item on a new line
            if ($Object -is [System.Array]) {
                foreach ($item in $Object) {
                    Write-Object -Object $item
                }
            }
            # String: Write the string directly
            elseif ($Object -is [System.String]) {
                Write-Line $Object -Type Special
            }
            # Boolean: Write the boolean value as a string
            elseif ($Object -is [System.Boolean]) {
                Write-Line $Object.ToString() -Type Special
            }
            # ValueType (int, datetime, etc.): Write the value as a string
            elseif ($Object -is [System.ValueType]) {
                Write-Line $Object.ToString() -Type Special
            }
            # Hashtable: Write each key-value pair on a new line
            elseif ($Object -is [System.Collections.Hashtable]) {
                foreach ($Key in $Object.Keys) {
                    Write-Host ("$($Key): ") -ForegroundColor Yellow -NoNewline
                    Write-Host $Object[$Key] -ForegroundColor $DefaultColor
                }
            }
            # Others: Write the full details of the object using Format-List
            else {
                [System.String]$FormattedString = $Object | Format-List * -Force | Out-String
                Write-Host $FormattedString -ForegroundColor $DefaultColor
            }
        }
        catch {
            Write-ErrorReport -ErrorRecord $_
        }
    }

    end {
    }
}

### END OF FUNCTION
####################################################################################################

