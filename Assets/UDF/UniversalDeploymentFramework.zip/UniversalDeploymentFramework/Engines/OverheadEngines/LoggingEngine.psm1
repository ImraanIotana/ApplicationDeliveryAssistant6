#
# Module 'LoggingEngine.psm1'
# Last Update: March 2026
#

####################################################################################################
<#
.SYNOPSIS
    Creates the Log folder if it does not exist and initializes the deployment logfile.
.DESCRIPTION
    This function checks if the Log folder exists at the specified path. If it does not exist, it creates the folder. Then, it initializes the deployment logfile by creating a new log file with a unique name based on the current timestamp and stores the path to this logfile in the Global DeploymentObject for later use.
.EXAMPLE
    Start-Logging
.INPUTS
    No input parameters are required for this function. It operates based on the Global DeploymentObject.
    The function relies on the Global DeploymentObject to determine the path for the Log folder and to store the path to the initialized deployment logfile.
    The Global DeploymentObject is expected to have a property named 'LogFolder' that specifies the path to the Log folder where the deployment logfile will be created, and a property named 'TimeStamp' that provides a unique timestamp for naming the logfile.
    The function will create a new logfile with a name in the format 'DeploymentLog_<TimeStamp>.log' and store the full path to this logfile in the Global DeploymentObject under a property named 'LogFilePath'.
.OUTPUTS
    No objects are returned to the pipeline. All operational output is written to the host and logged to the deployment logfile.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : February 2026
    Last Update     : March 2026
#>
####################################################################################################
function Start-Logging {
    [CmdletBinding()]
    [OutputType([System.Void])]
    param (
    )

    begin {
        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            ApplicationID       = Get-DeploymentData -PropertyName ApplicationID -ErrorAction Stop
            LogFolderPath       = Join-Path -Path $ENV:ProgramData -ChildPath 'Application Administration UDF'
            Timestamp           = Get-TimeStamp -ForFileName
            DeploymentAction    = Get-DeploymentData -PropertyName DeploymentAction -ErrorAction Stop
            UDFVersion          = Get-DeploymentData -PropertyName UDFVersion -ErrorAction Stop
            Username            = $ENV:USERNAME
            ComputerName        = $ENV:COMPUTERNAME
            Output              = $null
        }
        # PROPERTIES
        # Add the LogFolder to the Global DeploymentObject for later use
        Add-ToGlobalDeploymentObject -Name LogFolderPath -Value $CTX.LogFolderPath
    }

    process {
        try {
            # VALIDATION
            # Validate the LogFolderPath
            Approve-MandatoryString -String $CTX.LogFolderPath -StringDescription 'LogFolderPath' -ErrorAction Stop

            # PREPARATION - APPLICATION LOG FOLDER
            # Set the specific ApplicationLogFolder based on the ApplicationID
            [System.String]$CTX.ApplicationLogFolder = Join-Path -Path $CTX.LogFolderPath -ChildPath $CTX.ApplicationID
            # Create the ApplicationID Log folder
            New-FolderUDF -Path $CTX.ApplicationLogFolder

            # PREPARATION - LOG FILES
            # Add the LogFilePath to the Global DeploymentObject for later use
            [System.String]$LogFileCircumfix = "$($CTX.ApplicationID)_UTC_$($CTX.Timestamp)_{0}.log"
            [System.String]$CTX.LogFilePath = Join-Path -Path $CTX.ApplicationLogFolder -ChildPath ($LogFileCircumfix -f $CTX.DeploymentAction)
            Add-ToGlobalDeploymentObject -Name LogFilePath -Value $CTX.LogFilePath
            # Add the MSILogFilePath to the Global DeploymentObject for later use by the MSI functions
            [System.String]$CTX.MSILogFilePath = Join-Path -Path $CTX.ApplicationLogFolder -ChildPath ($LogFileCircumfix -f "MSI_$($CTX.DeploymentAction)")
            Add-ToGlobalDeploymentObject -Name MSILogFilePath -Value $CTX.MSILogFilePath

            # EXECUTION - START LOGGING
            # Start the logging process
            [System.Void](Start-Transcript -Path $CTX.LogFilePath -Append -IncludeInvocationHeader)
            Write-Line "Started logging. Logfile: ($($CTX.LogFilePath))"
            Write-Line -Type Separator

            # LOGGING - DEPLOYMENT INFORMATION
            # Write the Copyright notice to the log
            Write-Line "This Deployment is executed by the Universal Deployment Framework version ($($CTX.UDFVersion)). Copyright (C) Iotana. All rights reserved."
            Write-Line "This Deployment is performed by user ($($CTX.Username)) on machine ($($CTX.ComputerName))."
            Write-Line "All timestamps are in UTC-format [yyyy-MM-dd HH:mm:ss.fff]."
        }
        catch [System.Management.Automation.RuntimeException] {
            $PSCmdlet.ThrowTerminatingError($_)
        }
        catch {
            # ERROR HANDLING
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
    }

    end {
    }
}

# END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Stops the logging process by ending the transcript session.
.DESCRIPTION
    This function ends the transcript session that was started by the Start-Logging function.
.EXAMPLE
    Stop-Logging
.INPUTS
    No input parameters are required for this function. It operates based on the Global DeploymentObject.
.OUTPUTS
    No objects are returned to the pipeline. All operational output is written to the host and logged to the deployment logfile.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : February 2026
    Last Update     : February 2026
#>
####################################################################################################
function Stop-Logging {
    [CmdletBinding()]
    [OutputType([System.Void])]
    param (
    )

    begin {
        # Set the LogFilePath
        [System.String]$LogFilePath = Get-DeploymentData -PropertyName LogFilePath
    }

    process {
        try {
            # Stop the transcript session to finalize logging
            Write-Line "Stopped logging. Logfile saved at the following path: ($LogFilePath)"
            [System.Void](Stop-Transcript)
        }
        catch [System.Management.Automation.PSInvalidOperationException] {
            Write-Line "No active transcript session was found to stop. Logging may not have been started properly." -Type Warning
        }
        catch {
            Write-ErrorReport -ErrorRecord $_
        }
    }
    
    end {
    }
}
# END OF FUNCTION
####################################################################################################

