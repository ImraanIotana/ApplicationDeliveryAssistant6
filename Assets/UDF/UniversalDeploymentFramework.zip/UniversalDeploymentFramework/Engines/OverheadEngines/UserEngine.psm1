#
# Module 'UserEngine.psm1'
# Last Update: March 2026
#

####################################################################################################
<#
.SYNOPSIS
    Retrieves the path of a user folder based on a specified name.
.DESCRIPTION
    This function retrieves the path of a specified user folder. It supports common user folders like Desktop, Documents, and Downloads.
.EXAMPLE
    Get-UserPath -Name DesktopFolder
    Retrieves the path of the Desktop folder.
.INPUTS
    [System.String]$Name
    A string representing the name of the user folder for which the path will be retrieved.
.OUTPUTS
    [System.String]
    The path of the specified user folder.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Get-UserPath {
    [CmdletBinding()]
    [OutputType([System.String])]
    param(
        [Parameter(Mandatory=$true,Position=0,HelpMessage='The name of the user folder, for which the path will be retrieved.')]
        [System.String]$Name
    )

    begin {
        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            KeyName = $Name
            Output  = $null
        }

        # Set the mapping hashtable for the supported user folders and their paths
        [System.Collections.Hashtable]$UserPathMappingHashtable = @{
            DesktopFolder           = [Environment]::GetFolderPath('Desktop')
            DocumentsFolder         = [Environment]::GetFolderPath('MyDocuments')
            DownloadsFolder         = Join-Path -Path $env:USERPROFILE -ChildPath 'Downloads'
            StartMenuFolder         = [Environment]::GetFolderPath('StartMenu')
            StartMenuProgramsFolder = Join-Path -Path ([Environment]::GetFolderPath('StartMenu')) -ChildPath 'Programs'
            # Other Paths
            EnvironmentVariablePATH = [System.Environment]::GetEnvironmentVariable('PATH', [System.EnvironmentVariableTarget]::User)
        }
    }

    process {
        try {
            # VALIDATION
            # Validate the Name parameter
            if (-not($UserPathMappingHashtable.ContainsKey($CTX.KeyName))) {
                Write-Line "The Name is not supported: ($($CTX.KeyName))" -Type Fail
                throw [System.Management.Automation.RuntimeException]
            }

            # EXECUTION
            # Retrieve the path
            [System.Object]$UserPath = $UserPathMappingHashtable[$CTX.KeyName]
            <# Validate that the path exists, if it is a string
            if ($UserPath -is [System.String]) {
                if (-not (Test-Path -Path $UserPath)) {
                    Write-Line "The file or folder could not be found at the expected location: ($UserPath)" -Type Fail
                    throw [System.Management.Automation.RuntimeException]
                }
            }#>
        }
        catch {
            # ERROR HANDLING
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
        finally {
            # Set the output in the context
            $CTX.Output = $UserPath
        }

    }

    end {
        # OUTPUT
        # Return the path of the specified user folder
        $CTX.Output
    }
}

# END OF FUNCTION
####################################################################################################


