#
# Module 'TimeEngine.psm1'
# Last Update: March 2026
#

####################################################################################################
<#
.SYNOPSIS
    Returns a timestamp in a format suitable for filenames.
.DESCRIPTION
    This function returns the current timestamp. If the -ForFileName switch is used, the timestamp is formatted in a way that is suitable for use in filenames.
.EXAMPLE
    Get-TimeStamp -ForFileName
.INPUTS
    [System.Management.Automation.SwitchParameter]$ForFileName
    A switch parameter that indicates whether the timestamp should be formatted for use in filenames.
    [System.Management.Automation.SwitchParameter]$ForHost
    A switch parameter that indicates whether the timestamp should be formatted for display in the host.
.OUTPUTS
    [System.String] The timestamp is returned as a string.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : February 2026
    Last Update     : March 2026
#>
####################################################################################################
function Get-TimeStamp {
    [CmdletBinding()]
    [OutputType([System.String])]
    param (
        [Parameter(Mandatory=$true,ParameterSetName='ForFileName',HelpMessage='Returns the timestamp in a format suitable for filenames.')]
        [System.Management.Automation.SwitchParameter]$ForFileName,

        [Parameter(Mandatory=$true,ParameterSetName='ForHost',HelpMessage='Returns the timestamp in a format suitable for display.')]
        [System.Management.Automation.SwitchParameter]$ForHost
    )


    # PROPERTIES
    # Get the UTC TimeStamp
    [System.DateTime]$UTCTimeStamp = (Get-Date).ToUniversalTime()

    # Set the context
    [System.Collections.Hashtable]$CTX = @{
        ParameterSetName        = $PSCmdlet.ParameterSetName
        TimeStampForFileName    = $UTCTimeStamp.ToString('yyyy_MM_dd_HHmm')
        TimeStampDateForHost    = $UTCTimeStamp.ToString('yyyy-MM-dd')
        TimeStampTimeForHost    = $UTCTimeStamp.ToString('HH:mm:ss.fff')
        TimeStampDefault        = $UTCTimeStamp.ToString()
        Output                  = [System.String]::Empty
    }

    # EXECUTION
    # Switch the timestamp format based on the ParameterSetName
    $CTX.Output = switch ($CTX.ParameterSetName) {
        'ForFileName'   { $CTX.TimeStampForFileName }
        'ForHost'       { "[$($CTX.TimeStampDateForHost) $($CTX.TimeStampTimeForHost)]" }
        Default         { $CTX.TimeStampDefault }
    }

    # Return the output
    $CTX.Output
}

# END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Starts the global timer for the Deployment Process.
.DESCRIPTION
    This function starts a global timer by storing the current timestamp in a global variable. It is used to measure the elapsed time of the Deployment Process.
    It also logs the start time of the Deployment Process to the host.
.EXAMPLE
    Start-GlobalTimer
.INPUTS
    None
.OUTPUTS
    No objects are returned to the pipeline. All operational output is written to the host and logged to the deployment logfile.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : February 2026
    Last Update     : March 2026
#>
####################################################################################################
function Start-GlobalTimer {
    [CmdletBinding()]
    [OutputType([System.Void])]

    # EXECUTION
    # Start the global timer by storing the current timestamp in a global variable
    $Global:UDF_GlobalStopwatch = [System.Diagnostics.Stopwatch]::StartNew()
    # Get the current timestamp
    [System.String]$StartTimeStamp = Get-TimeStamp -ForHost
    # Write the start time of the Deployment Process
    Write-Line "The Deployment Process started at $StartTimeStamp"
    # Add the Timestamp to the Global:DeploymentObject for use in other functions
    Add-ToGlobalDeploymentObject -Name DeploymentStartTime -Value $StartTimeStamp
}

# END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Stops the global timer and reports elapsed time.
.DESCRIPTION
    This function stops the global timer that was started by Start-GlobalTimer and reports the elapsed time of the Deployment Process.
    It also logs the completion time of the Deployment Process to the host.
.EXAMPLE
    Stop-GlobalTimer
.INPUTS
    None
.OUTPUTS
    No objects are returned to the pipeline. All operational output is written to the host and logged to the deployment logfile.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : February 2026
    Last Update     : April 2026
#>
####################################################################################################
function Stop-GlobalTimer {
    [CmdletBinding()]
    [OutputType([System.Void])]

    # PREPARATION
    # Get the current timestamp
    [System.String]$StopTimeStamp = Get-TimeStamp -ForHost
    # Write the stop time of the Deployment Process
    Write-Line "The Deployment Process stopped at $StopTimeStamp"
    # Add the Timestamp to the Global:DeploymentObject for use in other functions
    Add-ToGlobalDeploymentObject -Name DeploymentStopTime -Value $StopTimeStamp
    
    # EXECUTION
    # Stop the global timer and report elapsed time
    if ($Global:UDF_GlobalStopwatch) {

        # Stop the global timer
        $Global:UDF_GlobalStopwatch.Stop()
        # Get the elapsed time
        [System.TimeSpan]$ElapsedTime = $Global:UDF_GlobalStopwatch.Elapsed
        [System.String]$ElapsedTimeInBrackets = "[$ElapsedTime]"
        # Add the ElapsedTime to the Global:DeploymentObject for use in other functions
        Add-ToGlobalDeploymentObject -Name DeploymentElapsedTime -Value $ElapsedTimeInBrackets
        # Write the elapsed time of the Deployment Process
        Write-Line "The Deployment Process was completed in: $ElapsedTimeInBrackets"
        # Remove the global stopwatch variable
        Remove-Variable -Name UDF_GlobalStopwatch -Scope Global -ErrorAction SilentlyContinue

    } else {
        # Write a fail message if the global timer was not started
        Write-Line "The Global timer was not started. The elapsed time cannot be determined." -Type Fail
    }
}

# END OF FUNCTION
####################################################################################################

