#
# Module 'SystemEngines.psm1'
# Last Update: March 2026
#

####################################################################################################
<#
.SYNOPSIS
    Retrieves the path of a system executable, or folder, based on a specified name.
.DESCRIPTION
    This function retrieves the path of a specified system executable or folder. It supports common executables like PowerShell64, PowerShell32, RegEdit, Cmd, Msiexec, and Explorer.
.EXAMPLE
    Get-SystemPath -Name PowerShell
    Retrieves the path of the PowerShell executable.
.INPUTS
    [System.String]$Name
    A string representing the name of the system executable for which the path will be retrieved.
.OUTPUTS
    [System.String]
    The path of the specified system executable.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Get-SystemPath {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true,Position=0,HelpMessage='The name of the system executable or folder, for which the path will be retrieved.')]
        [System.String]$Name
    )

    begin {
        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            KeyName = $Name
            Output  = $null
        }

        # Set the hash table for the supported executables and their paths
        [System.Collections.Hashtable]$SystemPathMappingHashtable = @{
            # System Executables
            PowerShell64                    = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
            PowerShell32                    = "$env:SystemRoot\SysWOW64\WindowsPowerShell\v1.0\powershell.exe"
            RegEdit                         = "$env:SystemRoot\regedit.exe"
            REGExecutable                   = "$env:SystemRoot\System32\reg.exe"
            Cmd                             = "$env:SystemRoot\System32\cmd.exe"
            Msiexec                         = "$env:SystemRoot\System32\msiexec.exe"
            Icacls                          = "$env:SystemRoot\System32\icacls.exe"
            Explorer                        = "$env:SystemRoot\explorer.exe"
            # System Folders
            DesktopFolder                   = [Environment]::GetFolderPath('CommonDesktopDirectory')
            StartMenuFolder                 = [Environment]::GetFolderPath('CommonStartMenu')
            StartMenuProgramsFolder         = Join-Path -Path ([Environment]::GetFolderPath('CommonStartMenu')) -ChildPath 'Programs'
            # Registry Paths
            AddRemoveProgramsRegistryPath64 = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall'
            AddRemoveProgramsRegistryPath32 = 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall'
            # Other Paths
            UDFTemporaryParentFolder        = Join-Path -Path $ENV:ProgramData -ChildPath "UDF_Temporary_Files"
            EnvironmentVariablePATH         = [System.Environment]::GetEnvironmentVariable('PATH', [System.EnvironmentVariableTarget]::Machine)
        }
        # Add the AddRemoveProgramsRegistryPaths
        $SystemPathMappingHashtable.AddRemoveProgramsRegistryPaths = @($SystemPathMappingHashtable.AddRemoveProgramsRegistryPath64, $SystemPathMappingHashtable.AddRemoveProgramsRegistryPath32)
    }

    process {
        try {
            # VALIDATION
            # Validate the Name parameter
            if (-not($SystemPathMappingHashtable.ContainsKey($CTX.KeyName))) {
                Write-Line "The Name is not supported: ($($CTX.KeyName))" -Type Fail
                throw [System.Management.Automation.RuntimeException]
            }

            # EXECUTION
            # Retrieve the path
            [System.Object]$SystemPath = $SystemPathMappingHashtable[$CTX.KeyName]
            <# Validate that the path exists, if it is a string
            if ($SystemPath -is [System.String]) {
                if (-not (Test-Path -Path $SystemPath)) {
                    Write-Line "The file or folder could not be found at the expected location: ($SystemPath)" -Type Fail
                    throw [System.Management.Automation.RuntimeException]
                }
            }#>
        }
        catch {
            # ERROR HANDLING
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
        finally {
            # Set the output in the context
            $CTX.Output = $SystemPath
        }
    }

    end {
        # OUTPUT
        # Return the path of the specified system executable
        $CTX.Output
    }
}

# END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Returns the size of a folder in Megabytes.
.DESCRIPTION
    This function returns the size of the specified folder in Megabytes. It recursively calculates the size of all files within the folder and its subfolders.
.EXAMPLE
    Get-FolderSize -Path "C:\MyFolder"
.INPUTS
    [System.String]$Path
    A string representing the path to the folder for which the size will be calculated.
.OUTPUTS
    [System.Double] The size of the folder in Megabytes.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : February 2026
    Last Update     : February 2026
#>
####################################################################################################
function Get-FolderSize {
    [CmdletBinding()]
    [OutputType([System.Double])]
    param (
        [Parameter(Mandatory=$false,HelpMessage='The path to the folder for which the size will be calculated.')]
        [System.String]$Path,

        [Parameter(Mandatory=$false,HelpMessage='The identifier for the folder that will be used in the output message.')]
        [System.String]$FolderIdentifier,

        [Parameter(Mandatory=$false,HelpMessage='Switch for returning the output.')]
        [System.Management.Automation.SwitchParameter]$PassThru,

        [Parameter(Mandatory=$false,HelpMessage='Switch for writing the output to the host.')]
        [System.Management.Automation.SwitchParameter]$OutHost
    )

    begin {
        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            PathToGetSizeFrom   = $Path
            FolderIdentifier    = if ($FolderIdentifier) { $FolderIdentifier } else { 'folder' }
            Output              = [System.Double]0.0
        }
    }

    process {
        try {
            # VALIDATION
            # Validate the input
            Approve-MandatoryPath -Path $CTX.PathToGetSizeFrom -PathDescription 'Path' -ErrorAction Stop

            # EXECUTION
            # Get the size of the folder in Megabytes
            [System.IO.DirectoryInfo]$Directory = [System.IO.DirectoryInfo]::new($CTX.PathToGetSizeFrom)
            [System.Int64]$TotalBytes = ($Directory.EnumerateFiles('*', 'AllDirectories') | Measure-Object -Property Length -Sum).Sum
            [System.Double]$SizeInMB = [System.Math]::Round($TotalBytes / 1MB, 2)
            
            # RESULT
            # Write the size of the folder to the host
            if ($OutHost) { Write-Line "The size of the $($CTX.FolderIdentifier) is $SizeInMB MB. ($($CTX.PathToGetSizeFrom))" }
            # Set the output
            $CTX.Output = $SizeInMB
        }
        catch [System.Management.Automation.RuntimeException] {
            $PSCmdlet.ThrowTerminatingError($_)
        }
        catch {
            Write-ErrorReport -ErrorRecord $_
        }
    }
    
    end {
        # OUTPUT
        # Return the output
        if ($PassThru) { $CTX.Output }
    }
}

# END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Retrieves the list of installed applications from the Add/Remove Programs registry paths.
.DESCRIPTION
    This function retrieves the list of installed applications from the Add/Remove Programs registry paths.
    It supports returning either the full registry key objects or just the key names of the installed applications.
.EXAMPLE
    Get-InstalledApplications -ReturnKeyNames
    Retrieves the key names of the installed applications.
.INPUTS
    [System.Management.Automation.SwitchParameter]$ReturnKeyNames
    A switch parameter that determines whether to return only the key names of the installed applications. If specified, only the key names will be returned; otherwise, the full registry key objects will be returned.
.OUTPUTS
    [System.Object[]]
    An array of either registry key objects or key names representing the installed applications, depending on the value of the ReturnKeyNames switch.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Get-InstalledApplications {
    [CmdletBinding()]
    [OutputType([System.Object[]])]
    param (
        [Parameter(Mandatory=$false,HelpMessage='Switch for returning only the key names of the installed applications.')]
        [System.Management.Automation.SwitchParameter]$ReturnKeyNames,

        [Parameter(Mandatory=$false,HelpMessage='Switch for writing the output to the host.')]
        [System.Management.Automation.SwitchParameter]$OutHost
    )
    
    begin {
        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            ARPPaths                    = Get-SystemPath -Name AddRemoveProgramsRegistryPaths
            InstalledApplicationObjects = [System.Collections.ArrayList]@()
            Output                      = $null
        }
    }
    
    process {
        try {
            # EXECUTION
            # Get the installed applications from the Add/Remove Programs registry paths
            foreach ($ARPPath in $CTX.ARPPaths) {
                # Get the ApplicationObjects of the registry path
                if ($OutHost) { Write-Line "Retrieving the installed applications from the registry path: ($ARPPath)" }
                [Microsoft.Win32.RegistryKey[]]$ApplicationObjects = Get-ChildItem -Path $ARPPath -ErrorAction SilentlyContinue
                # Add the display names of the installed applications to the list
                $CTX.InstalledApplicationObjects.AddRange($ApplicationObjects) | Out-Null
            }

            # RESOLVING THE OUTPUT
            # Set the output based on the ReturnKeyNames switch
            [System.Object[]]$ArrayToReturn = if ($ReturnKeyNames) {
                # Return only the key names of the installed applications
                if ($OutHost) { Write-Line "Resolving the key names of the installed applications." }
                [System.String[]]$KeyNames = $CTX.InstalledApplicationObjects | ForEach-Object { $_.PSChildName }
                $KeyNames
            } else {
                # Return the registry key objects of the installed applications
                if ($OutHost) { Write-Line "Returning the registry key objects of the installed applications." }
                $CTX.InstalledApplicationObjects.ToArray()
            }
            # Set the output
            $CTX.Output = $ArrayToReturn
            # Write the message
            if ($OutHost) { Write-Line "Retrieved installed applications: ($($CTX.Output.Count))" }
        }
        catch {
            Write-ErrorReport -ErrorRecord $_
        }
    }
    
    end {
        # OUTPUT
        # Return the output
        $CTX.Output

    }
}

# END OF FUNCTION
####################################################################################################
