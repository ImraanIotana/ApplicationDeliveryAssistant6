#
# Module 'ItemsEngine.psm1'
# Last Update: March 2026
#

####################################################################################################
<#
.SYNOPSIS
    Copies a file or folder to a specified destination folder, with the option to force overwrite.
.DESCRIPTION
    This function copies a file or folder to a specified destination folder. It supports both files and folders, and can force overwrite existing items.
    It also provides options to return the output and write the output to the host.
.EXAMPLE
    Copy-ItemUDF -ThisFile "C:\Source\File.txt" -IntoThisFolder "C:\Destination" -OutHost
    Copies the specified file to the destination folder and writes the output to the host.
.INPUTS
    [System.String]
    [System.Management.Automation.SwitchParameter]
.OUTPUTS
    [System.Boolean]
    A boolean value indicating whether the copy operation was successful, returned when using -PassThru
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Copy-ItemUDF {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$true,ParameterSetName='CopyFile',HelpMessage='The source file path.')]
        [System.String]$ThisFile,

        [Parameter(Mandatory=$false,ParameterSetName='CopyFile',HelpMessage='The new name for the copied file.')]
        [System.String]$AndRenameTo,

        [Parameter(Mandatory=$true,ParameterSetName='CopyFolder',HelpMessage='The source folder path.')]
        [System.String]$ThisFolder,

        [Parameter(Mandatory=$true,ParameterSetName='CopyFolderContent',HelpMessage='The folder whose content will be copied.')]
        [System.String]$ContentOfThisFolder,

        [Parameter(Mandatory=$false,HelpMessage='The destination folder path.')]
        [System.String]$IntoThisFolder,

        [Parameter(Mandatory=$false,HelpMessage='Switch for returning the output.')]
        [System.Management.Automation.SwitchParameter]$PassThru,

        [Parameter(Mandatory=$false,HelpMessage='Switch for writing the output to the host.')]
        [System.Management.Automation.SwitchParameter]$OutHost
    )
    
    begin {
        # PREPARATION - INPUT
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            FolderToCopyInto    = $IntoThisFolder
            ParameterSetName    = $PSCmdlet.ParameterSetName
            Output              = $null
        }

        # PREPARATION - ADDITIONAL PROPERTIES
        # Add the properties to the context based on the ParameterSetName
        [System.String]$CTX.SourceItemFullPath,[System.String]$CTX.PathType,[System.String]$CTX.ItemDescription = switch ($CTX.ParameterSetName) {
            'CopyFile'          { $ThisFile             , 'Leaf'        , 'file' }
            'CopyFolder'        { $ThisFolder           , 'Container'   , 'folder' }
            'CopyFolderContent' { $ContentOfThisFolder  , 'Container'   , 'content of the folder' }
        }
        # Add the LeafName
        [System.String]$CTX.LeafName = Split-Path -Path $CTX.SourceItemFullPath -Leaf
    }
    
    process {
        try {
            # VALIDATION
            # Validate the source item
            Approve-MandatoryPath -Path $CTX.SourceItemFullPath -PathDescription $CTX.ItemDescription -ErrorAction Stop

            # EXECUTION - CREATE DESTINATION FOLDER
            # If the FolderToCopyInto is empty, set it to the parent folder of the source item
            if (Test-String -IsEmpty $CTX.FolderToCopyInto) { $CTX.FolderToCopyInto = Split-Path -Path $CTX.SourceItemFullPath -Parent }
            # Create the destination folder
            New-FolderUDF -Path $CTX.FolderToCopyInto -ResetACL

            # PREPARATION - COPY PROPERTIES
            # Write the message
            if ($OutHost) { Write-Line "Copying the $($CTX.ItemDescription) ($($CTX.LeafName)) into the folder ($($CTX.FolderToCopyInto))..." }
            # Switch on the ParameterSetName to determine the item to copy
            [System.String]$ItemToCopy = switch ($CTX.ParameterSetName) {
                'CopyFolderContent' { "$($CTX.SourceItemFullPath)\*" }
                default             { $CTX.SourceItemFullPath }
            }
            # Set the Copy-Item parameters
            [System.Collections.Hashtable]$CopyItemParameters = @{
                Path        = $ItemToCopy
                Destination = $CTX.FolderToCopyInto
                Recurse     = $true
                Force       = $true
                ErrorAction = 'Stop'
            }
            # If AndRenameTo is specified, update the Destination parameter to include the new name for the copied item
            if ($AndRenameTo) { $CopyItemParameters.Destination = Join-Path -Path $CTX.FolderToCopyInto -ChildPath $AndRenameTo }

            # EXECUTION - COPY ITEM
            # Copy the item to the destination folder
            Copy-Item @CopyItemParameters

            # RESULT
            # Write the message
            if ($OutHost) { Write-Line "Successfully copied the $($CTX.ItemDescription) ($($CTX.LeafName)) into the folder ($($CTX.FolderToCopyInto))." }
            # Set the output to $true
            $CTX.Output = $true
        }
        catch [System.UnauthorizedAccessException] {
            Write-Line "Failed to copy the $($CTX.ItemDescription) ($($CTX.LeafName)) into the folder ($($CTX.FolderToCopyInto)). Access is denied." -Type Fail
            $PSCmdlet.ThrowTerminatingError($_)
        }
        catch {
            # ERROR HANDLING
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
    }
    
    end {
        # OUTPUT
        # Return the result of the copy operation if PassThru is specified
        if ($PassThru) { $CTX.Output }        
    }
}

# END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Removes a file or folder at a specified path, without confirmation.
.DESCRIPTION
    This function removes a file or folder at a specified path.
    It also provides options to return the output and write the output to the host.
.EXAMPLE
    Remove-ItemUDF -Path "C:\Source\File.txt" -OutHost
    Removes the specified file or folder and writes the output to the host.
.INPUTS
    [System.String]
    [System.Management.Automation.SwitchParameter]
.OUTPUTS
    [System.Boolean]
    A boolean value indicating whether the remove operation was successful, returned when using -PassThru
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function Remove-ItemUDF {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true,Position=0,HelpMessage='The path of the item to be removed.')]
        [System.String]$Path,

        [Parameter(Mandatory=$false,HelpMessage='Switch for returning the output.')]
        [System.Management.Automation.SwitchParameter]$PassThru,

        [Parameter(Mandatory=$false,HelpMessage='Switch for writing the output to the host.')]
        [System.Management.Automation.SwitchParameter]$OutHost
    )
    
    begin {
        # VALIDATION - INPUT
        # Validate the input
        Approve-MandatoryString -String $Path -StringDescription 'Path' -ErrorAction Stop

        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            # Input
            PathToRemove        = ConvertTo-TrimmedPath  -Path $Path
            # Handlers
            ForbiddenFolders    = @(
                "$ENV:WinDir",
                "$ENV:ProgramFiles",
                "${ENV:ProgramFiles(x86)}",
                "${ENV:WinDir\System32}",
                "${ENV:WinDir\SysWOW64}"
            )
            CallingFunction     = (Get-PSCallStack)[1].Command
            # Output
            Output              = $false
        }
    }
    
    process {
        try {
            # VALIDATION - ITEM EXISTENCE
            # If the item does not exist, consider the removal successful and return
            if (-not (Test-Path -Path $CTX.PathToRemove)) {
                Write-Line "The item was not found. The removal is considered successful. ($($CTX.PathToRemove))" ; $CTX.Output = $true ; return
            }

            # VALIDATION - FORBIDDEN FOLDERS
            # Check if the path is in the forbidden folders list
            if ($CTX.ForbiddenFolders -contains $CTX.PathToRemove) {
                throw "It is forbidden to remove items from this location. ($($CTX.PathToRemove))"
            }

            # EXECUTION
            # Write the message
            Write-Line "Removing the item ($($CTX.PathToRemove)) for the function [$($CTX.CallingFunction)]..." 
            # Remove the item
            Remove-Item -Path $CTX.PathToRemove -Recurse -Force -ErrorAction Stop
            # Write the message
            Write-Line "Successfully removed the item ($($CTX.PathToRemove)) for the function [$($CTX.CallingFunction)]."
            # Set the output to $true
            $CTX.Output = $true
        }
        catch [System.ArgumentException] {
            Write-Line "Failed to remove the item ($($CTX.PathToRemove)) for the function [$($CTX.CallingFunction)]. Access is denied." -Type Fail
            $PSCmdlet.ThrowTerminatingError($_)
        }
        catch [System.Security.SecurityException] {
            Write-Line "Failed to remove the item ($($CTX.PathToRemove)) for the function [$($CTX.CallingFunction)]. Access is denied." -Type Fail
            $PSCmdlet.ThrowTerminatingError($_)
        }
        catch {
            Write-Line "Failed to remove the item ($($CTX.PathToRemove)) for the function [$($CTX.CallingFunction)] for unknown reasons." -Type Fail
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
    }
    
    end {
        # OUTPUT
        # Return the result of the remove operation if PassThru is specified
        if ($PassThru) { $CTX.Output }        
    }
}

# END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Creates a new folder at a specified path.
.DESCRIPTION
    This function creates a new folder at a specified path. It also provides options to return the output and write the output to the host.
.EXAMPLE
    New-FolderUDF -Path "C:\NewFolder" -OutHost
    Creates the specified folder and writes the output to the host.
.INPUTS
    [System.String]
    [System.Management.Automation.SwitchParameter]
.OUTPUTS
    [System.Boolean]
    A boolean value indicating whether the create operation was successful, returned when using -PassThru
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function New-FolderUDF {
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param (
        [Parameter(Mandatory=$true,Position=0,HelpMessage='The path where the new folder will be created.')]
        [System.String]$Path,

        [Parameter(Mandatory=$false,HelpMessage='Switch for resetting the ACL of the folder.')]
        [System.Management.Automation.SwitchParameter]$ResetACL,

        [Parameter(Mandatory=$false,HelpMessage='Switch for returning the output.')]
        [System.Management.Automation.SwitchParameter]$PassThru
    )
    
    begin {
        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            FolderToCreate  = $Path
            FailMessage1    = "Failed to create the folder. Access is denied. ($Path)."
            FailMessage2    = "Failed to create the folder for unknown reasons. ($Path)."
            Output          = $false
        }
    }
    
    process {
        try {
            # VALIDATION
            # Validate the input
            Approve-MandatoryString -String $CTX.FolderToCreate -StringDescription 'Path' -ErrorAction Stop
            # Validate that the folder does not already exist
            if (Test-Path -Path $CTX.FolderToCreate) {
                Write-Line "The folder already exists. The creation is considered successful. ($($CTX.FolderToCreate))" ; $CTX.Output = $true ; return
            }

            # PREPARATION - SEGMENTATION
            # Normalize path to ensure consistent path formatting and to handle relative paths
            [System.String]$NormalizedPath = [System.IO.Path]::GetFullPath($CTX.FolderToCreate)
            # Segment the folder path into its components
            [System.String[]]$FolderPathSegments = $NormalizedPath.Split([System.IO.Path]::DirectorySeparatorChar) | Where-Object { $_ -ne "" }
            # Set the Increasing Path to the first segment of the folder path (e.g., "C:\")
            [System.String]$IncreasingPath = $FolderPathSegments[0]
            # Iterate through the segments of the folder path (except the first), creating each segment if it does not exist
            foreach ($Segment in $FolderPathSegments[1..($FolderPathSegments.Count - 1)]) {
                # Update the Increasing Path
                $IncreasingPath = Join-Path -Path $IncreasingPath -ChildPath $Segment
                # Check if the current segment of the path exists
                if (Test-Path -Path $IncreasingPath -PathType Container) {
                    # If it exists, write the message
                    Write-Verbose "The folder already exists: ($IncreasingPath)."
                } else {
                    # If it does not exist, create it
                    Write-Line "Creating the folder: ($IncreasingPath)."
                    [System.Void](New-Item -Path $IncreasingPath -ItemType Directory -Force -ErrorAction Stop)
                    Write-Line "Successfully created the folder: ($IncreasingPath)."
                    # Reset the ACL of the newly created folder
                    if ($ResetACL) { Reset-ACL -Path $IncreasingPath -UseIcacls -OutHost }
                }
            }

            # Set the output to $true
            $CTX.Output = $true
        }
        catch [System.Management.Automation.RuntimeException] {
            Write-Line $CTX.FailMessage1 -Type Fail
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
        catch [System.UnauthorizedAccessException] {
            Write-Line $CTX.FailMessage1 -Type Fail
            $PSCmdlet.ThrowTerminatingError($_)
        }
        catch {
            Write-Line $CTX.FailMessage2 -Type Fail
            Write-ErrorReport -ErrorRecord $_
        }
    }
    
    end {
        # OUTPUT
        # Return the result of the create operation if PassThru is specified
        if ($PassThru) { $CTX.Output }        
    }
}

# END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Converts a path to a trimmed path by removing leading and trailing whitespace and directory separator characters.
.DESCRIPTION
    This function converts a path to a trimmed path by removing leading and trailing whitespace and directory separator characters.
    It also provides options to write the output to the host.
.EXAMPLE
    ConvertTo-TrimmedPath -Path "  C:\Folder\Subfolder\\\ " -OutHost
    Returns "C:\Folder\Subfolder" by trimming the leading and trailing whitespace and directory separator characters from the input path.
.INPUTS
    [System.String]$Path
    [System.Management.Automation.SwitchParameter]$OutHost
.OUTPUTS
    [System.String]$CTX.Output
    A trimmed version of the input path with leading and trailing whitespace and directory separator characters removed.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function ConvertTo-TrimmedPath {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true,Position=0,HelpMessage='The path to be trimmed.')]
        [System.String]$Path,

        [Parameter(Mandatory=$false,HelpMessage='Switch for writing the output to the host.')]
        [System.Management.Automation.SwitchParameter]$OutHost
    )
    
    begin {
        # VALIDATION
        # Validate the input
        Approve-MandatoryString -String $Path -StringDescription 'Path'

        # PREPARATION
        # Set the context
        [System.Collections.Hashtable]$CTX = @{
            # Input
            OriginalPath   = $Path
            # Output
            Output         = [System.String]::Empty
        }
        # Write the message
        if ($OutHost) { Write-Line "Converting the path to a trimmed path: ($($CTX.OriginalPath))." }
    }
    
    process {
        try {
            # EXECUTION
            # Trim the leading and trailing whitespace
            $CTX.WhitespaceTrimmedPath = $CTX.OriginalPath.Trim()

            # Detect drive root early (C:\, D:\)
            if ($CTX.WhitespaceTrimmedPath -match '^[A-Za-z]:\\?$') {
                # If the path is a drive root, ensure it ends with a single backslash and return it as the output
                $CTX.Output = $CTX.WhitespaceTrimmedPath.TrimEnd('\') + '\'
                return
            }

            # Trim the path by removing any trailing directory separator characters
            $CTX.TrimmedPath = $CTX.WhitespaceTrimmedPath.TrimEnd(
                # Trim the directory separator: \
                [System.IO.Path]::DirectorySeparatorChar,
                # Trim the alternative directory separator: /
                [System.IO.Path]::AltDirectorySeparatorChar,
                # Trim the path separator: ;
                [System.IO.Path]::PathSeparator
            )

            # Prevent returning an empty path after trimming
            if (Test-String -IsEmpty $CTX.TrimmedPath) {
                throw "The path is empty after trimming: ($($CTX.OriginalPath))"
            }

            # RESULT
            # Write the message
            if ($OutHost) { Write-Line "Successfully converted the path to a trimmed path: ($($CTX.TrimmedPath))" }
            # Set the output to the trimmed path
            $CTX.Output = $CTX.TrimmedPath
        }
        catch {
            # ERROR HANDLING
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
    }
    
    end {
        # OUTPUT
        # Return the trimmed path
        $CTX.Output
    }
}

# END OF FUNCTION
####################################################################################################


####################################################################################################
<#
.SYNOPSIS
    Creates a new temporary folder with a unique name in the UDFTemporaryParentFolder directory.
.DESCRIPTION
    This function creates a new temporary folder with a unique name in the UDFTemporaryParentFolder directory.
    The folder name is generated using a new GUID to ensure uniqueness.
.EXAMPLE
    $MyNewFolder = New-TemporaryFolderUDF
.INPUTS
    None
.OUTPUTS
    [System.String]
    The full path of the newly created temporary folder.
.NOTES
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
    Version         : 6.0.0.0
    Author          : Imraan Iotana
    Creation Date   : March 2026
    Last Update     : March 2026
#>
####################################################################################################
function New-TemporaryFolderUDF {
    [CmdletBinding()]
    param (
    )
    
    process {
        try {
            # PREPARATION
            # Set a properties for the temporary folder
            [System.String]$UDFParentFolder         = Get-SystemPath -Name UDFTemporaryParentFolder
            [System.String]$NewGuid                 = [System.Guid]::NewGuid().ToString()
            [System.String]$NewTemporaryFolderPath  = Join-Path -Path $UDFParentFolder -ChildPath $NewGuid
            [System.String]$CallingFunction         = (Get-PSCallStack)[1].Command

            # EXECUTION
            # Write the message
            Write-Line "Creating a new temporary folder for the function [$CallingFunction]... ($NewTemporaryFolderPath)"
            # Create the temporary folder
            New-FolderUDF -Path $NewTemporaryFolderPath

            # OUTPUT
            # Return the temporary folder path
            $NewTemporaryFolderPath
        }
        catch {
            # ERROR HANDLING
            Write-ErrorReport -ErrorRecord $_
            $PSCmdlet.ThrowTerminatingError($_)
        }
    }
}

# END OF FUNCTION
####################################################################################################
