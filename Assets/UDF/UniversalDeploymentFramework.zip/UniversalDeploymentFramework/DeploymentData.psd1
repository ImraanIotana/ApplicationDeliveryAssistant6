####################################################################################################
<#
.SYNOPSIS
    UNIVERSAL DEPLOYMENT FRAMEWORK: This contains the data needed.
.DESCRIPTION
    This file contains the Deployment Objects Array, which is a collection of hashtables that define the deployment objects to be installed or uninstalled.
    Each hashtable represents a deployment object and contains the necessary information for its deployment.
.NOTES
    Version         : Defined in the DeploymentScriptVersion variable
    Author          : Imraan Iotana
    Creation Date   : February 2026
    Last Update     : February 2026
.COPYRIGHT
    This script is part of the Universal Deployment Framework. Copyright (C) Iotana. All rights reserved.
#>
####################################################################################################

# Add the Deployment Objects here. Please see the explanation in the lower section of this script.
@{
    # Set the Application ID
    #ApplicationID       = '<<APPLICATIONID>>' # (Mandatory String) Set the APPLICATION ID. (This is used for logging and reporting, and must be unique for each application. Example: 'Contoso_WebViewer_3.14')
    ApplicationID       = 'Contoso_WebViewer_3.14'
    # Set the Build Number
    #BuildNumber         = '01'      # (Mandatory String) Set the BUILD NUMBER. (This is used for logging and reporting, and can be used to differentiate between different builds of the same application. Example: '02')
    BuildNumber         = '11'
    # Set the Source Files Folder
    #SourceFilesFolder   = 'Default' # (Mandatory String) If the sourcefiles are on a hardcoded location, then change this value. Else leave it as 'Default' and place your sourcefiles in the subfolder named 'SourceFiles'
    SourceFilesFolder   = 'C:\Users\iotan500\Downloads\Bronmap'

    # Set the Deployment Objects
    DeploymentObjects   = @(
        @{
            Type                        = 'DEPLOYPAUSE'
            SecondsToPause              = '0'        # (Mandatory String) Set the length of the pause in SECONDS. Example: '10'.
            PerformDuringInstall        = $true     # (Mandatory Boolean) If the PAUSE be executed during INSTALL, then set this value to $true.
            PerformDuringUninstall      = $false    # (Mandatory Boolean) If the PAUSE be executed during UNINSTALL, then set this value to $true.
        }
        <#@{
            Type                        = 'DEPLOYREGFILE'
            REGFileName                 = 'HKCU.reg'    # (Mandatory String) Set the FILENAME of the REGFILE, INCLUDING the extension (.reg). Example: 'AppSettings.reg'
            AlsoRemoveParentKeys        = $true         # (Mandatory Boolean) If during UNINSTALL also the PARENTKEYS should be removed (not only the properties), then set this value to $true.
        }#>
    )
}


####################################################################################################
<#region ###### EXPLANATION AND EXAMPLE ######

Instructions:
Add DeploymentObjects to the DeploymentObjectsArray. The objects will be deployed from top to bottom.

THIS IS AN EXAMPLE:
The following example firstly installs an MSI, then waits 10 seconds, then configures the application, and the removes the desktopshortcut:
    $DeploymentObjects = @(
        @{ # Install the main application
            Type                        = 'DEPLOYMSI'
            MSIFileName                 = 'TeamViewer_Host'
            MSTFileName                 = 'TeamViewer_WithMyChanges'
            MSPFileNames                = @('Patch_1.2','Patch_1.3')
            AdditionalArguments         = @('ADDLOCAL=ALL','ALLUSERS=1')
            InstallSuccessExitCodes     = @(0)
            UninstallSuccessExitCodes   = @(0)
        }
        @{ # Wait for the installation to finish
            Type                        = 'DEPLOYPAUSE'
            SecondsToPause              = '10'
            PerformDuringInstall        = $true
            PerformDuringUninstall      = $false
        }
        @{ # Configure the application
            Type                        = 'RUNEXE'
            ExeFullPath                 = 'C:\Program Files (x86)\TeamViewer\TeamViewer.exe'
            ArgumentList                = @('assignment','--id 0001CoABChBKuKbwRXwR7YjOAt758SqwBJYzjOwkVDKLFM9K3n4ze','--retries=3','--timeout=120')
            WaitUntilFinished           = $true
            RunDuringInstall            = $true
            RunDuringUninstall          = $false
        }
        @{ # Remove the desktop shortcut
            Type                        = 'REMOVESHORTCUT'
            ShortcutFileName            = 'TeamViewer.lnk'
            PerformDuringInstall        = $true
            PerformDuringUninstall      = $false
            AlsoRemoveFromStartMenu     = $false
        }
    )

#endregion ###### EXPLANATION AND EXAMPLE ######
#>

####################################################################################################
<#region ### DEPLOYMENT OBJECT TEMPLATES ###

Index:
- 10 - GENERAL INSTALLATIONS
- DEPLOYMSI

- 20 - FILES AND FOLDERS
- DEPLOYBASICFOLDERCOPY
- DEPLOYCOMPRESSEDFOLDER
- DEPLOYBASICFILECOPY

- 50 - SHORTCUTS
- DEPLOYSHORTCUT

- 80 - REGISTRY
- DEPLOYREGFILE
- IMPORTREGFILE

- 90 - OTHER
- DEPLOYPAUSE
- DEPLOYARPENTRY
- ADDENVIRONMENTPATH

####################################################################################################


10 - GENERAL INSTALLATIONS #########################################################################
10 - GENERAL INSTALLATIONS #########################################################################
#
#
###### TEMPLATE DEPLOYMSI OBJECT ###### 6.0.0
# Note: This Object installs an MSI package during Install, and uninstalls it during Uninstall.
    # Copy from here:
        @{
            Type                        = 'DEPLOYMSI'
            MSIFileName                 = ''            # (Mandatory String) Set the MSI FILENAME. Example: 'Contoso-Webviewer-3.14.msi'.
            MSTFileName                 = ''            # (Optional String) Set the MST FILENAME. Example: 'Webviewer_WithMyAdjustments.mst'. (If there is no MST file then leave this empty.)
            MSPFileNames                = @()           # (Optional String Array) Set the MSP FILENAMES. Example: @('WebviewerPatch01.msp','WebviewerPatch02.msp'). (If there are no MSP's then leave this empty.)
            AdditionalArguments         = @()           # (Optional String Array) Add any ADDITIONAL INSTALL arguments. Example: @('ADDLOCAL=ALL','ALLUSERS=1','REBOOT=Suppress'). (If there are no additional arguments then leave this empty.)
            InstallSuccessExitCodes     = @(0,3010)     # (Mandatory Integer Array) Set the INSTALL SUCCESS EXIT CODES for the MSI. (The default value is @(0,3010).)
            UninstallSuccessExitCodes   = @(0,3010)     # (Mandatory Integer Array) Set the UNINSTALL SUCCESS EXIT CODES for the MSI. (The default value is @(0,3010).)
        }
###### TEMPLATE DEPLOYMSI OBJECT ###### 6.0.0
#
#
10 - GENERAL INSTALLATIONS #########################################################################
10 - GENERAL INSTALLATIONS #########################################################################




20 - FILES AND FOLDERS #############################################################################
20 - FILES AND FOLDERS #############################################################################
#
#
###### TEMPLATE DEPLOYBASICFOLDERCOPY OBJECT ###### 6.0.0
# Note: This Object copies a folder from the source files to a destination folder on the local system. During Install, the folder will be copied. During Uninstall, the copied folder will be removed.
    # Copy from here:
        @{
            Type                        = 'DEPLOYBASICFOLDERCOPY'
            FolderToCopy                = ''                    # (Mandatory String) Set NAME OF THE FOLDER to copy. Example: 'MyApplication'
            DestinationFolder           = 'C:\Program Files'    # (Mandatory String) Set the DESTINATION FOLDER to which your folder will be copied. Example: 'C:\Program Files'
            KeepCurrentFolderName       = $true                 # (Mandatory Boolean) If you want to keep the current foldername, then set this value to $true. Otherwise it will be renamed to the ApplicationID.
        }
###### TEMPLATE DEPLOYBASICFOLDERCOPY OBJECT ###### 6.0.0
#
###### TEMPLATE DEPLOYCOMPRESSEDFOLDER OBJECT######## 6.0.0
# Note: This Object extracts a compressed folder (zipfile), to a destination folder on the local system.
# IMPORTANT: The DestinationFolder is the folder that will be REMOVED during Uninstall. Therefore, make sure that this folder is used EXCLUSIVELY for the application that is being deployed.
# Copy from here:
        @{
            Type                        = 'DEPLOYCOMPRESSEDFOLDER'
            ZipFileName                 = ''                            # (Mandatory String) Set the NAME of the zip-file, including the extension. Example: 'MyZipFile.zip'.
            DestinationFolder           = 'C:\Program Files\Webviewer'  # (Mandatory String) Set the DESTINATION FOLDER to which the zipfile will be extracted. Example: 'C:\Program Files\Contoso\WebViewer'
            SkipTopFolderInsideZipFile  = $true                         # (Mandatory Boolean) If the topmost folder inside the zip file should be ignored, then set this value to $true.
        }
###### TEMPLATE DEPLOYCOMPRESSEDFOLDER OBJECT######## 6.0.0
#
###### TEMPLATE DEPLOYBASICFILECOPY OBJECT ###### 6.0.0
# Note: This Object copies a file from the source files to a destination folder on the local system. During Install, the file will be copied. During Uninstall, the copied file will be removed.
    # Copy from here:
        @{
            Type                        = 'DEPLOYBASICFILECOPY'
            FileToCopy                  = ''                    # (Mandatory String) Set NAME of the FILE to copy. Example: 'WebViewerConfiguration.xml'
            DestinationFolder           = ''                    # (Mandatory String) Set the DESTINATION FOLDER to which the file will be copied. Example: 'C:\ProgramData\WebViewer'
            OverwriteExistingFile       = $false                # (Mandatory Boolean) If an existing file needs to be overwritten, then set this value to $true.
        }
###### TEMPLATE DEPLOYBASICFILECOPY OBJECT ###### 6.0.0
#
#
20 - FILES AND FOLDERS #############################################################################
20 - FILES AND FOLDERS #############################################################################




50 - SHORTCUTS #####################################################################################
50 - SHORTCUTS #####################################################################################
#
#
###### TEMPLATE DEPLOYSHORTCUT OBJECT ###### 6.0.0
# Note: This Object creates a shortcut during Install, and removes it during Uninstall.
    # Copy from here:
        @{
            Type                        = 'DEPLOYSHORTCUT'
            DisplayName                 = ''        # (Mandatory String) Set the DISPLAYNAME of the Shortcut. Example: 'Help for Users'
            TargetPath                  = ''        # (Mandatory String) Set the FULL PATH of the Target file or folder. Example: 'C:\Program Files\MyDemoApp\help.exe'
            WorkingDirectory            = ''        # (Optional String) Set the WORKING DIRECTORY of the Shortcut. Example: 'C:\Program Files\MyDemoApp'
            Arguments                   = ''        # (Optional String) Set the ARGUMENTS for the Target File. Example: '-readonly'
            IconFileName                = ''        # (Optional String) Set the FILENAME of the ICON FILE, INCLUDING the extension (.ico), and add it to the sourcefiles. Example: 'MyIcon.ico'
            StartMenuSubFolder          = ''        # (Optional String) Set the Startmenu SUBFOLDER. Example: 'MyDemoApp'
            AlsoPlaceOnDesktop          = $false    # (Mandatory Boolean) If the shortcut should also be placed on the Desktop, then set this value to $true. Otherwise it will be placed in the Startmenu only.
        }
###### TEMPLATE DEPLOYSHORTCUT OBJECT ###### 6.0.0
#
###### TEMPLATE REMOVESHORTCUT OBJECT ###### 6.0.0
# Note: This Object removes a shortcut during Install or Uninstall. This can be used for example, to remove a Desktop shortcut during Install.
    # Copy from here:
        @{
            Type                        = 'REMOVESHORTCUT'
            ShortcutFileName            = ''        # (Mandatory String) Set the FILENAME of the SHORTCUT to remove, INCLUDING the extension. Examples: 'Acrobat Cloud.lnk' or 'Online Registration.url'
            PerformDuringInstall        = $true     # (Mandatory Boolean) If the shortcut must be removed during INSTALL, then set this value to $true.
            PerformDuringUninstall      = $false    # (Mandatory Boolean) If the shortcut must be removed during UNINSTALL, then set this value to $true.
            AlsoRemoveFromStartMenu     = $true     # (Mandatory Boolean) If the shortcut must be removed from the Desktop AND THE STARTMENU, then set this value to $true. (If false, it will be removed from the Desktop only.)
        }
###### TEMPLATE REMOVESHORTCUT OBJECT ###### 6.0.0
#
#
50 - SHORTCUTS #####################################################################################
50 - SHORTCUTS #####################################################################################




80 - REGISTRY ######################################################################################
80 - REGISTRY ######################################################################################
#
#
###### TEMPLATE DEPLOYREGFILE OBJECT ######### 6.0.0
# Note: This Object imports a REGFILE during Install, and removes the imported registry keys during Uninstall.
    # Copy from here:
        @{
            Type                        = 'DEPLOYREGFILE'
            REGFileName                 = ''        # (Mandatory String) Set the FILENAME of the REGFILE, INCLUDING the extension (.reg). Example: 'AppSettings.reg'
            AlsoRemoveParentKeys        = $true     # (Mandatory Boolean) If during UNINSTALL also the PARENTKEYS should be removed (not only the properties), then set this value to $true.
        }
###### TEMPLATE DEPLOYREGFILE OBJECT ######### 6.0.0
#
###### TEMPLATE IMPORTREGFILE OBJECT ######### 6.0.0
# Note: This Object imports a REGFILE. This import can be performed during Install, and/or during Uninstall.
    # Copy from here:
        @{
            Type                        = 'IMPORTREGFILE'
            REGFileName                 = ''        # (Mandatory String) Set the FILENAME of the REGFILE, INCLUDING the extension (.reg). Example: 'AppSettings.reg'
            PerformDuringInstall        = $true     # (Mandatory Boolean) If the regfile should be IMPORTED during INSTALL, then set this value to $true.
            PerformDuringUninstall      = $false    # (Mandatory Boolean) If the regfile should be IMPORTED during UNINSTALL, then set this value to $true.
        }
###### TEMPLATE IMPORTREGFILE OBJECT ######### 6.0.0
#
#
80 - REGISTRY ######################################################################################
80 - REGISTRY ######################################################################################




90 - OTHER #########################################################################################
90 - OTHER #########################################################################################
#
#
###### TEMPLATE DEPLOYPAUSE OBJECT ###### 6.0.0
# Note: This Object pauses the deployment process for a specified number of seconds. This can be used for example, to wait for a previous installation to finish.
    # Copy from here:
        @{
            Type                        = 'DEPLOYPAUSE'
            SecondsToPause              = ''        # (Mandatory String) Set the length of the pause in SECONDS. Example: '10'.
            PerformDuringInstall        = $true     # (Mandatory Boolean) If the PAUSE be executed during INSTALL, then set this value to $true.
            PerformDuringUninstall      = $false    # (Mandatory Boolean) If the PAUSE be executed during UNINSTALL, then set this value to $true.
        }
###### TEMPLATE DEPLOYPAUSE OBJECT ###### 6.0.0
#
###### TEMPLATE DEPLOYARPENTRY OBJECT ###### 6.0.0
# Note: This Object creates an Add/Remove Programs (ARP) Entry during Install, and removes it during Uninstall.
    # Copy from here:
        @{
            Type                        = 'DEPLOYARPENTRY'
            DisplayName                 = ''        # (Optional String) Set the DISPLAYNAME of the application. Example: 'WebViewer'. (If this is empty, then the ApplicationID will be used)
            DisplayVersion              = ''        # (Mandatory String) Set the version. Example: '3.14'
            PublisherName               = ''        # (Mandatory String) Set the NAME of the PUBLISHER. Example: 'Contoso'
            DisplayIconFileName         = ''        # (Optional String) Set the FILENAME of the icon, and add it to the sourcefiles. Example: 'MyIcon.ico'. (If this is empty, then shell32.dll,15 will be used).
            QuietUninstallString        = ''        # (Optional String) Set the uninstallstring. Example: 'C:\Program Files\MyApp\Uninstall.exe /silent'. (If this is empty, then this Deployment Framework will be used).
            HideOriginalARPEntries      = @()       # (Optional String Array) If there are existing ARP entries for this application that should be hidden after installation, then enter their DISPLAYNAMES in this array. Example: @('WebViewer','Audio Driver'). (If there are no ARP entries to hide, then leave this empty.)
        }
###### TEMPLATE DEPLOYARPENTRY OBJECT ###### 6.0.0
#
###### TEMPLATE ADDENVIRONMENTPATH OBJECT ######### 6.0.0
# Note: This Object adds a directory to the SYSTEM Environment Variable PATH during Install, and removes it during Uninstall.
    # Copy from here:
        @{
            Type                        = 'ADDENVIRONMENTPATH'
            Directory                   = ''        # (Mandatory String) Set the DIRECTORY that should be added to the SYSTEM Environment Variable PATH. (Example: 'C:\Program Files\Contoso\WebViewer')
            RemoveDuringUninstall       = $true     # (Mandatory Boolean) If the Path should be REMOVED during UNINSTALL, then set this to $true.
        }
###### TEMPLATE ADDENVIRONMENTPATH OBJECT ######### 6.0.0
#
#
90 - OTHER #########################################################################################
90 - OTHER #########################################################################################







# LEGACY DEPLOYMENT OBJECTS

####################################################################################################
###################################### GENERAL INSTALLATIONS #######################################

###### TEMPLATE REMOVEMSI OBJECT ###### 5.6
# NOTE : This object only uninstalls an MSI. This can be used for example, to remove a previous version of an MSI, before installing the new version.
# Copy from here:
    @{
        Type                        = 'REMOVEMSI'
        MSIBaseNamesOrProductCodes  = @()       # (Mandatory String Array) Enter EITHER the MSI Filename OR the MSI Productcode. Example: @('MyApplication.msi','{6B29FC40-CA47-1067-B31D-00DD010662DA}'). (If an MSI is entered, then also provide that file in the sourcefiles.)
        RemoveDuringInstall         = $true     # (Mandatory Boolean) If the MSI should be removed DURING INSTALL, then set this to $true.
        RemoveDuringUninstall       = $false    # (Mandatory Boolean) If the MSI should be removed DURING UNINSTALL, then set this to $true.
        UninstallSuccessExitCodes   = @(0,3010) # (Mandatory Integer Array) Set the UNINSTALL SUCCESS EXIT CODES for the MSI. Example: @(0,123) (The default value is @(0,3010).)
    }
###### TEMPLATE REMOVEMSI OBJECT ###### 5.6

###### TEMPLATE DEPLOYEXECUTABLE OBJECT ###### 5.5.3
# Copy from here:
    @{
        Type                        = 'DEPLOYEXECUTABLE'
        InstallEXEBaseName          = ''        # (Mandatory String) Set the INSTALL EXE BASENAME WITHOUT the extension. Example: 'setup'
        InstallArguments            = @()       # (Optional String Array) Set the INSTALL ARGUMENTS for the Executable. Example: @('/SILENT','/nodesktopshortcut')
        InstallSuccessExitCodes     = @(0)      # (Mandatory Integer Array) Set the INSTALL SUCCESS EXIT CODES for the Executable. Example: @(0,123) (The default value is @(0).)
        UninstallEXEOnLocalSystem   = ''        # (Exclusive String) If the UNINSTALL EXE file is on the Local System, then enter the FULL PATH. Example: 'C:\Program Files\MyApplication\Uninstall.exe'
        UninstallEXEBaseName        = ''        # (Exclusive String) If the UNINSTALL EXE file is in the Source Files, then enter the BASENAME. Example: 'setup'
        UninstallArguments          = @()       # (Optional String Array) Set the UNINSTALL ARGUMENTS for the Executable. Example: @('/SILENT')
        UninstallSuccessExitCodes   = @(0)      # (Mandatory Integer Array) Set the UNINSTALL SUCCESS EXIT CODES for the Executable. Example: @(0,123) (The default value is @(0).)
        ZipFileBaseName             = ''        # (Optional String) If the Source Files are in a zip file, then set the BASENAME of the zip-file, EXCLUDING the extension (.zip). Example: 'MyZipFile'.
    }
###### TEMPLATE DEPLOYEXECUTABLE OBJECT ###### 5.5.3

###### TEMPLATE DEPLOYISSSETUP OBJECT ###### 5.5.3
# Copy from here:
    @{
        Type                        = 'DEPLOYISSSETUP'
        InstallEXEBaseName          = ''        # (Mandatory String) Set the INSTALL EXE BASENAME WITHOUT the extension. Example: 'setup'
        InstallISSBaseName          = ''        # (Mandatory String) Set the INSTALL INF BASENAME WITHOUT the extension. Example: 'InstallationConfuguration'.
        AdditionalInstallArguments  = @()       # (Optional String Array) Set any ADDITIONAL INSTALL ARGUMENTS for the Executable. Example: @('/norestart','/nodesktopshortcut')
        InstallSuccessExitCodes     = @(0)      # (Mandatory Integer Array) Set the INSTALL SUCCESS EXIT CODES for the Executable. Example: @(0,123) (The default value is @(0).)
        UninstallEXEOnLocalSystem   = ''        # (Exclusive String) If the UNINSTALL EXE file is on the Local System, then enter the FULL PATH. Example: 'C:\Program Files\MyApplication\Uninstall.exe'
        UninstallEXEInSourceFiles   = ''        # (Exclusive String) If the UNINSTALL EXE file is in the Source Files, then enter the BASENAME. Example: 'setup'
        UninstallISSBaseName        = ''        # (Optional String) Set the UNINSTALL INF BASENAME WITHOUT the extension. Example: 'UninstallConfuguration'.
        AdditionalUninstallArguments = @()      # (Optional String Array) Set any ADDITIONAL UNINSTALL ARGUMENTS for the Executable. Example: @('/norestart')
        UninstallSuccessExitCodes   = @(0)      # (Mandatory Integer Array) Set the UNINSTALL SUCCESS EXIT CODES for the Executable. Example: @(0,123) (The default value is @(0).)
    }
###### TEMPLATE DEPLOYISSSETUP OBJECT ###### 5.5.3

###### TEMPLATE DEPLOYINNOSETUP OBJECT ###### 5.5.3
# Copy from here:
    @{
        Type                        = 'DEPLOYINNOSETUP'
        InstallEXEBaseName          = ''        # (Mandatory String) Set the INSTALL EXE BASENAME WITHOUT the extension. Example: 'setup'
        InstallINFBaseName          = ''        # (Mandatory String) Set the INSTALL INF BASENAME WITHOUT the extension. Example: 'InstallationConfuguration'.
        AdditionalInstallArguments  = @('/VERYSILENT') # (Optional String Array) Set the INSTALL ARGUMENTS for the Executable. Example: @('/SILENT','/nodesktopshortcut')
        InstallSuccessExitCodes     = @(0)      # (Mandatory Integer Array) Set the INSTALL SUCCESS EXIT CODES for the Executable. Example: @(0,123) (The default value is @(0).)
        UninstallEXEFilePath        = ''        # (Optional String) Set the UNINSTALL EXE file path INCLUDING the extension (.exe). If there is no executable to run during UNINSTALL, then leave this empty.
        UninstallArguments          = @('/VERYSILENT') # (Optional String Array) Set the UNINSTALL ARGUMENTS for the Executable. Example: @('/SILENT')
        UninstallSuccessExitCodes   = @(0)      # (Mandatory Integer Array) Set the UNINSTALL SUCCESS EXIT CODES for the Executable. Example: @(0,123) (The default value is @(0).)
    }
###### TEMPLATE DEPLOYINNOSETUP OBJECT ###### 5.5.3

###################################### GENERAL INSTALLATIONS #######################################
####################################################################################################



####################################################################################################
######################################## FILES AND FOLDERS #########################################

###### TEMPLATE DEPLOYSYSTEMFILECOPY OBJECT ###### 5.5.3
# This object copies a file from the local system, to a folder on the local system.
# Copy from here:
    @{
        Type                        = 'DEPLOYSYSTEMFILECOPY'
        FilePathToCopy              = ''        # (Mandatory String) Set FULL PATH of the FILE to copy. Example: 'C:\Windows\System32\Robocopy.exe'
        DestinationFolder           = ''        # (Mandatory String) Set the DESTINATION FOLDER to which your file will be copied. Example: 'C:\Program Files\MyApplication'
        NewFileName                 = ''        # (Optional String) If the file must be renamed, then set NEW NAME of the file to copy. Example: 'MyCopyOfRobocopy.exe'. Otherwise leave this empty.
        OverwriteExistingFile       = $false    # (Mandatory Boolean) If an existing file needs to be overwritten, then set this value to $true.
        CopyDuringInstall           = $true     # (Mandatory Boolean) If the file needs to be copied during uninstall, then set this value to $true.
        CopyDuringUninstall         = $false    # (Mandatory Boolean) If the file needs to be copied during uninstall, then set this value to $true.
    }
###### TEMPLATE DEPLOYSYSTEMFILECOPY OBJECT ###### 5.5.3

###### TEMPLATE DEPLOYPOWERSHELLAPP OBJECT ###### 5.6
# Copy from here:
    @{
        Type                        = 'DEPLOYPOWERSHELLAPP'
        Ps1FileBaseName             = ''        # (Mandatory String) Set the BASENAME of the PS1-file, WITHOUT the extension (.ps1). Example: 'MyScript'.
        ShortcutDisplayName         = ''        # (Mandatory String) Set the DISPLAYNAME of the shortcut. Example: 'Start MyScript'
        StartMenuSubFolder          = ''        # (Optional String) Set the Startmenu SUBFOLDER. Example: 'My Application'
    }
###### TEMPLATE DEPLOYPOWERSHELLAPP OBJECT ###### 5.6


######################################## FILES AND FOLDERS #########################################
####################################################################################################


####################################################################################################
############################################ MS OFFICE #############################################

###### TEMPLATE DEPLOYMSOFFICE OBJECT ###### 5.5.2
# Copy from here:
    @{
        Type                        = 'DEPLOYMSOFFICE'
        SetupFileBaseName           = ''        # (Mandatory String) Set the BASENAME the SETUP file. Example: 'setup'
        InstallXMLFileBaseName      = ''        # (Mandatory String) Set the BASENAME the CONFIGURATION file. Example: 'Office2024Configuration'
        ProductsToLicense           = @()       # (Optional String Array) Set the PRODUCT ID's that need to be licensed. The PIDKEY has to be in the XML. Example: @('ProPlus2024Volume','VisioPro2024Volume'). When using MS Office AutoActivation, then leave this empty.
    }
###### TEMPLATE DEPLOYMSOFFICE OBJECT ###### 5.5.2

###### TEMPLATE DEPLOYTRUSTEDLOCATION OBJECT ###### 5.5.2
# Copy from here:
    @{
        Type                        = 'DEPLOYTRUSTEDLOCATION'
        TrustedLocationPath         = ''        # (Mandatory String) Set the FULL PATH of the Trusted Location. Example: 'C:\Data\ExtraOfficeFiles'
        OfficeProduct               = ''        # (Mandatory String) Set the OFFICE PRODUCT for which the Trusted Location must be added. Valid values are: Word, Excel, PowerPoint, Access
        OfficeVersion               = '2024'    # (Mandatory String) Set the OFFICE VERSION. Example: '2024'
        AllowSubfolders             = $true     # (Mandatory Boolean) If the SUBFOLDERS of the Trusted Location should also be allowed, then set this value to $true.
    }
###### TEMPLATE DEPLOYTRUSTEDLOCATION OBJECT ###### 5.5.2

############################################ MS OFFICE #############################################
####################################################################################################



####################################################################################################
##################################### LOCAL GROUPS AND USERS #######################################

###### TEMPLATE DEPLOYLOCALGROUP OBJECT ###### 5.5.3
# Copy from here:
    @{
        Type                        = 'DEPLOYLOCALGROUP'
        LocalGroupName              = ''        # (Mandatory String) The NAME of the LOCAL GROUP you wish to create. Example: 'Adobe_Administrators'
        Description                 = ''        # (Optional String) The DESCRIPTION of the LOCAL GROUP. Example: 'Administrators of Adobe Products'
        MakeMemberOfParentGroups    = @()       # (Optional String Array) The NAMES of the PARENT GROUPS, that this new Group must become a member of. Example: @('Administrators','Guests')
        AddMemberUsersOrGroups      = @()       # (Optional String Array) The NAMES of the MEMBERS, you wish to ADD to this new Group. Example: @('DOMAIN\ADGroupName1','DOMAIN\ADGroupName2')
        CreateDuringInstall         = $true     # (Mandatory Boolean) If the GROUP must be CREATED during INSTALL, then set this value to $true.
        RemoveDuringUninstall       = $false    # (Mandatory Boolean) If the GROUP must be REMOVED during UNINSTALL, then set this value to $true. (Note: this can also be used to cleanup groups, that you did not create)
    }
###### TEMPLATE DEPLOYLOCALGROUP OBJECT ###### 5.5.3

###### TEMPLATE REMOVELOCALGROUPMEMBER OBJECT ###### 5.5.3
# Copy from here:
    @{
        Type                        = 'REMOVELOCALGROUPMEMBER'
        LocalGroupName              = ''        # (Mandatory String) The NAME of the LOCAL GROUP. Example: 'Adobe_Users'
        MemberNameToRemove          = ''        # (Exclusive String) The NAME of the MEMBER that will be REMOVED. Example: 'Everyone'. (This is exlusive with MemberSIDToRemove)
        MemberSIDToRemove           = ''        # (Exclusive String) The SID of the MEMBER that will be REMOVED. Example: 'S-1-1-0'. (This is exlusive with MemberNameToRemove)
        RemoveDuringInstall         = $true     # (Mandatory Boolean) If the MEMBER must be removed during INSTALL, then set this value to $true.
        RemoveDuringUninstall       = $false    # (Mandatory Boolean) If the MEMBER must be removed during UNINSTALL, then set this value to $true.
    }
###### TEMPLATE REMOVELOCALGROUPMEMBER OBJECT ###### 5.5.3

###### TEMPLATE DEPLOYLOCALUSER OBJECT ###### (Not yet created. Will be added in the future)
# Copy from here:
    @{
        Type                        = 'DEPLOYLOCALUSER'
        LocalGroupName              = ''        # (Mandatory String) The NAME of the LOCAL GROUP you wish to create. Example: 'Adobe_Users'
        MakeMemberOf                = ''        # (Optional String) The NAME of the PARENT GROUP, that this new Group must become a member of. Example: 'Administrators'
    }
###### TEMPLATE DEPLOYLOCALGROUP OBJECT ######

##################################### LOCAL GROUPS AND USERS #######################################
####################################################################################################



####################################################################################################
########################################### RUN SCRIPTS ############################################

###### TEMPLATE RUNCMDFILE OBJECT ###### 5.5.3
# Copy from here:
    @{
        Type                        = 'RUNCMDFILE'
        CmdBatFileName              = ''        # (Mandatory String) Set the FILENAME of the cmd/bat-file, INCLUDING the extension (.cmd or .bat). Example: 'MyConfiguration.bat'.
        ArgumentList                = @()       # (Optional String Array) Set the EXTRA ARGUMENTS for the cmd/bat. Example: @('/SILENT','/nodesktopshortcut')
        RunDuringInstall            = $true     # (Mandatory Boolean) If the script must RUN during INSTALL, then set this value to $true.
        RunDuringUninstall          = $false    # (Mandatory Boolean) If the script must RUN during UNINSTALL, then set this value to $true.
    }
###### TEMPLATE RUNCMDFILE OBJECT ###### 5.5.3

###### TEMPLATE RUNPS1SCRIPT OBJECT ######
# PS1FileName (Mandatory String)                    : Set the file name of the script INCLUDING the extension (.ps1). Example: 'MyScript.ps1'
# PS1PathIsAbsolute (Mandatory Boolean)             : If the script is on the local system, the set the FULL PATH as the PS1FileName, and set this to true.
# RunDuringInstall (Mandatory Boolean)              : If the script must run during INSTALL, then set this to true.
# InstallArguments (Non-mandatory Array)            : Set the INSTALL ARGUMENTS for the script. Example: @('-Verbose')
# InstallSuccessExitCodes (Mandatory Array)         : Set the INSTALL SUCCESS EXIT CODES for the script, the default value is @(0). Example: @(0,1223,1651)
# RunDuringUninstall (Mandatory Boolean)            : If the script must run during UNINSTALL, then set this to true.
# UninstallArguments (Non-mandatory Array)          : Set the UNINSTALL ARGUMENTS for the script. Example: @('-Verbose')
# UninstallSuccessExitCodes (Mandatory Array)       : Set the UNINSTALL SUCCESS EXIT CODES for the script, the default value is @(0). Example: @(0,1223,1651)
# Copy from here:
    @{
        Type                        = 'RUNPS1SCRIPT'
        PS1FileName                 = ''
        PS1PathIsAbsolute           = $false
        RunDuringInstall            = $true
        InstallArguments            = @()
        InstallSuccessExitCodes     = @(0)
        RunDuringUninstall          = $false
        UninstallArguments          = @()
        UninstallSuccessExitCodes   = @(0)
    }
###### TEMPLATE RUNPS1SCRIPT OBJECT ######

###### TEMPLATE RUNBATCHFILE OBJECT ###### ARCHIVED
# BatchFileName (Mandatory String)      : Set the FILENAME the batchfile that must be started. Example: 'Configuration.bat'
# ArgumentList (Non-mandatory Array)    : Set the ARGUMENTS for the Executable. Example: @('-start','-database:SQL01')
# WaitUntilFinished (Mandatory Boolean) : If the process should wait until the batchfile is done, then set this boolean to $true.
# RunDuringInstall (Mandatory Boolean)  : If this should be executed during INSTALL, then set this value to $true.
# RunDuringUninstall (Mandatory Boolean): If this should be executed during UNINSTALL, then set this value to $true.
# Copy from here:
    @{
        Type                        = 'RUNBATCHFILE'
        BatchFileName               = ''
        ArgumentList                = @()
        WaitUntilFinished           = $true
        RunDuringInstall            = $true
        RunDuringUninstall          = $false
    }
###### TEMPLATE RUNBATCHFILE OBJECT ###### ARCHIVED

###### TEMPLATE DEPLOYPYTHONMODULE OBJECT ###### 5.5.3
# Copy from here:
    @{
        Type                        = 'DEPLOYPYTHONMODULE'
        PipPathOnLocalSystem        = ''        # (Mandatory String) Set the FULL PATH of pip.exe on the local system. Example: 'C:\Program Files\Python\pip.exe'
        ModulePathOnLocalSystem     = ''        # (Optional String) If the MODULE file is on the Local System, then enter the FULL PATH. Example: 'C:\Program Files\MyApplication\MyModule.whl'
        ModuleFileNameInSourceFiles = ''        # (Optional String) If the MODULE file is in the Source Files, then enter the FILENAME. Example: 'MyModule.tar.gz'
    }
###### TEMPLATE DEPLOYPYTHONMODULE OBJECT ###### 5.5.3

########################################### RUN SCRIPTS ############################################
####################################################################################################



####################################################################################################
############################################## SQL #################################################

###### TEMPLATE DEPLOYSQLEXPRESS OBJECT ###### 5.5.3
# Copy from here:
    @{
        Type                            = 'DEPLOYSQLEXPRESS'
        SetupFileBaseName               = ''    # (Mandatory String) Set the BASENAME of the SETUP FILE, WITHOUT the extension (.exe). Example: 'SQLEXPR_x64_ENU'.
        InstallConfigurationBaseName    = ''    # (Mandatory String) Set the BASENAME the CONFIGURATION FILE that will be used for INSTALLATION, WITHOUT the extension (.ini). Example: 'InstallConfiguration'
        UninstallConfigurationBaseName  = ''    # (Mandatory String) Set the BASENAME the CONFIGURATION FILE that will be used for UNINSTALL, WITHOUT the extension (.ini). Example: 'UninstallConfiguration'
    }
###### TEMPLATE DEPLOYSQLEXPRESS OBJECT ###### 5.5.3

###### TEMPLATE DEPLOYSQLSCRIPT OBJECT ###### 5.5.3
# Copy from here:
    @{
        Type                        = 'DEPLOYSQLSCRIPT'
        SQLFileBaseName             = ''        # (Mandatory String) Set the BASENAME of the SQLFILE, WITHOUT the extension (.sql). Example: 'ConfigureDatabase'
        SQLInstanceName             = ''        # (Mandatory String) Set the NAME of the SQL INSTANCE. Example: 'SQLEXPRESS2012'
        RunScriptDuringInstall      = $true     # (Mandatory Boolean) If the SCRIPT should RUN during INSTALL, then set this value to $true.
        RunScriptDuringUninstall    = $false    # (Mandatory Boolean) If the SCRIPT should RUN during UNINSTALL, then set this value to $true.
    }
###### TEMPLATE DEPLOYSQLSCRIPT OBJECT ######

############################################## SQL #################################################
####################################################################################################



####################################################################################################
############################################## OTHER ###############################################

###### TEMPLATE DEPLOYPROCESSSTOP OBJECT ###### 5.5.3
# Copy from here:
    @{
        Type                        = 'DEPLOYPROCESSSTOP'
        ProcessBaseName             = ''        # (Mandatory String) Set the BASENAME of the PROCESS to stop (WITHOUT the extension). Example: 'vpn-connector'
        StopDuringInstall           = $false    # (Mandatory Boolean) If the PROCESS must be stopped during INSTALL, then set this value to $true.
        StopDuringUninstall         = $true     # (Mandatory Boolean) If the PROCESS must be stopped during UNINSTALL, then set this value to $true.
    }
###### TEMPLATE DEPLOYPROCESSSTOP OBJECT ###### 5.5.3

###### TEMPLATE DISABLESCHEDULEDTASK OBJECT ###### 5.5.3
# Copy from here:
    @{
        Type                        = 'DISABLESCHEDULEDTASK'
        TaskName                    = ''        # (Mandatory String) Set the NAME of the TASK.
        DisableDuringInstall        = $true     # (Mandatory Boolean) If the TASK should be DISABLED during INSTALL, then set this value to $true.
        DisableDuringUninstall      = $false    # (Mandatory Boolean) If the TASK should be DISABLED during UNINSTALL, then set this value to $true.
    }
###### TEMPLATE DISABLESCHEDULEDTASK OBJECT ###### 5.5.3

###### TEMPLATE DEPLOYWINDOWSPACKAGE OBJECT ###### 5.5.3
# Copy from here:
    @{
        Type                        = 'DEPLOYWINDOWSPACKAGE'
        CABFileBaseName             = ''        # (Mandatory String) Set the BASENAME of the CAB file (WITHOUT the extension). Example: 'microsoft-windows-netfx3-ondemand-package~31bf3856ad364e35~amd64~~'
    }
###### TEMPLATE DEPLOYWINDOWSPACKAGE OBJECT ###### 5.5.3

############################################## OTHER ###############################################
####################################################################################################



###### TEMPLATE MSIX OBJECT ######
# MSIXFileNames (Mandatory Array)   : Set the MSIX Filenames WITH the extension. Example: '@('NotepadPlusPlus_8.4.8.1_x64__h8vhay9grb1ec.msix','Orca-5.0.10011x64__h8vhay9grb1ec.msix')'
# Note                              : The MSIX's will be deployed for all users (machine wide).
# Copy from here:
    @{
        Type                        = 'MSIX'
        MSIXFileNames               = @()
    }
###### TEMPLATE MSIX OBJECT ######


###### TEMPLATE DEPLOYACTIVESETUP OBJECT ######### 5.5.1
# HKCURegFileName (Mandatory String)        : Set the REGFILE name (containing the HKCU keys), INCLUDING the extension. Example: 'HKCUSettings.reg'
# ImportDuringInstall (Mandatory Boolean)   : If the regfile should be IMPORTED DURING INSTALL, then set this to $true.
# ImportDuringUninstall (Mandatory Boolean) : If the regfile should be IMPORTED DURING UNINSTALL, then set this to $true.
# Copy from here:
    @{
        Type                        = 'DEPLOYACTIVESETUP'
        HKCURegFileName             = ''
        ImportDuringInstall         = $true
        ImportDuringUninstall       = $false
    }
###### TEMPLATE DEPLOYACTIVESETUP OBJECT ######### 5.5.1


###### TEMPLATE DEPLOYFONT OBJECT ###### 5.5.1
# FontFileNames (Mandatory Array)   : Set the font FILENAMES INCLUDING the EXTENSION (.ttf, .otf). Example: @('Flora.ttf','Fauna.otf')
# Copy from here:
    @{
        Type                        = 'DEPLOYFONT'
        FontFileNames               = @()
    }
###### TEMPLATE DEPLOYFONT OBJECT ###### 5.5.1


###### TEMPLATE VSCODEEXTENSION OBJECT ###### 5.5.1
# VSIXExtensionBaseName (Mandatory String)  : Set the BASENAME of the VSIX file WITHOUT the file-extension. Example: 'ms-vscode.PowerShell-2025.5.0'
# Copy from here:
    @{
        Type                        = 'VSCODEEXTENSION'
        VSCodeExtensionBaseName     = ''
    }
###### TEMPLATE VSCODEEXTENSION OBJECT ###### 5.5.1


###### TEMPLATE CERTIFICATE OBJECT #########
# CertificateFileName (Mandatory String)    : Set the CERTIFICATE file name INCLUDING the extension (.cer, .pfx). Example: 'VendorCertificate.cer'
# CertificateStoreName (Mandatory String)   : Set the STORE name. (The default store is set to TrustedPublisher.)
# Note                                      : The certificate will be deployed for all users (in the local machine segment).
# Copy from here:
    @{
        Type                        = 'CERTIFICATE'
        CertificateFileName         = ''
        CertificateStoreName        = 'TrustedPublisher'
        RemoveDuringUninstall       = $false
    }
###### TEMPLATE CERTIFICATE OBJECT #########


###### TEMPLATE INFDRIVER OBJECT ######
# INFFileNames (Mandatory Array)    : Set the INF file names INCLUDING the extension (.inf). Example: @('driver64.inf','driver32.inf')
# Copy from here:
    @{
        Type                        = 'INFDRIVER'
        INFFileNames                = @()
    }
###### TEMPLATE INFDRIVER OBJECT ######


###### TEMPLATE DEPLOYUSERFILE OBJECT########
# FileToCopy (Mandatory String)             : Set the FILE name INCLUDING the extension. Example: 'settings.ini'
# UserFolder (Mandatory String)             : Set the Userfolder to copy to. Valid values are 'Roaming', 'Local', 'LocalLow' or 'UserProfile'
# SubfolderToCopyTo (Mandatory String)      : Set the subfolder to copy the file to. Example: 'Vendor\Configuration Files'.
# OverwriteExistingFile (Mandatory Boolean) : If an existing file needs to be overwritten, then set this value to $true.
# RemoveDuringUninstall (Mandatory Boolean) : If the file needs to be removed during uninstall, then set this value to $true.
# Copy from here:
    @{
        Type                        = 'DEPLOYUSERFILE'
        FileToCopy                  = ''
        UserProfileLocation         = 'Roaming'
        SubfolderToCopyTo           = ''
        OverwriteExistingFile       = $false
        RemoveDuringUninstall       = $false
    }
###### TEMPLATE DEPLOYUSERFILE OBJECT########


###### TEMPLATE DEPLOYUSERPROFILEFOLDER OBJECT########
# FolderToCopy (Mandatory String)               : Set the FILE name INCLUDING the extension. Example: 'settings.ini'
# UserProfileLocation (Mandatory String)        : Set the UserProfileLocation to copy to. Valid values are 'Roaming', 'Local', 'LocalLow' or 'UserProfile'
# OverwriteExistingFolder (Mandatory Boolean)   : If an existing file needs to be overwritten, then set this value to $true.
# RemoveDuringUninstall (Mandatory Boolean)     : If the folder needs to be removed during uninstall, then set this value to $true.
# Copy from here:
    @{
        Type                        = 'DEPLOYUSERPROFILEFOLDER'
        FolderToCopy                = ''
        UserProfileLocation         = 'Roaming'
        OverwriteExistingFolder     = $false
        RemoveDuringUninstall       = $false
        ValidateSetUserProfile      = @('Roaming','Local','LocalLow','UserProfile')
    }
###### TEMPLATE DEPLOYUSERPROFILEFOLDER OBJECT########


###### TEMPLATE DOTNET35 OBJECT ######
# LocalSourcePath (Non-Mandatory String)    : If there is an on-premise location with the Windows Features, then add this here. If empty then the sourcefiles will be downloaded from the internet.
# RemoveDuringUninstall (Mandatory Boolean) : If DotNet should be removed during UNINSTALL, then set this value to $true.
# Copy from here:
    @{
        Type                        = 'DOTNET35'
        LocalSourcePath             = ''
        RemoveDuringUninstall       = $false
    }
###### TEMPLATE DOTNET35 OBJECT ######


###### TEMPLATE VSTO OBJECT ######
# VSTOPathOrURL (Mandatory String)  : The URL of the VSTO. Example: 'https://VendorURL.com/OfficeAddins/VendorAddin.vsto'
# Note                              : The VSTO can only be installed silently, if the certificate is installed first. You can use the Certificate Object for this.
# Copy from here:
    @{
        Type                        = 'VSTO'
        VSTOPathOrURL               = ''
    }
###### TEMPLATE VSTO OBJECT ######


###### TEMPLATE RUNEXE OBJECT ######
# ExeFullPath (Mandatory String)        : Set the full path of the exe that must be started. Example: 'C:\Program Files\MyApp\MyService.exe'
# ArgumentList (Non-mandatory Array)    : Set the ARGUMENTS for the Executable. Example: @('-start','-database:SQL01')
# WaitUntilFinished (Mandatory Boolean) : If the process should wait until this exe is done, then set this boolean to $true. (E.g. when uninstalling an extra item)
#                                         If the process should NOT wait until this exe is done, then set this boolean to $false. (E.g. when starting a service)
# RunDuringInstall (Mandatory Boolean)  : If this should be executed during INSTALL, then set this value to $true.
# RunDuringUninstall (Mandatory Boolean): If this should be executed during UNINSTALL, then set this value to $true.
# Note                                  : The difference between this object and the DEPLOYEXE object, is that this object can only run a exe on the local system, and does not check for an exitcode.
# Copy from here:
    @{
        Type                        = 'RUNEXE'
        ExeFullPath                 = ''
        ArgumentList                = @()
        WaitUntilFinished           = $true
        RunDuringInstall            = $true
        RunDuringUninstall          = $false
    }
###### TEMPLATE RUNEXE OBJECT ######


###### TEMPLATE STOPSERVICE OBJECT ######
# SeriviceName (Mandatory String)       : Set the NAME of the SERVICE.
# DuringInstall (Mandatory Boolean)     : If this should be executed during INSTALL, then set this value to $true.
# DuringUninstall (Mandatory Boolean)   : If this should be executed during UNINSTALL, then set this value to $true.
# Copy from here:
    @{
        Type                        = 'STOPSERVICE'
        ServiceName                 = ''
        StopDuringInstall           = $true
        StopDuringUninstall         = $false
    }
###### TEMPLATE STOPSERVICE OBJECT ######


###### TEMPLATE DISABLESERVICE OBJECT ######
# SeriviceName (Mandatory String)       : Set the NAME of the SERVICE.
# DuringInstall (Mandatory Boolean)     : If this should be executed during INSTALL, then set this value to $true.
# DuringUninstall (Mandatory Boolean)   : If this should be executed during UNINSTALL, then set this value to $true.
# Copy from here:
    @{
        Type                        = 'DISABLESERVICE'
        ServiceName                 = ''
        StopDuringInstall           = $true
        StopDuringUninstall         = $false
    }
###### TEMPLATE DISABLESERVICE OBJECT ######


###### TEMPLATE PAUSE OBJECT ######
# Seconds (Mandatory String)            : Set the length of the pause in SECONDS. Example: '10' (Note: This is a String, not an Integer)
# DuringInstall (Mandatory Boolean)     : If this should be executed during INSTALL, then set this value to $true.
# DuringUninstall (Mandatory Boolean)   : If this should be executed during UNINSTALL, then set this value to $true.
# Copy from here:
    @{
        Type                        = 'PAUSE'
        Seconds                     = ''
        DuringInstall               = $true
        DuringUninstall             = $false
    }
###### TEMPLATE PAUSE OBJECT ######


####################################################################################################
###### ARCHIVED OBJECTS - DO NOT USE ######

# Archived since version 3.2:

###### TEMPLATE ASKUSERSTRING OBJECT ######
# Note: A pop-up will appear to ask the user for input.
#       The input of the user will be written into the file 'C:\ProgramData\Intune\SupportFiles\UserInput\UserInput.ini'.
#       The content of the file will be: UserInput=xxx
#       When deploying this script with Intune, it MUST be installed in USER context, for the popup to appear for the user. 
# Copy from here:
@{
    Type                            = 'ASKUSERSTRING'
}
###### TEMPLATE ASKUSERSTRING OBJECT ######

###### TEMPLATE NETWORKPRINTER OBJECT ######
# PrintServer (Mandatory String)        : Set the name of the printserver WIHOUT the backslashes. Example: 'PSERV201'
# PrinterName (Non mandatory String)    : Set the name to the network printer. Example: 'LP0106'. (If this is empty, then the file 'C:\ProgramData\Intune\SupportFiles\NetworkPrinterFile\NetworkPrinter.ini' will be used.)
# Copy from here:
@{
    Type                            = 'NETWORKPRINTER'
    PrintServer                     = ''
    PrinterName                     = ''
}
###### TEMPLATE NETWORKPRINTER OBJECT ######

###### TEMPLATE MSI OBJECT ######
# MSIFileName (Mandatory String)            : Set the MSI file name INCLUDING the extension (.msi). Example: 'Acrobat.msi'
# MSTFileName (Non-mandatory String)        : Set the MST file name INCLUDING the extension (.mst). If there is no MST file then leave this empty. Example: 'Acrobat.mst'
# MSPFileNames (Non-mandatory Array)        : Set the MSP file names INCLUDING the extension (.msp). If there are no MSP's then leave this empty. Example: @('AcrobatPatch01.msp','AcrobatPatch02.msp')
# AdditionalArguments (Non-mandatory Array) : Add any ADDITIONAL INSTALL arguments. If there are no additional arguments then leave this empty. Example: @('DATABASE=SQL01','AUTOUPDATE=OFF')
# Copy from here:
    @{
        Type                        = 'MSI'
        MSIFileName                 = ''
        MSTFileName                 = ''
        MSPFileNames                = @()
        AdditionalArguments         = @('ADDLOCAL=ALL','ALLUSERS=1')
    }
###### TEMPLATE MSI OBJECT ######


###### TEMPLATE CUSTOMFOLDER OBJECT ######
# FolderToCopy (Mandatory String)               : Set NAME OF THE FOLDER to copy to 'C:\Program Files\'. It will be renamed to the Asset ID.
# ShortcutName (Non mandatory String)           : Set the DISPLAYNAME of the shortcut. Example: 'Text Editor'. (If no shortcut is needed, then leave this empty.)
# TargetFileName (Non Mandatory String)         : Set the NAME of the TargetFileName (that is inside your sourcefolder). Example: 'TextEditor.exe'. (If no shortcut is needed, then leave this empty.)
# Arguments (Non mandatory String)              : Set the ARGUMENTS for the shortcut. Example: '/open:SQL01'
# IconFileName (Non mandatory String)           : Set the name of the ICON file INCLUDING the extension (.ico). Example: 'cross.ico'. (If this is empty, then the icon of the TargetFileName will be used.)
# WorkingDirectory (Non mandatory String)       : Set the name of the WORKING DIRECTORY. (If this is empty, then the location of the TargetFileName will be used.)
# InStartmenu (Mandatory Boolean)               : If the shortcut needs to be placed in the STARTMENU, then set this value to $true.
# OnDesktop (Mandatory Boolean)                 : If the shortcut needs to be placed on the DESKTOP, then set this value to $true.
# KeepOriginalFolderName (Mandatory Boolean)    : If you want to keep the original folder name instead of the Asset ID, then set this value to $true.
# DivertToProgramData (Mandatory Boolean)       : If you need to divert from 'C:\Program Files\' (i.e. for spaces in foldernames, or permissions), then set this value to $true. In this case, the folder 'C:\ProgramData\' will be used instead.
# DivertToRoot (Mandatory Boolean)              : If you need to divert from 'C:\Program Files\' (i.e. for spaces in foldernames, or permissions), then set this value to $true. In this case, the folder 'C:\' will be used instead.
# Copy from here:
    @{
        Type                        = 'CUSTOMFOLDER'
        FolderToCopy                = ''
        ShortcutName                = ''
        TargetFileName              = ''
        Arguments                   = ''
        IconFileName                = ''
        WorkingDirectory            = ''
        InStartmenu                 = $true
        OnDesktop                   = $false
        KeepOriginalFolderName      = $false
        DivertToProgramData         = $false
        DivertToRoot                = $false
    }
###### TEMPLATE CUSTOMFOLDER OBJECT ######


###### ARCHIVED OBJECTS ######
####################################################################################################


#endregion ### DEPLOYMENT OBJECT TEMPLATES ###
#>
